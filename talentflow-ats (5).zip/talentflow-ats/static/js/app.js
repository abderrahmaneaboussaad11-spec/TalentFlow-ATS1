(function () {
  var body = document.body;
  // Barre latérale : état mémorisé
  try { if (localStorage.getItem("tf-sidebar") === "collapsed") body.classList.add("sidebar-collapsed"); } catch (e) {}
  var toggle = document.getElementById("sidebarToggle");
  if (toggle) toggle.addEventListener("click", function () {
    if (window.matchMedia("(max-width: 991.98px)").matches) { body.classList.toggle("sidebar-open"); return; }
    body.classList.toggle("sidebar-collapsed");
    try { localStorage.setItem("tf-sidebar", body.classList.contains("sidebar-collapsed") ? "collapsed" : "open"); } catch (e) {}
  });
  document.addEventListener("click", function (e) {
    if (body.classList.contains("sidebar-open") && !e.target.closest(".sidebar") && !e.target.closest("#sidebarToggle")) body.classList.remove("sidebar-open");
  });
  // Thème clair / sombre (mémorisé dans le navigateur)
  var themeBtn = document.getElementById("themeToggle");
  if (themeBtn) themeBtn.addEventListener("click", function () {
    var next = document.documentElement.getAttribute("data-bs-theme") === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-bs-theme", next);
    try { localStorage.setItem("tf-theme", next); } catch (e) {}
    if (document.querySelector("canvas[data-chart]")) window.location.reload();
  });
  // Zone de dépôt de fichiers (glisser-déposer) : le champ fichier classique reste utilisable sans JavaScript
  document.querySelectorAll(".dropzone").forEach(function (zone) {
    var input = document.getElementById(zone.dataset.input), list = document.getElementById(zone.dataset.list);
    if (!input) return;
    function show() {
      if (!list) return;
      list.innerHTML = "";
      Array.prototype.forEach.call(input.files, function (f) { var li = document.createElement("li"); li.textContent = f.name + " (" + Math.round(f.size / 1024) + " Ko)"; list.appendChild(li); });
    }
    zone.addEventListener("click", function (e) { if (e.target !== input) input.click(); });
    zone.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } });
    ["dragenter", "dragover"].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add("dragover"); }); });
    ["dragleave", "drop"].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.remove("dragover"); }); });
    zone.addEventListener("drop", function (e) { if (e.dataTransfer && e.dataTransfer.files.length) { input.files = e.dataTransfer.files; show(); } });
    input.addEventListener("change", show);
  });
  // État de chargement des formulaires (évite les doubles envois)
  document.querySelectorAll("form").forEach(function (f) {
    f.addEventListener("submit", function () {
      var btn = f.querySelector("button[type=submit]:not([data-no-loading])");
      if (!btn || f.dataset.noLoading !== undefined) return;
      setTimeout(function () { btn.disabled = true; btn.classList.add("btn-loading"); btn.insertAdjacentHTML("afterbegin", '<span class="spinner-border me-2" role="status" aria-hidden="true"></span>'); }, 0);
    });
  });
  document.querySelectorAll("form[data-confirm]").forEach(function (f) {
    f.addEventListener("submit", function (e) { if (!window.confirm(f.dataset.confirm)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  });
  // Kanban : glisser-déposer (alternative sans JavaScript : liste déroulante sur chaque carte)
  var csrf = (document.querySelector("input[name=csrfmiddlewaretoken]") || {}).value;
  var dragged = null;
  document.querySelectorAll(".kcard[draggable=true]").forEach(function (card) {
    card.addEventListener("dragstart", function (e) { dragged = card; card.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", card.dataset.id); });
    card.addEventListener("dragend", function () { card.classList.remove("dragging"); document.querySelectorAll(".kanban-col").forEach(function (c) { c.classList.remove("drag-over"); }); });
  });
  document.querySelectorAll(".kanban-col").forEach(function (col) {
    col.addEventListener("dragover", function (e) { if (dragged) { e.preventDefault(); col.classList.add("drag-over"); } });
    col.addEventListener("dragleave", function () { col.classList.remove("drag-over"); });
    col.addEventListener("drop", function (e) {
      e.preventDefault(); col.classList.remove("drag-over");
      if (!dragged) return;
      var card = dragged, from = card.parentElement, url = card.dataset.moveUrl;
      fetch(url, { method: "POST", headers: { "Content-Type": "application/json", "X-CSRFToken": csrf }, body: JSON.stringify({ stage: col.dataset.stageId }) })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (res.ok) { col.querySelector(".kanban-body").prepend(card); window.location.reload(); }
          else { alert(res.j.error || "Déplacement impossible."); }
        })
        .catch(function () { alert("Erreur réseau : le déplacement n'a pas été enregistré."); });
    });
  });
  // Graphiques Chart.js alimentés par des json_script (données réelles)
  if (window.Chart) {
    var palette = ["#10b981", "#38bdf8", "#8b5cf6", "#f59e0b", "#f87171", "#14b8a6", "#94a3b8", "#e879f9"];
    var cs = getComputedStyle(document.documentElement); Chart.defaults.color = cs.getPropertyValue("--tf-muted").trim() || "#93a09b"; Chart.defaults.borderColor = cs.getPropertyValue("--tf-border").trim() || "#262d2b"; Chart.defaults.font.family = "'Instrument Sans', system-ui, sans-serif";
    document.querySelectorAll("canvas[data-chart]").forEach(function (cv) {
      var src = document.getElementById(cv.dataset.chart); if (!src) return;
      var d = JSON.parse(src.textContent), type = cv.dataset.type || "bar", horizontal = cv.dataset.horizontal === "1";
      var round = type === "doughnut" || type === "pie";
      d.datasets.forEach(function (ds, i) {
        if (round) { ds.backgroundColor = d.colors || palette; ds.borderColor = cs.getPropertyValue("--tf-surface").trim() || "#151918"; ds.borderWidth = 2; }
        else if (type === "line") { ds.borderColor = palette[i % palette.length]; ds.backgroundColor = palette[i % palette.length] + "22"; ds.tension = .3; ds.fill = i === 0; ds.pointRadius = 2; }
        else { ds.backgroundColor = palette[i % palette.length]; ds.borderRadius = 5; ds.maxBarThickness = 38; }
      });
      new Chart(cv, { type: type, data: { labels: d.labels, datasets: d.datasets }, options: {
        indexAxis: horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: round || d.datasets.length > 1, position: "bottom", labels: { boxWidth: 10, usePointStyle: true } } },
        scales: round ? {} : { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: horizontal } } } } });
    });
  }
})();
