from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Administrateur"
        HR_MANAGER = "hr_manager", "Responsable RH"
        RECRUITER = "recruiter", "Recruteur"
        OBSERVER = "observer", "Observateur"

    role = models.CharField("Rôle", max_length=20, choices=Role.choices, default=Role.OBSERVER)

    def save(self, *args, **kwargs):
        # Un superutilisateur créé en ligne de commande est toujours administrateur.
        if self.is_superuser:
            self.role = self.Role.ADMIN
        super().save(*args, **kwargs)

    @property
    def display_name(self):
        return self.get_full_name() or self.username

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN

    @property
    def can_manage(self):
        """Responsable RH et administrateur : paramètres, suppression, archivage."""
        return self.role in (self.Role.ADMIN, self.Role.HR_MANAGER)

    @property
    def can_write(self):
        """Peut créer/modifier offres, candidats, entretiens, évaluations."""
        return self.role in (self.Role.ADMIN, self.Role.HR_MANAGER, self.Role.RECRUITER)

    @property
    def can_see_private(self):
        """Documents (CV), notes internes et exports de données personnelles."""
        return self.can_write
