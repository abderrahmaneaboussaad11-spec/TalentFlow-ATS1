from django import forms
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .models import User


MAX_LOGIN_FAILURES = 5
LOCK_SECONDS = 15 * 60


class LoginForm(AuthenticationForm):
    """Connexion avec limitation des essais : 5 échecs consécutifs bloquent l'identifiant 15 minutes."""

    error_messages = {
        "invalid_login": "Identifiant ou mot de passe incorrect.",
        "inactive": "Ce compte est désactivé.",
    }

    def _throttle_key(self):
        username = (self.data.get("username") or "").strip().lower()
        ip = self.request.META.get("REMOTE_ADDR", "") if self.request else ""
        return f"login-fail:{username}:{ip}"

    def clean(self):
        key = self._throttle_key()
        if cache.get(key, 0) >= MAX_LOGIN_FAILURES:
            raise ValidationError("Trop de tentatives échouées. Réessayez dans 15 minutes.", code="locked")
        try:
            cleaned = super().clean()
        except ValidationError:
            cache.add(key, 0, LOCK_SECONDS)
            try:
                cache.incr(key)
            except ValueError:
                cache.set(key, 1, LOCK_SECONDS)
            raise
        cache.delete(key)
        return cleaned

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].label = "Identifiant"
        self.fields["password"].label = "Mot de passe"
        self.fields["username"].widget.attrs.update({"class": "form-control", "autofocus": True, "autocomplete": "username"})
        self.fields["password"].widget.attrs.update({"class": "form-control", "autocomplete": "current-password"})


class UserCreateForm(UserCreationForm):
    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email", "role")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields.values():
            f.widget.attrs.setdefault("class", "form-select" if isinstance(f.widget, forms.Select) else "form-control")
        self.fields["email"].required = True


class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("first_name", "last_name", "email", "role", "is_active")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, f in self.fields.items():
            if isinstance(f.widget, forms.CheckboxInput):
                f.widget.attrs["class"] = "form-check-input"
            elif isinstance(f.widget, forms.Select):
                f.widget.attrs["class"] = "form-select"
            else:
                f.widget.attrs["class"] = "form-control"


class UserPasswordForm(forms.Form):
    """Définition d'un nouveau mot de passe par un administrateur."""

    password1 = forms.CharField(label="Nouveau mot de passe", widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}))
    password2 = forms.CharField(label="Confirmation", widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}))

    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned = super().clean()
        p1, p2 = cleaned.get("password1"), cleaned.get("password2")
        if p1 and p2:
            if p1 != p2:
                raise ValidationError("Les deux mots de passe ne correspondent pas.")
            from django.contrib.auth.password_validation import validate_password
            validate_password(p1, self.user)
        return cleaned

    def save(self):
        self.user.set_password(self.cleaned_data["password1"])
        self.user.save()
        return self.user
