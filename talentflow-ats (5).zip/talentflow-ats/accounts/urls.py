from django.contrib.auth import views as auth_views
from django.urls import path

from .forms import LoginForm
from .views import logout_view

urlpatterns = [
    path("connexion/", auth_views.LoginView.as_view(template_name="registration/login.html", authentication_form=LoginForm, redirect_authenticated_user=True), name="login"),
    path("deconnexion/", logout_view, name="logout"),
]
