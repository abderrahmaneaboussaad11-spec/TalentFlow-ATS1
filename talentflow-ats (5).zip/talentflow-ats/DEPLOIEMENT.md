# Mettre TalentFlow ATS en ligne (démonstration publique)

> **Honnêteté** : ces étapes n'ont pas pu être exécutées par l'auteur du projet (aucun accès à un compte d'hébergement). Ce qui a été testé : le démarrage « comme sur Render » en local (migrations, données fictives, serveur de production, connexion en un clic, réinitialisation, fichiers statiques, endpoint de santé). Ce qui reste à vérifier **par vous** : le déploiement lui-même. L'URL finale n'existe qu'après les étapes ci-dessous.

Résultat attendu : une adresse `https://talentflow-ats-xxxx.onrender.com` que vos camarades ouvrent sans rien installer.

## Ce qu'il vous faut
- Un compte **GitHub** (gratuit) : https://github.com
- Un compte **Render** (gratuit, connexion via GitHub) : https://render.com
- Le projet extrait sur votre PC.

## Étape 1 : mettre le projet sur GitHub
1. Sur GitHub : **New repository** → nom `talentflow-ats` → *Private* (recommandé) → *Create*.
2. Le plus simple pour un débutant : installer **GitHub Desktop**, choisir *Add local repository* avec le dossier du projet, puis *Publish repository*.
3. **N'envoyez jamais** : `.env`, `.venv/`, `db.sqlite3`, `private_media/`, `DEMO_IDENTIFIANTS.txt`. Le fichier `.gitignore` du projet les exclut automatiquement avec GitHub Desktop ou git. Si vous glissez les fichiers à la main sur le site GitHub, laissez-les de côté vous-même.

## Étape 2 : créer le site sur Render
1. Sur Render : **New +** → **Blueprint** → choisissez le dépôt `talentflow-ats` → **Apply**.
2. Render lit `render.yaml` : service web gratuit, clé secrète générée automatiquement, mode démonstration activé.
3. Patientez quelques minutes (installation). Quand l'état passe à **Live**, l'adresse apparaît en haut de la page du service.

Sans Blueprint (manuel) : **New + → Web Service**, runtime *Python*, *Build command* `pip install -r requirements.txt && python manage.py collectstatic --noinput`, *Start command* `python manage.py bootstrap_demo && waitress-serve --host=0.0.0.0 --port=$PORT config.wsgi:application`, plan *Free*, puis variables d'environnement : voir `render.yaml`.

## Étape 3 : tester vous-même
1. Ouvrez l'adresse, depuis votre téléphone en 4G (hors de votre Wi-Fi) pour être sûr qu'elle est vraiment publique.
2. Cliquez **Entrer comme Recruteur** : vous arrivez sur le tableau de bord avec des données fictives.
3. Essayez : candidats, processus (Kanban), classement d'une offre, import d'un CV, export PDF.
4. Connectez-vous comme **Responsable RH** → *Paramètres* → **Réinitialiser la démonstration** pour tout remettre à zéro.

## Ce que voient vos camarades
- Une page de connexion avec trois boutons (Recruteur, Responsable RH, Observateur lecture seule). Aucun mot de passe, aucun compte administrateur.
- Un bandeau « Mode démonstration : données fictives ».

## Limites du plan gratuit (documentation officielle de Render)
- Le site se **met en veille après 15 minutes** sans visite ; le premier chargement suivant prend environ 30 à 60 secondes.
- Le **disque est éphémère** : à chaque redémarrage, tout est perdu et la démonstration se recharge toute seule (c'est voulu pour une démo).
- Une base Postgres gratuite expire après 30 jours : elle n'est pas utilisée ici.
- Render peut redémarrer un service gratuit à tout moment.

## Garder le site « toujours en ligne »

Aucun hébergement gratuit ne garantit un site éveillé en permanence. Trois voies, de la plus simple à la plus solide :

**A. Render gratuit + « réveilleur » (le plus simple, gratuit)**
1. Créez un compte gratuit sur un service de surveillance (par exemple UptimeRobot : https://uptimerobot.com).
2. Ajoutez un moniteur HTTP(S) sur `https://VOTRE-SITE.onrender.com/sante/` avec une vérification toutes les **5 minutes** (vérifiez l'intervalle autorisé dans l'offre gratuite du service).
3. Le site reçoit une visite avant les 15 minutes d'inactivité, donc il ne se met plus en veille.
- Limites : Render offre 750 heures gratuites par mois ; un service allumé en continu consomme environ 744 heures, donc **un seul service gratuit** peut rester allumé tout le mois. Render peut aussi redémarrer un service gratuit à tout moment : la démonstration se recharge alors toute seule (données fictives d'origine). Vérifiez que cette pratique reste acceptée par les conditions d'utilisation actuelles de Render.

**B. PythonAnywhere gratuit (ne s'endort pas, disque persistant)**
- Un site Django gratuit sur `votre-nom.pythonanywhere.com`, sans veille après 15 minutes et avec un disque qui conserve les fichiers.
- Contraintes : mise en place manuelle (console, environnement virtuel, fichier WSGI, fichiers statiques), et le site gratuit **expire si vous ne vous reconnectez pas pour cliquer sur le bouton de prolongation** (une fois par mois ou par trimestre selon la date de création du compte : l'e-mail d'avertissement vous le rappelle). Pas d'accès SSH ni de tâches planifiées en gratuit.
- Guide pas à pas : **`DEPLOIEMENT_PYTHONANYWHERE.md`**.

**C. Offre payante (solide, sans surveillance)**
Une offre payante entrée de gamme chez Render, PythonAnywhere (offre « Developer », environ 10 $/mois d'après les pages tarifaires consultées, à vérifier) ou un petit serveur évite la veille. Vérifiez toujours le prix actuel avant de vous engager.

**Pour une présentation devant le jury** : quelle que soit la voie, ouvrez le lien une heure avant, et gardez la démo locale (`LANCER.bat --demo`) comme plan B.

## Règles à respecter
- **Aucune donnée réelle de candidat** sur ce site (pas de validation juridique : Loi 09-08, CNDP).
- Les CV importés pendant la démo sont des fichiers de test et disparaissent au redémarrage.
- L'OCR (PDF scannés) n'est pas disponible sur l'hébergement gratuit standard (Tesseract absent) : l'application l'indique clairement et propose la saisie manuelle.

## Dépannage
| Symptôme | Piste |
|---|---|
| Le déploiement échoue | Ouvrez l'onglet *Logs* du service : le message d'erreur y est. Copiez-le pour demander de l'aide. |
| « Bad Request (400) » | L'hôte n'est pas autorisé : vérifiez que la variable `DJANGO_ALLOWED_HOSTS` existe (l'adresse Render est ajoutée automatiquement). |
| « CSRF verification failed » | Utilisez l'adresse `https://…onrender.com` exacte. |
| Page blanche / lente | Normal au réveil du site (30 à 60 s). Rechargez. |
| Les boutons de démo n'apparaissent pas | `TALENTFLOW_DEMO_MODE` doit valoir `1`. |
