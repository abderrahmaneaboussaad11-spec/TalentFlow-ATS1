from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("accounts.urls")),
    path("", include("ats.urls")),
]

handler403 = "ats.views.errors.permission_denied"
handler404 = "ats.views.errors.not_found"
handler500 = "ats.views.errors.server_error"
