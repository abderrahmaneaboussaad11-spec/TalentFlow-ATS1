"""Partage une DÉMONSTRATION (données fictives uniquement) via un lien HTTPS temporaire.

- Utilise une base et un dossier de fichiers SÉPARÉS (demo.sqlite3 / private_media_demo) : vos vraies données ne sont jamais exposées.
- Serveur de production (waitress) avec DEBUG désactivé, fichiers statiques servis par WhiteNoise.
- Tunnel Cloudflare « Quick Tunnel » : lien public temporaire, sans compte ; il s'arrête avec ce programme.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

from start_local import ROOT, port_in_use, say, venv_python

URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
EXE = "cloudflared.exe" if os.name == "nt" else "cloudflared"
DOWNLOAD = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"


def demo_env():
    env = dict(os.environ)
    env.update({
        "DJANGO_DEBUG": "0", "DJANGO_BEHIND_PROXY": "1", "DJANGO_SSL_REDIRECT": "0", "DJANGO_SECURE_COOKIES": "1",
        "TALENTFLOW_DEMO_MODE": "1", "TALENTFLOW_DB_NAME": "demo.sqlite3", "TALENTFLOW_MEDIA_DIR": "private_media_demo",
        "DJANGO_ALLOWED_HOSTS": "localhost,127.0.0.1,.trycloudflare.com",
        "DJANGO_CSRF_TRUSTED_ORIGINS": "https://*.trycloudflare.com",
    })
    return env


def manage(vpy, env, *args, what):
    say(f"\n> {what}")
    code = subprocess.call([str(vpy), "manage.py", *args], cwd=ROOT, env=env)
    if code != 0:
        say(f"\nERREUR pendant : {what}.")
        sys.exit(code or 1)


def find_cloudflared():
    found = shutil.which("cloudflared")
    if found:
        return found
    local = ROOT / "tools" / EXE
    if local.exists():
        return str(local)
    if os.name == "nt":
        say("\n> Téléchargement de cloudflared (outil officiel Cloudflare, une seule fois)...")
        try:
            local.parent.mkdir(exist_ok=True)
            urllib.request.urlretrieve(DOWNLOAD, local)
            return str(local)
        except Exception as exc:  # réseau, pare-feu, antivirus…
            say(f"Téléchargement impossible ({exc}).")
    say("\ncloudflared est introuvable. Installez-le puis relancez ce programme :")
    say("    winget install --id Cloudflare.cloudflared      (puis fermez et rouvrez la fenêtre)")
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8100)
    parser.add_argument("--no-tunnel", action="store_true", help="Démarre uniquement le serveur de démonstration (test local).")
    parser.add_argument("--mails", default="", help="Adresses e-mail autorisées (séparées par des virgules) : le visiteur recevra un code par e-mail avant d'accéder au lien.")
    args = parser.parse_args()

    say("=" * 60)
    say("  TalentFlow ATS — PARTAGE DE DÉMONSTRATION (données fictives)")
    say("=" * 60)
    code = subprocess.call([sys.executable, "start_local.py", "--no-server", "--no-browser", "--skip-admin"], cwd=ROOT)
    if code != 0:
        sys.exit(code)
    vpy, env = venv_python(), demo_env()
    manage(vpy, env, "migrate", "--noinput", "-v", "0", what="Préparation de la base de démonstration (séparée de vos données)")
    manage(vpy, env, "collectstatic", "--noinput", "-v", "0", what="Préparation des fichiers du site")
    manage(vpy, env, "seed_demo", what="Chargement des données fictives (si absentes)")
    creds = ROOT / "DEMO_IDENTIFIANTS.txt"
    manage(vpy, env, "demo_accounts", "--file", str(creds), what="Création des comptes de démonstration")

    tunnel_bin = None if args.no_tunnel else find_cloudflared()
    if not args.no_tunnel and not tunnel_bin:
        sys.exit(1)
    if port_in_use(args.port):
        say(f"Le port {args.port} est déjà utilisé : relancez avec --port 8101.")
        sys.exit(1)
    server = subprocess.Popen([str(vpy), "-m", "waitress", f"--listen=127.0.0.1:{args.port}", "config.wsgi:application"], cwd=ROOT, env=env)
    tunnel = None
    try:
        for _ in range(60):
            if port_in_use(args.port):
                break
            time.sleep(0.5)
        else:
            say("Le serveur n'a pas démarré. Lisez les messages ci-dessus.")
            return
        if args.no_tunnel:
            say(f"\nServeur de démonstration prêt sur http://127.0.0.1:{args.port}/ (Ctrl + C pour arrêter)")
            server.wait()
            return
        cmd = [tunnel_bin, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{args.port}"]
        for mail in [m.strip() for m in args.mails.split(",") if m.strip()]:
            cmd += ["--allowed-mail", mail]
        tunnel = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        found = threading.Event()

        def pump():
            for line in tunnel.stdout:
                m = URL_RE.search(line)
                if m and not found.is_set():
                    found.set()
                    say("\n" + "=" * 60)
                    say("  LIEN À DONNER AU JURY :")
                    say(f"      {m.group(0)}")
                    say("")
                    say("  Comptes (aussi dans DEMO_IDENTIFIANTS.txt) :")
                    for l in creds.read_text(encoding="utf-8").splitlines()[1:]:
                        say("   " + l)
                    say("")
                    say("  Le lien fonctionne tant que cette fenêtre reste ouverte.")
                    say("  Pour tout arrêter : Ctrl + C. Tout lien est alors invalide.")
                    say("=" * 60)
                elif "ERR" in line:
                    say("  [cloudflared] " + line.strip())

        threading.Thread(target=pump, daemon=True).start()
        if not found.wait(60):
            say("\nLe lien n'est pas apparu après 60 secondes : vérifiez votre connexion internet ou votre pare-feu.")
        tunnel.wait()
    except KeyboardInterrupt:
        pass
    finally:
        for proc in (tunnel, server):
            if proc and proc.poll() is None:
                proc.terminate()
        say("\nPartage arrêté : le lien n'est plus valide.")


if __name__ == "__main__":
    main()
