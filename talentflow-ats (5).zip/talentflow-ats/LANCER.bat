@echo off
chcp 65001 >nul
title TalentFlow ATS
cd /d "%~dp0"
echo.
echo === TalentFlow ATS ===
where py >nul 2>nul && (py -3 start_local.py %* & goto :fin)
where python >nul 2>nul && (python start_local.py %* & goto :fin)
echo Python est introuvable. Installez Python depuis https://www.python.org/downloads/
echo et cochez "Add python.exe to PATH" pendant l installation. Puis relancez ce fichier.
start https://www.python.org/downloads/
:fin
echo.
echo Le programme est termine. Si une erreur est affichee ci-dessus, copiez-la pour demander de l aide.
pause
