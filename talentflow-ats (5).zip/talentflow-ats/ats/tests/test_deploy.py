import io
import shutil
import tempfile
import zipfile
from pathlib import Path
from unittest import skipUnless

from django.core.exceptions import ImproperlyConfigured
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import override_settings
from django.urls import reverse
from pypdf import PdfReader

from accounts.models import User
from ats.models import Application, AuditEvent, Candidate, CVDocument, Job, PipelineStage
from ats.services import pipeline, scoring
from ats.services.cv_parser import extract_text_ex, ocr_available

from .base import ATSTestCase, make_candidate, make_job, make_user
from .test_cv import CV_TEXT, make_docx, make_pdf


class HealthAndConfigTests(ATSTestCase):
    def test_health_endpoint_is_public_and_minimal(self):
        r = self.client.get(reverse("health"))
        self.assertEqual((r.status_code, r.json()), (200, {"status": "ok"}))

    def test_database_url_parsing(self):
        from config import settings
        cfg = settings._database_from_url("postgres://user:p%40ss@db.example.com:6543/talent")
        self.assertEqual((cfg["NAME"], cfg["USER"], cfg["PASSWORD"], cfg["HOST"], cfg["PORT"]), ("talent", "user", "p@ss", "db.example.com", "6543"))
        with self.assertRaises(ImproperlyConfigured):
            settings._database_from_url("mysql://x@y/z")


class BulkCVTests(ATSTestCase):
    def test_multiple_files_go_to_pending_review_without_creating_candidates(self):
        self.login("recruiter")
        names = ["Alpha Beta", "Gamma Delta", "Omega Sigma"]
        files = [SimpleUploadedFile(f"cv{i}.docx", make_docx(CV_TEXT.replace("Yasmine Alaoui", n).replace("yasmine.alaoui", f"p{i}.n{i}"))) for i, n in enumerate(names)]
        files.append(SimpleUploadedFile("bad.exe", b"MZ"))
        r = self.client.post(reverse("cv_import"), {"files": files}, follow=True)
        self.assertEqual(CVDocument.objects.count(), 3)
        self.assertEqual(Candidate.objects.count(), 0)
        self.assertContains(r, "Fichier refusé")
        self.assertContains(r, "3 CV importés")
        self.assertContains(r, "Gamma Delta")
        doc = CVDocument.objects.first()
        r = self.client.post(reverse("candidate_create"), {})
        self.client.post(reverse("cv_discard", args=[doc.pk]))
        self.assertEqual(CVDocument.objects.count(), 2)

    def test_too_many_files_and_no_files(self):
        self.login("recruiter")
        r = self.client.post(reverse("cv_import"), {})
        self.assertContains(r, "au moins un fichier")
        with self.settings(CV_MAX_FILES_PER_UPLOAD=1):
            r = self.client.post(reverse("cv_import"), {"files": [SimpleUploadedFile("a.docx", make_docx(CV_TEXT)), SimpleUploadedFile("b.docx", make_docx(CV_TEXT))]})
            self.assertContains(r, "Maximum 1 fichiers")
        self.assertEqual(CVDocument.objects.count(), 0)

    def test_observer_cannot_import_or_see_pending(self):
        self.login("observer")
        self.assertEqual(self.client.get(reverse("cv_import")).status_code, 403)
        self.assertEqual(self.client.get(reverse("cv_pending")).status_code, 403)


def _scanned_pdf_bytes():
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (1240, 700), "white")
    d = ImageDraw.Draw(img)
    font = ImageFont.load_default(size=44)
    for i, line in enumerate(["Jean Dupont", "jean.dupont@example.test", "Competences : SEO, Excel, Canva", "Experience professionnelle"]):
        d.text((60, 60 + i * 90), line, fill="black", font=font)
    buf = io.BytesIO()
    img.save(buf, "PDF")
    return buf.getvalue()


class OCRTests(ATSTestCase):
    @skipUnless(ocr_available(), "Tesseract non installé sur cette machine")
    def test_scanned_pdf_is_read_by_ocr(self):
        text, used = extract_text_ex(io.BytesIO(_scanned_pdf_bytes()), ".pdf")
        self.assertTrue(used)
        self.assertIn("dupont", text.lower())
        self.assertIn("jean.dupont@example.test", text.lower())

    @skipUnless(ocr_available(), "Tesseract non installé sur cette machine")
    def test_scanned_pdf_upload_flags_ocr_and_requires_review(self):
        self.login("recruiter")
        r = self.client.post(reverse("cv_import"), {"files": SimpleUploadedFile("scan.pdf", _scanned_pdf_bytes())}, follow=True)
        doc = CVDocument.objects.get()
        self.assertTrue(doc.used_ocr)
        self.assertContains(r, "reconnaissance de caractères")
        self.assertEqual(Candidate.objects.count(), 0)

    def test_scanned_pdf_without_ocr_gives_clear_message(self):
        from django.test import override_settings
        with override_settings(OCR_ENABLED=False):
            from ats.services.cv_parser import CVExtractionError
            with self.assertRaises(CVExtractionError) as cm:
                extract_text_ex(io.BytesIO(_scanned_pdf_bytes()), ".pdf")
            self.assertIn("OCR", str(cm.exception))


class ReportAndBackupTests(ATSTestCase):
    def test_analytics_pdf_is_valid_and_real(self):
        self.login("recruiter")
        pipeline.create_application(make_candidate(), make_job(title="Poste PDF"))
        r = self.client.get(reverse("analytics"), {"export": "pdf"})
        self.assertEqual(r["Content-Type"], "application/pdf")
        text = "\n".join(p.extract_text() for p in PdfReader(io.BytesIO(r.content)).pages)
        self.assertIn("Rapport de recrutement", text)
        self.assertIn("Candidatures", text)
        self.assertIn("Poste PDF", text)
        self.assertTrue(AuditEvent.objects.filter(action="export.analytics_pdf").exists())

    def test_ranking_pdf_lists_candidates_and_tie_warning(self):
        self.login("recruiter")
        job = make_job()
        for i in range(3):
            app = pipeline.create_application(make_candidate(first_name=f"Egal{i}", skills=["SEO"]), job)
            scoring.evaluate_application(app)
        r = self.client.get(reverse("job_ranking", args=[job.pk]), {"export": "pdf", "n": 2})
        text = "\n".join(p.extract_text() for p in PdfReader(io.BytesIO(r.content)).pages)
        self.assertIn("Egal0", text)
        self.assertIn("Égalité au seuil", text)

    def test_pdf_exports_forbidden_for_observer(self):
        self.login("observer")
        self.assertEqual(self.client.get(reverse("analytics"), {"export": "pdf"}).status_code, 403)
        self.assertEqual(self.client.get(reverse("job_ranking", args=[make_job().pk]), {"export": "pdf"}).status_code, 403)

    def test_backup_creates_consistent_copy_and_rotates(self):
        make_candidate(first_name="Sauvegarde")
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as media:
            (Path(media) / "cv").mkdir()
            (Path(media) / "cv" / "x.pdf").write_bytes(b"%PDF-1.4 test")
            with self.settings(BACKUP_DIR=Path(d), PRIVATE_MEDIA_ROOT=media):
                import time
                for _ in range(3):
                    call_command("backup_data", "--keep", "2", stdout=io.StringIO())
                    time.sleep(1.1)
                dbs = sorted(Path(d).glob("talentflow-*.sqlite3"))
                self.assertEqual(len(dbs), 2)
                import sqlite3
                # sous SQLite en mémoire (tests) la copie est vide mais valide ; on vérifie surtout l'intégrité
                con = sqlite3.connect(dbs[-1])
                self.assertEqual(con.execute("pragma integrity_check").fetchone()[0], "ok")
                con.close()
                with zipfile.ZipFile(next(Path(d).glob("*-fichiers.zip"))) as z:
                    self.assertIn("cv/x.pdf", z.namelist())


class DemoWorkspaceTests(ATSTestCase):
    def setUp(self):
        super().setUp()
        call_command("seed_demo", "--candidates", "6", verbosity=0)
        call_command("demo_accounts", stdout=io.StringIO())

    def test_one_click_login_only_in_demo_mode(self):
        self.assertEqual(self.client.post(reverse("demo_login", args=["recruteur"])).status_code, 404)
        with self.settings(DEMO_MODE=True):
            r = self.client.post(reverse("demo_login", args=["recruteur"]))
            self.assertRedirects(r, reverse("dashboard"))
            self.assertContains(self.client.get(reverse("dashboard")), "Mode démonstration")
            self.assertEqual(self.client.get(reverse("settings_company")).status_code, 403)  # recruteur : pas de paramètres
            self.assertEqual(self.client.post(reverse("demo_login", args=["admin"])).status_code, 404)  # aucun accès administrateur
            self.assertEqual(self.client.get(reverse("demo_login", args=["rh"])).status_code, 405)  # POST uniquement

    def test_login_page_shows_demo_buttons_only_in_demo_mode(self):
        self.assertNotContains(self.client.get(reverse("login")), "Entrer comme Recruteur")
        with self.settings(DEMO_MODE=True):
            self.assertContains(self.client.get(reverse("login")), "Entrer comme Recruteur")

    def test_observer_demo_login_is_read_only(self):
        with self.settings(DEMO_MODE=True):
            self.client.post(reverse("demo_login", args=["observateur"]))
            self.assertEqual(self.client.get(reverse("job_create")).status_code, 403)

    def test_reset_wipes_user_data_and_restores_demo(self):
        with self.settings(DEMO_MODE=True):
            self.client.post(reverse("demo_login", args=["rh"]))
            make_candidate(first_name="Intrus")
            make_job(title="Offre ajoutée par un visiteur")
            r = self.client.post(reverse("demo_reset"))
            self.assertRedirects(r, reverse("dashboard"))
            self.assertFalse(Candidate.objects.filter(first_name="Intrus").exists())
            self.assertFalse(Job.objects.filter(title__startswith="Offre ajoutée").exists())
            self.assertTrue(Candidate.objects.filter(is_demo=True).exists())
            self.assertEqual(PipelineStage.objects.count(), 8)
            self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)  # la session survit (comptes conservés)

    def test_reset_refused_outside_demo_mode_and_for_recruiter(self):
        from ats.services.demo import reset_demo_workspace
        make_candidate(first_name="Reel")
        with self.assertRaises(PermissionError):
            reset_demo_workspace()
        self.assertTrue(Candidate.objects.filter(first_name="Reel").exists())
        self.login("recruiter")
        self.assertEqual(self.client.post(reverse("demo_reset")).status_code, 403)

    def test_bootstrap_demo_is_idempotent(self):
        Candidate.objects.all().delete()
        call_command("bootstrap_demo", stdout=io.StringIO())
        n = Candidate.objects.count()
        self.assertGreater(n, 0)
        call_command("bootstrap_demo", stdout=io.StringIO())
        self.assertEqual(Candidate.objects.count(), n)


class PerformanceAndInsightTests(ATSTestCase):
    def test_pipeline_board_query_count_does_not_grow_with_applications(self):
        self.login("recruiter")
        job = make_job()

        def count_queries():
            from django.db import connection
            from django.test.utils import CaptureQueriesContext
            with CaptureQueriesContext(connection) as ctx:
                self.assertEqual(self.client.get(reverse("pipeline")).status_code, 200)
            return len(ctx)

        for i in range(3):
            scoring.evaluate_application(pipeline.create_application(make_candidate(), job))
        small = count_queries()
        for i in range(15):
            scoring.evaluate_application(pipeline.create_application(make_candidate(), job))
        self.assertLessEqual(count_queries(), small + 2)

    def test_insights_show_matched_and_missing_skills(self):
        self.login("recruiter")
        job = make_job()
        app = pipeline.create_application(make_candidate(skills=["SEO"]), job)
        scoring.evaluate_application(app)
        r = self.client.get(reverse("application_detail", args=[app.pk]))
        self.assertContains(r, "Analyse de correspondance")
        self.assertContains(r, "50 % retrouvées")
        self.assertContains(r, "Non documentées")
        ins = r.context["insights"]
        self.assertEqual((ins["matched"], ins["missing"]), (["SEO"], ["Excel"]))


class ThemeTests(ATSTestCase):
    def test_theme_toggle_present_and_script_before_css(self):
        self.login("recruiter")
        html = self.client.get(reverse("dashboard")).content.decode()
        self.assertIn('id="themeToggle"', html)
        self.assertLess(html.index("tf-theme"), html.index("theme.css"))
