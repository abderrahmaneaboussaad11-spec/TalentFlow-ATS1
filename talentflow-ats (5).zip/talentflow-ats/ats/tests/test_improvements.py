import io
import tempfile
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from unittest import mock

from django.core.cache import cache
from django.core.files.base import ContentFile
from django.core.management import call_command
from django.urls import reverse
from django.utils import timezone

from accounts.models import User
from ats.models import Application, AuditEvent, CVDocument, PipelineStage
from ats.services import pipeline, scoring
from ats.views.jobs import shortlist_analysis

from .base import ATSTestCase, make_candidate, make_job, make_user


class LoginThrottleTests(ATSTestCase):
    def test_five_failures_lock_even_correct_password(self):
        make_user("recruiter", "alice")
        for _ in range(5):
            r = self.client.post(reverse("login"), {"username": "alice", "password": "bad"})
            self.assertContains(r, "Identifiant ou mot de passe incorrect")
        r = self.client.post(reverse("login"), {"username": "alice", "password": "Str0ng-pass-123!"})
        self.assertContains(r, "Trop de tentatives")
        self.assertNotIn("_auth_user_id", self.client.session)
        cache.clear()
        r = self.client.post(reverse("login"), {"username": "alice", "password": "Str0ng-pass-123!"})
        self.assertRedirects(r, reverse("dashboard"))

    def test_success_resets_counter(self):
        make_user("recruiter", "alice")
        for _ in range(3):
            self.client.post(reverse("login"), {"username": "alice", "password": "bad"})
        self.client.post(reverse("login"), {"username": "alice", "password": "Str0ng-pass-123!"})
        self.client.post(reverse("logout"))
        for _ in range(4):
            self.client.post(reverse("login"), {"username": "alice", "password": "bad"})
        r = self.client.post(reverse("login"), {"username": "alice", "password": "Str0ng-pass-123!"})
        self.assertRedirects(r, reverse("dashboard"))


class AdminPasswordTests(ATSTestCase):
    def test_admin_sets_password_and_validators_apply(self):
        admin = make_user("admin", "boss")
        target = make_user("recruiter", "alice")
        self.client.force_login(admin)
        r = self.client.post(reverse("user_password", args=[target.pk]), {"password1": "123", "password2": "123"})
        self.assertContains(r, "trop court")
        r = self.client.post(reverse("user_password", args=[target.pk]), {"password1": "Nouveau-Mdp-2026!", "password2": "Autre-Mdp-2026!"})
        self.assertContains(r, "ne correspondent pas")
        self.client.post(reverse("user_password", args=[target.pk]), {"password1": "Nouveau-Mdp-2026!", "password2": "Nouveau-Mdp-2026!"})
        target.refresh_from_db()
        self.assertTrue(target.check_password("Nouveau-Mdp-2026!"))
        self.assertTrue(AuditEvent.objects.filter(action="user.password_reset").exists())

    def test_non_admin_forbidden(self):
        hr = make_user("hr_manager", "hr")
        self.client.force_login(hr)
        self.assertEqual(self.client.get(reverse("user_password", args=[hr.pk])).status_code, 403)


class ShortlistTests(ATSTestCase):
    def setUp(self):
        super().setUp()
        self.user = self.login("recruiter")
        self.job = make_job(min_experience_years=Decimal("2"))
        self.strong = make_candidate(first_name="Forte", education_level=4, education_field="Marketing", years_experience=Decimal("3"), skills=["SEO", "Excel"], languages="Français, Anglais")
        self.tied = [make_candidate(first_name=f"Egal{i}", skills=["SEO"]) for i in range(3)]
        self.apps = {c.pk: pipeline.create_application(c, self.job) for c in [self.strong] + self.tied}
        for app in self.apps.values():
            scoring.evaluate_application(app)

    def ranked(self):
        from ats.views.jobs import _ranked_rows
        return _ranked_rows(self.job)[0]

    def test_analysis_without_tie(self):
        a = shortlist_analysis(self.ranked(), 1)
        self.assertFalse(a["tie"])
        self.assertEqual([r["app"].candidate for r in a["sure"]], [self.strong])

    def test_analysis_detects_tie_and_does_not_pick(self):
        a = shortlist_analysis(self.ranked(), 2)
        self.assertTrue(a["tie"])
        self.assertEqual(len(a["tied"]), 3)
        self.assertEqual(a["slots"], 1)
        self.assertEqual([r["app"].candidate for r in a["sure"]], [self.strong])  # aucun départage arbitraire
        r = self.client.get(reverse("job_ranking", args=[self.job.pk]), {"n": 2})
        self.assertContains(r, "Égalité au seuil")

    def test_fewer_candidates_than_slots(self):
        a = shortlist_analysis(self.ranked(), 10)
        self.assertFalse(a["tie"])
        self.assertEqual(len(a["sure"]), 4)

    def test_tie_requires_written_justification(self):
        pick = self.apps[self.tied[1].pk]
        data = {"n": 2, "ids": [self.apps[self.strong.pk].pk, pick.pk]}
        self.client.post(reverse("job_shortlist", args=[self.job.pk]), data)
        pick.refresh_from_db()
        self.assertEqual(pick.stage.kind, "new")
        data["justification"] = "Meilleur échange téléphonique"
        self.client.post(reverse("job_shortlist", args=[self.job.pk]), data)
        pick.refresh_from_db()
        self.assertEqual(pick.stage.kind, "screening")
        self.assertIn("Meilleur échange téléphonique", pick.history.first().comment)
        self.assertTrue(AuditEvent.objects.filter(action="job.shortlist", details__contains="égalité justifiée").exists())
        other = self.apps[self.tied[0].pk]
        other.refresh_from_db()
        self.assertEqual(other.stage.kind, "new")

    def test_shortlist_without_tie_needs_no_justification(self):
        self.client.post(reverse("job_shortlist", args=[self.job.pk]), {"n": 1, "ids": [self.apps[self.strong.pk].pk]})
        self.assertEqual(self.apps[self.strong.pk].__class__.objects.get(pk=self.apps[self.strong.pk].pk).stage.kind, "screening")

    def test_shortlist_ignores_other_jobs_and_empty_selection(self):
        r = self.client.post(reverse("job_shortlist", args=[self.job.pk]), {"n": 1})
        self.assertEqual(r.status_code, 302)
        other_job = make_job(title="Autre")
        foreign = pipeline.create_application(make_candidate(), other_job)
        self.client.post(reverse("job_shortlist", args=[self.job.pk]), {"n": 1, "ids": [foreign.pk]})
        foreign.refresh_from_db()
        self.assertEqual(foreign.stage.kind, "new")

    def test_observer_cannot_shortlist(self):
        self.client.logout()
        self.login("observer")
        r = self.client.post(reverse("job_shortlist", args=[self.job.pk]), {"n": 1, "ids": [1]})
        self.assertEqual(r.status_code, 403)


class CompareTests(ATSTestCase):
    def test_compare_two_candidates_shows_evidence(self):
        self.login("recruiter")
        job = make_job()
        a = pipeline.create_application(make_candidate(first_name="Alpha", skills=["SEO"]), job)
        b = pipeline.create_application(make_candidate(first_name="Bravo", skills=["SEO", "Excel"]), job)
        for x in (a, b):
            scoring.evaluate_application(x)
        r = self.client.post(reverse("job_compare", args=[job.pk]), {"ids": [a.pk, b.pk]})
        self.assertContains(r, "Alpha")
        self.assertContains(r, "Bravo")
        self.assertContains(r, "Non documentés dans le dossier")
        r = self.client.get(reverse("job_compare", args=[job.pk]), {"ids": f"{a.pk},{b.pk}"})
        self.assertEqual(r.status_code, 200)

    def test_compare_needs_two(self):
        self.login("recruiter")
        job = make_job()
        a = pipeline.create_application(make_candidate(), job)
        r = self.client.post(reverse("job_compare", args=[job.pk]), {"ids": [a.pk]})
        self.assertEqual(r.status_code, 302)

    def test_observer_forbidden(self):
        self.login("observer")
        self.assertEqual(self.client.get(reverse("job_compare", args=[make_job().pk])).status_code, 403)


class ExportAndMaintenanceTests(ATSTestCase):
    def test_analytics_csv_export(self):
        self.login("recruiter")
        pipeline.create_application(make_candidate(), make_job())
        r = self.client.get(reverse("analytics"), {"export": "csv"})
        body = r.content.decode("utf-8")
        self.assertIn("text/csv", r["Content-Type"])
        self.assertIn("Entonnoir", body)
        self.assertIn("indisponible", body)
        self.client.logout()
        self.login("observer")
        self.assertEqual(self.client.get(reverse("analytics"), {"export": "csv"}).status_code, 403)

    def test_purge_orphan_cvs_only_removes_old_unattached(self):
        user = make_user("recruiter")
        old = CVDocument.objects.create(original_name="old.pdf", uploaded_by=user)
        old.file.save("old.pdf", ContentFile(b"%PDF-1.4"), save=True)
        CVDocument.objects.filter(pk=old.pk).update(uploaded_at=timezone.now() - timedelta(days=3))
        fresh = CVDocument.objects.create(original_name="new.pdf", uploaded_by=user)
        fresh.file.save("new.pdf", ContentFile(b"%PDF-1.4"), save=True)
        attached = CVDocument.objects.create(original_name="ok.pdf", uploaded_by=user, candidate=make_candidate())
        attached.file.save("ok.pdf", ContentFile(b"%PDF-1.4"), save=True)
        CVDocument.objects.filter(pk=attached.pk).update(uploaded_at=timezone.now() - timedelta(days=3))
        call_command("purge_orphan_cvs", verbosity=0)
        self.assertEqual(set(CVDocument.objects.values_list("original_name", flat=True)), {"new.pdf", "ok.pdf"})


class InitLocalTests(ATSTestCase):
    def test_creates_admin_with_valid_password(self):
        with mock.patch("sys.stdin") as stdin, mock.patch("builtins.input", return_value="chef"), \
                mock.patch("getpass.getpass", side_effect=["123", "123", "Mot-de-passe-solide-1", "Mot-de-passe-solide-1"]):
            stdin.isatty.return_value = True
            call_command("init_local", stdout=io.StringIO())
        u = User.objects.get(username="chef")
        self.assertEqual(u.role, "admin")
        self.assertTrue(u.check_password("Mot-de-passe-solide-1"))

    def test_skips_when_user_exists(self):
        make_user("admin", "boss")
        out = io.StringIO()
        call_command("init_local", stdout=out)
        self.assertIn("existe déjà", out.getvalue())
        self.assertEqual(User.objects.count(), 1)

    def test_non_interactive_does_not_hang(self):
        out = io.StringIO()
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = False
            call_command("init_local", stdout=out)
        self.assertIn("createsuperuser", out.getvalue())


class SettingsEnvTests(ATSTestCase):
    def test_env_file_with_utf8_bom_is_read(self):
        import os
        from config import settings
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".env"
            p.write_bytes(b"\xef\xbb\xbfTF_TEST_BOM_VAR=ok\r\nTF_TEST_QUOTED=\"abc\"\r\n")
            settings._load_env_file(p)
        self.assertEqual(os.environ.get("TF_TEST_BOM_VAR"), "ok")
        self.assertEqual(os.environ.get("TF_TEST_QUOTED"), "abc")


class DemoModeTests(ATSTestCase):
    def test_demo_accounts_created_with_roles_and_fresh_passwords(self):
        out = io.StringIO()
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "ids.txt"
            call_command("demo_accounts", "--file", str(target), stdout=out)
            first = {u.username: u for u in User.objects.filter(username__startswith="demo_")}
            self.assertEqual({k: v.role for k, v in first.items()}, {"demo_rh": "hr_manager", "demo_recruteur": "recruiter", "demo_observateur": "observer"})
            self.assertIn("demo_rh", target.read_text(encoding="utf-8"))
            pwd = out.getvalue().split("demo_rh")[1].split("mot de passe :")[1].split()[0]
            self.assertTrue(User.objects.get(username="demo_rh").check_password(pwd))
            self.assertFalse(User.objects.filter(username__startswith="demo_", role="admin").exists())
            call_command("demo_accounts", stdout=io.StringIO())
            self.assertFalse(User.objects.get(username="demo_rh").check_password(pwd))  # mot de passe renouvelé

    def test_banner_only_in_demo_mode(self):
        self.assertNotContains(self.client.get(reverse("login")), "Mode démonstration")
        with self.settings(DEMO_MODE=True):
            self.assertContains(self.client.get(reverse("login")), "Mode démonstration")
            self.login("recruiter")
            self.assertContains(self.client.get(reverse("dashboard")), "aucune information réelle")
