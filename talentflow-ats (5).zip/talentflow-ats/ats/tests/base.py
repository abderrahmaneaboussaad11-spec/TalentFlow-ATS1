import shutil
import tempfile
from decimal import Decimal

from django.test import TestCase, override_settings

from accounts.models import User
from ats.models import Candidate, Job, Skill
from ats.services import scoring

_TMP_MEDIA = tempfile.mkdtemp(prefix="tf-test-media-")


def make_user(role, username=None):
    return User.objects.create_user(username=username or f"u_{role}", password="Str0ng-pass-123!", role=role, email=f"{role}@example.test")


def make_job(**kw):
    defaults = dict(title="Poste test", description="Description", required_education_level=3, required_education_field="marketing, communication",
                    min_experience_years=Decimal("1"), required_languages="Français, Anglais", status=Job.Status.PUBLISHED)
    defaults.update(kw)
    job = Job.objects.create(**defaults)
    job.required_skills.set([Skill.get_or_create_ci(s) for s in ["SEO", "Excel"]])
    scoring.create_default_criteria(job)
    return job


def make_candidate(**kw):
    n = Candidate.objects.count() + 1
    skills = kw.pop("skills", [])
    defaults = dict(first_name="Test", last_name=f"Candidat{n}", email=f"c{n}@example.test")
    defaults.update(kw)
    cand = Candidate.objects.create(**defaults)
    cand.skills.set([Skill.get_or_create_ci(s) for s in skills])
    return cand


@override_settings(PRIVATE_MEDIA_ROOT=_TMP_MEDIA)
class ATSTestCase(TestCase):
    def setUp(self):
        from django.core.cache import cache
        cache.clear()
        super().setUp()

    def login(self, role):
        user = make_user(role)
        self.client.force_login(user)
        return user
