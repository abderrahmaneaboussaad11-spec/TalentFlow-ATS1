from datetime import timedelta
from decimal import Decimal

from django.urls import reverse
from django.utils import timezone

from accounts.models import User
from ats.models import (Application, AuditEvent, Candidate, EvaluationCriterion, Interview, Job, PipelineStage,
                        StageHistory)
from ats.services import analytics, pipeline, scoring

from .base import ATSTestCase, make_candidate, make_job, make_user


class AuthPermissionTests(ATSTestCase):
    def test_anonymous_redirected_to_login(self):
        for name in ("dashboard", "job_list", "candidate_list", "pipeline", "interview_list", "analytics"):
            r = self.client.get(reverse(name))
            self.assertEqual(r.status_code, 302, name)
            self.assertIn(reverse("login"), r["Location"])

    def test_login_and_logout(self):
        make_user("recruiter", "alice")
        r = self.client.post(reverse("login"), {"username": "alice", "password": "Str0ng-pass-123!"})
        self.assertRedirects(r, reverse("dashboard"))
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)
        self.client.post(reverse("logout"))
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 302)

    def test_wrong_password_shows_french_error(self):
        make_user("recruiter", "alice")
        r = self.client.post(reverse("login"), {"username": "alice", "password": "nope"})
        self.assertContains(r, "Identifiant ou mot de passe incorrect")

    def test_logout_requires_post(self):
        self.login("recruiter")
        self.assertEqual(self.client.get(reverse("logout")).status_code, 405)

    def test_observer_is_read_only(self):
        self.login("observer")
        job, cand = make_job(), make_candidate()
        app = pipeline.create_application(cand, job)
        self.assertEqual(self.client.get(reverse("job_list")).status_code, 200)
        self.assertEqual(self.client.get(reverse("job_create")).status_code, 403)
        self.assertEqual(self.client.post(reverse("job_status", args=[job.pk, "close"])).status_code, 403)
        self.assertEqual(self.client.get(reverse("candidate_list")).status_code, 403)
        self.assertEqual(self.client.get(reverse("candidate_detail", args=[cand.pk])).status_code, 403)
        self.assertEqual(self.client.get(reverse("application_detail", args=[app.pk])).status_code, 403)
        self.assertEqual(self.client.post(reverse("application_move", args=[app.pk]), {"stage": app.stage_id}).status_code, 403)
        self.assertEqual(self.client.get(reverse("interview_list")).status_code, 403)
        self.assertEqual(self.client.get(reverse("job_ranking", args=[job.pk]) + "?export=csv").status_code, 403)

    def test_recruiter_cannot_manage_settings_users_or_delete(self):
        self.login("recruiter")
        job = make_job()
        for name in ("settings_company", "settings_stages", "user_list", "audit_log"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 403, name)
        self.assertEqual(self.client.post(reverse("job_delete", args=[job.pk])).status_code, 403)
        self.assertEqual(self.client.get(reverse("job_criteria", args=[job.pk])).status_code, 403)

    def test_hr_manager_cannot_manage_users_but_admin_can(self):
        self.login("hr_manager")
        self.assertEqual(self.client.get(reverse("settings_company")).status_code, 200)
        self.assertEqual(self.client.get(reverse("user_list")).status_code, 403)
        self.client.logout()
        make_user("admin", "boss")
        self.client.login(username="boss", password="Str0ng-pass-123!")
        self.assertEqual(self.client.get(reverse("user_list")).status_code, 200)

    def test_superuser_gets_admin_role(self):
        su = User.objects.create_superuser("root", "r@example.test", "Str0ng-pass-123!")
        self.assertEqual(su.role, "admin")

    def test_403_page_is_friendly(self):
        self.login("observer")
        r = self.client.get(reverse("job_create"))
        self.assertContains(r, "Accès refusé", status_code=403)

    def test_observer_nav_hides_private_links(self):
        self.login("observer")
        r = self.client.get(reverse("dashboard"))
        self.assertNotContains(r, reverse("candidate_list"))


class JobTests(ATSTestCase):
    def payload(self, **kw):
        d = {"title": "Chargé de test", "location": "Casablanca", "contract_type": "cdi", "description": "Desc", "min_experience_years": "1",
             "required_skills_text": "SEO, Excel", "required_education_level": "3", "required_languages": "Français"}
        d.update(kw)
        return d

    def test_create_edit_publish_close_archive_delete(self):
        self.login("hr_manager")
        r = self.client.post(reverse("job_create"), self.payload(new_department="Marketing"))
        job = Job.objects.get()
        self.assertRedirects(r, reverse("job_detail", args=[job.pk]))
        self.assertEqual(job.status, "draft")
        self.assertEqual(job.criteria.count(), 5)
        self.assertEqual(job.department.name, "Marketing")
        self.assertEqual(job.required_skills.count(), 2)
        self.client.post(reverse("job_edit", args=[job.pk]), self.payload(title="Titre modifié", required_skills_text="SEO"))
        job.refresh_from_db()
        self.assertEqual(job.title, "Titre modifié")
        self.assertEqual(job.required_skills.count(), 1)
        for action, status in (("publish", "published"), ("close", "closed"), ("archive", "archived")):
            self.client.post(reverse("job_status", args=[job.pk, action]))
            job.refresh_from_db()
            self.assertEqual(job.status, status)
        self.client.post(reverse("job_delete", args=[job.pk]))
        self.assertFalse(Job.objects.exists())

    def test_validation_errors(self):
        self.login("recruiter")
        r = self.client.post(reverse("job_create"), self.payload(title="", min_experience_years="-3"))
        self.assertEqual(Job.objects.count(), 0)
        self.assertContains(r, "Ce champ est obligatoire")
        r = self.client.post(reverse("job_create"), self.payload(deadline="2001-01-01"))
        self.assertContains(r, "ne peut pas être dans le passé")

    def test_cannot_delete_job_with_applications(self):
        self.login("admin")
        job = make_job()
        pipeline.create_application(make_candidate(), job)
        self.client.post(reverse("job_delete", args=[job.pk]))
        self.assertTrue(Job.objects.filter(pk=job.pk).exists())

    def test_search_and_filter(self):
        self.login("recruiter")
        make_job(title="Développeur Django")
        make_job(title="Comptable", status="draft")
        self.assertContains(self.client.get(reverse("job_list"), {"q": "django"}), "Développeur Django")
        r = self.client.get(reverse("job_list"), {"q": "django"})
        self.assertNotContains(r, "Comptable")
        r = self.client.get(reverse("job_list"), {"status": "draft"})
        self.assertContains(r, "Comptable")
        self.assertNotContains(r, "Développeur Django")

    def test_criteria_weights_must_total_100(self):
        self.login("hr_manager")
        job = make_job()
        crits = list(job.criteria.all())
        data = {"form-TOTAL_FORMS": len(crits) + 1, "form-INITIAL_FORMS": len(crits), "form-MIN_NUM_FORMS": 0, "form-MAX_NUM_FORMS": 1000}
        for i, c in enumerate(crits):
            data.update({f"form-{i}-id": c.pk, f"form-{i}-kind": c.kind, f"form-{i}-name": c.name, f"form-{i}-weight": c.weight})
        data[f"form-0-weight"] = 30  # total = 110
        data.update({f"form-{len(crits)}-kind": "", f"form-{len(crits)}-name": "", f"form-{len(crits)}-weight": ""})
        r = self.client.post(reverse("job_criteria", args=[job.pk]), data)
        self.assertContains(r, "égal à 100 points")
        data["form-0-weight"] = 20
        r = self.client.post(reverse("job_criteria", args=[job.pk]), data)
        self.assertRedirects(r, reverse("job_detail", args=[job.pk]))


class CandidateTests(ATSTestCase):
    def payload(self, **kw):
        d = {"first_name": "Salma", "last_name": "Test", "email": "salma@example.test", "source": "website", "skills_text": "SEO, seo, Excel"}
        d.update(kw)
        return d

    def test_create_edit_and_skills_dedup(self):
        self.login("recruiter")
        r = self.client.post(reverse("candidate_create"), self.payload())
        c = Candidate.objects.get()
        self.assertRedirects(r, reverse("candidate_detail", args=[c.pk]))
        self.assertEqual(c.skills.count(), 2)
        self.client.post(reverse("candidate_edit", args=[c.pk]), self.payload(city="Rabat", years_experience="2.5"))
        c.refresh_from_db()
        self.assertEqual((c.city, c.years_experience), ("Rabat", Decimal("2.5")))

    def test_duplicate_email_blocked_case_insensitively(self):
        self.login("recruiter")
        self.client.post(reverse("candidate_create"), self.payload())
        r = self.client.post(reverse("candidate_create"), self.payload(first_name="Autre", email="SALMA@example.test"))
        self.assertContains(r, "existe déjà")
        self.assertEqual(Candidate.objects.count(), 1)

    def test_unknown_values_stay_unknown(self):
        self.login("recruiter")
        self.client.post(reverse("candidate_create"), self.payload())
        c = Candidate.objects.get()
        self.assertIsNone(c.education_level)
        self.assertIsNone(c.years_experience)
        self.assertContains(self.client.get(reverse("candidate_detail", args=[c.pk])), "non documentée")

    def test_search_filter_sort_pagination(self):
        self.login("recruiter")
        job = make_job()
        for i in range(17):
            make_candidate(first_name=f"Prenom{i}", last_name=f"Nom{i:02d}", years_experience=Decimal(i), skills=["Python"] if i % 2 else ["SEO"])
        r = self.client.get(reverse("candidate_list"))
        self.assertEqual(len(r.context["page"]), 15)
        r = self.client.get(reverse("candidate_list"), {"page": 2})
        self.assertEqual(len(r.context["page"]), 2)
        self.assertEqual(len(self.client.get(reverse("candidate_list"), {"skill": "python"}).context["page"]), 8)
        self.assertEqual(len(self.client.get(reverse("candidate_list"), {"min_exp": "15"}).context["page"]), 2)
        self.assertEqual(len(self.client.get(reverse("candidate_list"), {"q": "Prenom3"}).context["page"]), 1)
        r = self.client.get(reverse("candidate_list"), {"sort": "experience"})
        self.assertEqual(r.context["page"][0].last_name, "Nom16")
        pipeline.create_application(Candidate.objects.get(last_name="Nom01"), job)
        self.assertEqual(len(self.client.get(reverse("candidate_list"), {"job": job.pk}).context["page"]), 1)

    def test_csv_export_respects_filters_and_neutralizes_formulas(self):
        self.login("recruiter")
        make_candidate(first_name="=HYPERLINK(1)", last_name="Zed", email="z@example.test", skills=["Python"])
        make_candidate(first_name="Autre", last_name="Perso", email="p@example.test")
        r = self.client.get(reverse("candidate_list"), {"skill": "python", "export": "csv"})
        body = r.content.decode("utf-8")
        self.assertIn("text/csv", r["Content-Type"])
        self.assertIn("'=HYPERLINK(1)", body)
        self.assertNotIn("Perso", body)
        self.assertTrue(AuditEvent.objects.filter(action="export.candidates").exists())

    def test_observer_cannot_export(self):
        self.login("observer")
        self.assertEqual(self.client.get(reverse("candidate_list"), {"export": "csv"}).status_code, 403)

    def test_delete_blocked_with_active_application_and_allowed_when_closed(self):
        self.login("hr_manager")
        c, job = make_candidate(), make_job()
        app = pipeline.create_application(c, job)
        self.client.post(reverse("candidate_delete", args=[c.pk]))
        self.assertTrue(Candidate.objects.filter(pk=c.pk).exists())
        pipeline.move_application(app, PipelineStage.objects.get(kind="withdrawn"), None)
        self.client.post(reverse("candidate_delete", args=[c.pk]))
        self.assertFalse(Candidate.objects.filter(pk=c.pk).exists())

    def test_apply_creates_application_with_history(self):
        self.login("recruiter")
        c, job = make_candidate(), make_job()
        self.client.post(reverse("candidate_apply", args=[c.pk]), {"job": job.pk})
        app = Application.objects.get()
        self.assertEqual(app.stage.kind, "new")
        self.assertEqual(app.history.count(), 1)
        self.client.post(reverse("candidate_apply", args=[c.pk]), {"job": job.pk})  # doublon
        self.assertEqual(Application.objects.count(), 1)

    def test_apply_refused_after_deadline(self):
        self.login("recruiter")
        c = make_candidate()
        job = make_job(deadline=timezone.localdate() - timedelta(days=1))
        self.client.post(reverse("candidate_apply", args=[c.pk]), {"job": job.pk})
        self.assertEqual(Application.objects.count(), 0)


class PipelineTests(ATSTestCase):
    def setUp(self):
        self.job, self.cand = make_job(), make_candidate()
        self.app = pipeline.create_application(self.cand, self.job)

    def stage(self, kind):
        return PipelineStage.objects.get(kind=kind)

    def test_move_records_history_with_user_and_updates_views(self):
        user = self.login("recruiter")
        self.client.post(reverse("application_move", args=[self.app.pk]), {"stage": self.stage("screening").pk, "comment": "Profil solide"})
        self.app.refresh_from_db()
        self.assertEqual(self.app.stage.kind, "screening")
        h = self.app.history.first()
        self.assertEqual((h.changed_by, h.comment, h.from_stage.kind), (user, "Profil solide", "new"))
        self.assertContains(self.client.get(reverse("application_detail", args=[self.app.pk])), "Présélection")
        self.assertContains(self.client.get(reverse("pipeline")), self.cand.last_name)
        self.assertEqual(self.client.get(reverse("pipeline"), {"job": self.job.pk}).status_code, 200)

    def test_rejection_requires_justification(self):
        self.login("recruiter")
        self.client.post(reverse("application_move", args=[self.app.pk]), {"stage": self.stage("rejected").pk})
        self.app.refresh_from_db()
        self.assertEqual(self.app.stage.kind, "new")
        self.client.post(reverse("application_move", args=[self.app.pk]), {"stage": self.stage("rejected").pk, "comment": "Poste pourvu en interne"})
        self.app.refresh_from_db()
        self.assertEqual(self.app.stage.kind, "rejected")

    def test_json_move_for_kanban(self):
        self.login("recruiter")
        r = self.client.post(reverse("application_move_json", args=[self.app.pk]), '{"stage": %d}' % self.stage("interview").pk, content_type="application/json")
        self.assertEqual(r.json()["ok"], True)
        self.app.refresh_from_db()
        self.assertEqual(self.app.stage.kind, "interview")
        r = self.client.post(reverse("application_move_json", args=[self.app.pk]), '{"stage": 99999}', content_type="application/json")
        self.assertEqual(r.status_code, 400)
        r = self.client.post(reverse("application_move_json", args=[self.app.pk]), '{"stage": %d}' % self.stage("rejected").pk, content_type="application/json")
        self.assertEqual(r.status_code, 400)

    def test_observer_cannot_move_and_sees_no_names(self):
        self.login("observer")
        r = self.client.post(reverse("application_move_json", args=[self.app.pk]), '{"stage": 1}', content_type="application/json")
        self.assertEqual(r.status_code, 403)
        self.assertNotContains(self.client.get(reverse("pipeline")), self.cand.last_name)

    def test_evaluate_override_note_via_views(self):
        self.login("recruiter")
        self.client.post(reverse("application_evaluate", args=[self.app.pk]))
        res = self.app.results.get(criterion__kind="skills")
        r = self.client.post(reverse("result_override", args=[res.pk]), {"points": "30", "justification": ""})
        res.refresh_from_db()
        self.assertFalse(res.is_overridden)
        self.client.post(reverse("result_override", args=[res.pk]), {"points": "30", "justification": "Vu en entretien"})
        res.refresh_from_db()
        self.assertEqual(res.effective_points, Decimal("30.0"))
        self.assertTrue(AuditEvent.objects.filter(action="score.override").exists())
        self.client.post(reverse("application_note", args=[self.app.pk]), {"text": "Bon contact"})
        self.assertEqual(self.app.notes.count(), 1)
        self.assertContains(self.client.get(reverse("application_detail", args=[self.app.pk])), "Vu en entretien")

    def test_observer_does_not_see_notes_page(self):
        self.app.notes.create(text="Secret interne")
        self.login("observer")
        self.assertEqual(self.client.get(reverse("application_detail", args=[self.app.pk])).status_code, 403)

    def test_ranking_orders_descending_and_exports(self):
        self.login("recruiter")
        strong = make_candidate(education_level=4, education_field="Marketing", years_experience=Decimal("3"), skills=["SEO", "Excel"], languages="Français, Anglais")
        pipeline.create_application(strong, self.job)
        self.client.post(reverse("job_evaluate_all", args=[self.job.pk]))
        r = self.client.get(reverse("job_ranking", args=[self.job.pk]))
        ranked = r.context["ranked"]
        self.assertEqual([x["app"].candidate for x in ranked][0], strong)
        self.assertGreater(ranked[0]["total"], ranked[1]["total"])
        csv = self.client.get(reverse("job_ranking", args=[self.job.pk]), {"export": "csv"})
        self.assertIn(strong.last_name, csv.content.decode())


class InterviewTests(ATSTestCase):
    def setUp(self):
        self.user = self.login("recruiter")
        self.app = pipeline.create_application(make_candidate(), make_job())
        self.when = (timezone.now() + timedelta(days=3)).replace(second=0, microsecond=0)

    def payload(self, when=None, **kw):
        d = {"application": self.app.pk, "scheduled_at": timezone.localtime(when or self.when).strftime("%Y-%m-%dT%H:%M"), "duration_minutes": 45,
             "format": "video", "location": "https://meet.example.test/x", "interviewer": self.user.pk, "status": "planned"}
        d.update(kw)
        return d

    def test_schedule_list_and_feedback(self):
        r = self.client.post(reverse("interview_create"), self.payload())
        self.assertRedirects(r, reverse("application_detail", args=[self.app.pk]))
        iv = Interview.objects.get()
        self.assertContains(self.client.get(reverse("interview_list")), self.app.candidate.last_name)
        self.assertEqual(analytics.dashboard_kpis()["interviews_scheduled"], 1)
        self.client.post(reverse("interview_feedback", args=[iv.pk]), {"rating": 4, "recommendation": "yes", "strengths": "Bien"})
        iv.refresh_from_db()
        self.assertEqual(iv.status, "done")
        self.assertEqual(iv.feedback.rating, 4)

    def test_past_date_rejected(self):
        r = self.client.post(reverse("interview_create"), self.payload(when=timezone.now() - timedelta(days=1)))
        self.assertContains(r, "ne peut pas être fixé dans le passé")
        self.assertEqual(Interview.objects.count(), 0)

    def test_location_required_for_video(self):
        r = self.client.post(reverse("interview_create"), self.payload(location=""))
        self.assertContains(r, "Indiquez le lieu")

    def test_interviewer_conflict_detected(self):
        self.client.post(reverse("interview_create"), self.payload())
        other = pipeline.create_application(make_candidate(), make_job(title="Autre"))
        r = self.client.post(reverse("interview_create"), self.payload(when=self.when + timedelta(minutes=30), application=other.pk))
        self.assertContains(r, "Conflit")
        self.assertEqual(Interview.objects.count(), 1)
        r = self.client.post(reverse("interview_create"), self.payload(when=self.when + timedelta(minutes=45), application=other.pk))
        self.assertEqual(Interview.objects.count(), 2)

    def test_cancel_interview(self):
        self.client.post(reverse("interview_create"), self.payload())
        iv = Interview.objects.get()
        self.client.post(reverse("interview_status", args=[iv.pk, "cancelled"]))
        iv.refresh_from_db()
        self.assertEqual(iv.status, "cancelled")


class DashboardAndAnalyticsTests(ATSTestCase):
    def test_empty_state_without_fabricated_numbers(self):
        self.login("recruiter")
        r = self.client.get(reverse("dashboard"))
        self.assertContains(r, "Aucune candidature pour le moment")
        self.assertEqual(r.context["kpis"]["applications"], 0)
        self.assertContains(self.client.get(reverse("analytics")), "Données insuffisantes")
        self.assertIsNone(analytics.time_to_hire())
        self.assertIsNone(analytics.conversion_rates()["hired"])

    def test_aggregation_matches_database(self):
        self.login("recruiter")
        job = make_job()
        stages = {s.kind: s for s in PipelineStage.objects.all()}
        apps = [pipeline.create_application(make_candidate(), job) for _ in range(4)]
        pipeline.move_application(apps[0], stages["interview"], None)
        pipeline.move_application(apps[1], stages["interview"], None)
        pipeline.move_application(apps[1], stages["hired"], None)
        k = analytics.dashboard_kpis()
        self.assertEqual((k["applications"], k["active_jobs"], k["hired"], k["under_review"]), (4, 1, 1, 2))
        conv = analytics.conversion_rates()
        self.assertEqual((conv["interview"], conv["hired"]), (50.0, 25.0))
        self.assertEqual(analytics.time_to_hire()["count"], 1)
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.context["stage_chart"]["datasets"][0]["data"][0], 2)  # 2 encore à "Nouvelle candidature"
        self.assertEqual(analytics.applications_per_job()["datasets"][0]["data"], [4])
        funnel = dict(zip(analytics.funnel()["labels"], analytics.funnel()["datasets"][0]["data"]))
        self.assertEqual(funnel["Entretien"], 2)
        self.assertEqual(sum(analytics.weekly_series()["datasets"][0]["data"]), 4)
        self.assertContains(self.client.get(reverse("analytics")), "Entonnoir")

    def test_global_search(self):
        self.login("recruiter")
        make_candidate(first_name="Zorro", last_name="Unique")
        make_job(title="Poste Zorro")
        r = self.client.get(reverse("search"), {"q": "zorro"})
        self.assertContains(r, "Unique")
        self.assertContains(r, "Poste Zorro")


class SettingsTests(ATSTestCase):
    def test_company_and_stage_management(self):
        self.login("hr_manager")
        self.client.post(reverse("settings_company"), {"name": "ACME RH", "retention_months": 12})
        from ats.models import CompanyProfile
        self.assertEqual(CompanyProfile.get().name, "ACME RH")
        r = self.client.post(reverse("settings_company"), {"name": "ACME RH", "retention_months": 0})
        self.assertContains(r, "comprise entre 1 et 120")
        self.client.post(reverse("settings_stages"), {"name": "Test technique", "kind": "evaluation", "order": 9, "color": "#112233"})
        stage = PipelineStage.objects.get(name="Test technique")
        self.client.post(reverse("stage_delete", args=[stage.pk]))
        self.assertFalse(PipelineStage.objects.filter(name="Test technique").exists())
        used = PipelineStage.objects.get(kind="new")
        pipeline.create_application(make_candidate(), make_job())
        self.client.post(reverse("stage_delete", args=[used.pk]))
        self.assertTrue(PipelineStage.objects.filter(pk=used.pk).exists())

    def test_admin_creates_user_and_cannot_lock_self_out(self):
        admin = make_user("admin", "boss")
        self.client.force_login(admin)
        r = self.client.post(reverse("user_create"), {"username": "newbie", "first_name": "N", "last_name": "B", "email": "n@example.test", "role": "recruiter", "password1": "Compl3x-Pass-987!", "password2": "Compl3x-Pass-987!"})
        self.assertEqual(User.objects.get(username="newbie").role, "recruiter")
        r = self.client.post(reverse("user_edit", args=[admin.pk]), {"first_name": "", "last_name": "", "email": "a@example.test", "role": "observer", "is_active": "on"})
        self.assertContains(r, "ne pouvez pas")
        admin.refresh_from_db()
        self.assertEqual(admin.role, "admin")

    def test_weak_password_rejected(self):
        admin = make_user("admin", "boss")
        self.client.force_login(admin)
        r = self.client.post(reverse("user_create"), {"username": "weak", "email": "w@example.test", "role": "observer", "password1": "123", "password2": "123"})
        self.assertFalse(User.objects.filter(username="weak").exists())


class DemoCommandTests(ATSTestCase):
    def test_seed_and_reset_only_touch_demo_data(self):
        from django.core.management import call_command
        real = make_candidate(first_name="Vrai", last_name="Dossier")
        real_job = make_job(title="Vraie offre")
        call_command("seed_demo", "--candidates", "8", verbosity=0)
        self.assertEqual(Candidate.objects.filter(is_demo=True).count(), 8)
        self.assertTrue(Application.objects.exists())
        call_command("seed_demo", "--only-reset", verbosity=0)
        self.assertFalse(Candidate.objects.filter(is_demo=True).exists())
        self.assertTrue(Candidate.objects.filter(pk=real.pk).exists())
        self.assertTrue(Job.objects.filter(pk=real_job.pk).exists())
