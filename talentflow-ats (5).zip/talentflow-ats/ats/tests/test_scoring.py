from decimal import Decimal

from django.test import TestCase

from ats.models import EvaluationCriterion, EvaluationResult
from ats.services import pipeline, scoring

from .base import make_candidate, make_job


class ScoringRulesTests(TestCase):
    def setUp(self):
        pipeline.ensure_default_stages()
        self.job = make_job(min_experience_years=Decimal("2"))

    def evaluate(self, cand):
        app = pipeline.create_application(cand, self.job)
        scoring.evaluate_application(app)
        return app, {r.criterion.kind: r for r in app.results.select_related("criterion")}

    def test_default_weights_total_100(self):
        self.assertEqual(sum(c.weight for c in self.job.criteria.all()), 100)

    def test_perfect_candidate_gets_100(self):
        cand = make_candidate(education_level=4, education_field="Marketing digital", years_experience=Decimal("3"), languages="Français (courant), Anglais (B2)", skills=["SEO", "Excel"])
        from ats.models import Qualification
        Qualification.objects.create(candidate=cand, kind="certification", title="Google Analytics")
        app, _ = self.evaluate(cand)
        self.assertEqual(scoring.summarize(app)["total"], Decimal("100"))

    def test_empty_candidate_scores_zero_and_everything_unverified(self):
        app, res = self.evaluate(make_candidate())
        s = scoring.summarize(app)
        self.assertEqual(s["total"], Decimal("0"))
        self.assertEqual(res["education"].status, EvaluationResult.Status.UNVERIFIED)
        self.assertEqual(res["experience"].status, EvaluationResult.Status.UNVERIFIED)
        self.assertEqual(s["unverified"], 5)

    def test_missing_skill_is_not_called_absent(self):
        _, res = self.evaluate(make_candidate(skills=["SEO"]))
        self.assertEqual(res["skills"].auto_points, Decimal("20.0"))
        self.assertIn("absence de mention", res["skills"].evidence)
        self.assertEqual(res["skills"].status, EvaluationResult.Status.PARTIAL)

    def test_experience_boundaries(self):
        # minimum requis : 2 ans -> 2.0 = 100 %, 1.0 = 50 %, 0.9 = 0
        for years, expected in [("2", "20.0"), ("2.5", "20.0"), ("1", "10.0"), ("1.9", "10.0"), ("0.9", "0.0")]:
            job = make_job(title=f"Poste {years}", min_experience_years=Decimal("2"))
            cand = make_candidate(years_experience=Decimal(years))
            app = pipeline.create_application(cand, job)
            scoring.evaluate_application(app)
            res = app.results.get(criterion__kind="experience")
            self.assertEqual(res.auto_points, Decimal(expected), years)

    def test_education_level_and_field(self):
        _, res = self.evaluate(make_candidate(education_level=3, education_field="Marketing"))
        self.assertEqual(res["education"].auto_points, Decimal("20.0"))
        _, res = self.evaluate(make_candidate(education_level=3, education_field="Droit"))
        self.assertEqual(res["education"].auto_points, Decimal("0.0"))
        self.assertEqual(res["education"].status, EvaluationResult.Status.VERIFIED)
        _, res = self.evaluate(make_candidate(education_level=1, education_field="Marketing"))
        self.assertEqual(res["education"].auto_points, Decimal("0.0"))

    def test_score_never_exceeds_max_or_goes_below_zero(self):
        app, res = self.evaluate(make_candidate())
        with self.assertRaises(ValueError):
            scoring.apply_override(res["skills"], 41, "trop", None)
        with self.assertRaises(ValueError):
            scoring.apply_override(res["skills"], -1, "négatif", None)
        self.assertEqual(scoring.clamp(Decimal("150"), 40), Decimal("40"))
        self.assertEqual(scoring.clamp(Decimal("-5"), 40), Decimal("0"))

    def test_override_requires_justification_and_survives_reevaluation(self):
        app, res = self.evaluate(make_candidate())
        with self.assertRaises(ValueError):
            scoring.apply_override(res["skills"], 20, "   ", None)
        scoring.apply_override(res["skills"], 25, "Compétences vues en entretien", None)
        scoring.evaluate_application(app)
        r = app.results.get(criterion__kind="skills")
        self.assertEqual(r.effective_points, Decimal("25.0"))
        self.assertEqual(r.auto_points, Decimal("0.0"))
        self.assertTrue(r.is_overridden)

    def test_validate_weights(self):
        self.assertIsNone(scoring.validate_weights([20, 20, 40, 10, 10]))
        self.assertIn("100", scoring.validate_weights([50, 40]))
        self.assertIsNotNone(scoring.validate_weights([100, 0]))

    def test_custom_criterion_is_manual(self):
        EvaluationCriterion.objects.filter(job=self.job, kind="certifications").update(kind="custom", name="Test pratique")
        _, res = self.evaluate(make_candidate())
        self.assertEqual(res["custom"].status, EvaluationResult.Status.MANUAL)
        self.assertEqual(res["custom"].auto_points, Decimal("0"))

    def test_score_never_changes_stage_automatically(self):
        app, _ = self.evaluate(make_candidate())
        app.refresh_from_db()
        self.assertEqual(app.stage.kind, "new")
