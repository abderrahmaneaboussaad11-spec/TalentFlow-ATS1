from django.db import transaction
from django.utils import timezone

from ..models import Application, PipelineStage, StageHistory
from . import audit

DEFAULT_STAGES = [
    ("Nouvelle candidature", PipelineStage.Kind.NEW, "#64748b"),
    ("Présélection", PipelineStage.Kind.SCREENING, "#0ea5e9"),
    ("Entretien", PipelineStage.Kind.INTERVIEW, "#8b5cf6"),
    ("Évaluation complémentaire", PipelineStage.Kind.EVALUATION, "#f59e0b"),
    ("Offre envoyée", PipelineStage.Kind.OFFER, "#14b8a6"),
    ("Recruté", PipelineStage.Kind.HIRED, "#10b981"),
    ("Refusé", PipelineStage.Kind.REJECTED, "#ef4444"),
    ("Retiré du processus", PipelineStage.Kind.WITHDRAWN, "#94a3b8"),
]


def ensure_default_stages():
    if PipelineStage.objects.exists():
        return
    for i, (name, kind, color) in enumerate(DEFAULT_STAGES, start=1):
        PipelineStage.objects.create(name=name, kind=kind, color=color, order=i)


def first_stage():
    ensure_default_stages()
    return PipelineStage.objects.filter(kind=PipelineStage.Kind.NEW).first() or PipelineStage.objects.first()


@transaction.atomic
def create_application(candidate, job, user=None, applied_at=None):
    """Crée une candidature à l'étape initiale et ouvre son historique."""
    stage = first_stage()
    when = applied_at or timezone.now()
    app = Application.objects.create(candidate=candidate, job=job, stage=stage, applied_at=when, last_activity=when)
    StageHistory.objects.create(application=app, from_stage=None, to_stage=stage, changed_by=user, comment="Candidature enregistrée", changed_at=when)
    audit.log(user, "application.create", f"Candidature #{app.pk}", f"Offre #{job.pk}")
    return app


@transaction.atomic
def move_application(app, stage, user, comment=""):
    """Change l'étape d'une candidature, historise et trace la décision (jamais automatique)."""
    if app.stage_id == stage.pk:
        return False
    previous = app.stage
    app.stage = stage
    app.last_activity = timezone.now()
    app.save(update_fields=["stage", "last_activity"])
    StageHistory.objects.create(application=app, from_stage=previous, to_stage=stage, changed_by=user, comment=comment[:300])
    audit.log(user, "application.stage", f"Candidature #{app.pk}", f"{previous.name} → {stage.name}")
    return True
