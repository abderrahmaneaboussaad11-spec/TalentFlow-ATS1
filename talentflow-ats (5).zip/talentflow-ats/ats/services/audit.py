from ..models import AuditEvent


def log(user, action, target="", details=""):
    """Enregistre un événement d'audit. Ne jamais y mettre de données personnelles superflues."""
    AuditEvent.objects.create(
        user=user if getattr(user, "is_authenticated", False) else None,
        action=action[:60], target=str(target)[:200], details=str(details)[:300],
    )
