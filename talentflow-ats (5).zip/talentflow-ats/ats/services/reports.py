"""Rapports PDF (ReportLab). Les chiffres viennent des mêmes services que l'écran : rien n'est inventé."""
import io
from datetime import datetime

from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from . import analytics

GREEN = colors.HexColor("#047857")
LIGHT = colors.HexColor("#ecfdf5")


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=base["Title"], textColor=GREEN, alignment=0, fontSize=20, spaceAfter=4),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], textColor=GREEN, spaceBefore=14, spaceAfter=6),
        "body": ParagraphStyle("b", parent=base["BodyText"], fontSize=9.5, leading=13),
        "small": ParagraphStyle("s", parent=base["BodyText"], fontSize=8, textColor=colors.HexColor("#6b7280")),
        "note": ParagraphStyle("n", parent=base["BodyText"], fontSize=9, backColor=LIGHT, borderPadding=6, leading=12),
    }


def _table(data, widths):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GREEN), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d1d5db")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f9fafb")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def _build(story_fn, title):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm, title=title, author="TalentFlow ATS")
    st = _styles()
    story = [Paragraph(title, st["title"]), Paragraph(f"Généré le {timezone.localtime():%d/%m/%Y à %H:%M}", st["small"]), Spacer(1, 10)]
    story += story_fn(st)

    def footer(canvas, d):
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#6b7280"))
        canvas.drawString(2 * cm, 1 * cm, "TalentFlow ATS - document confidentiel, contient des données personnelles")
        canvas.drawRightString(A4[0] - 2 * cm, 1 * cm, f"Page {d.page}")

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


def analytics_pdf():
    def story(st):
        k, conv, tth = analytics.dashboard_kpis(), analytics.conversion_rates(), analytics.time_to_hire()
        pct = lambda v: "n/d" if v is None else f"{v} %"
        out = [Paragraph("Indicateurs clés", st["h2"]), _table([
            ["Indicateur", "Valeur"], ["Offres actives", k["active_jobs"]], ["Candidats", k["candidates"]], ["Candidatures", k["applications"]],
            ["En cours d'examen", k["under_review"]], ["Entretiens à venir", k["interviews_scheduled"]], ["Offres envoyées", k["offers"]], ["Recrutements", k["hired"]],
            ["Passage à l'entretien", pct(conv["interview"])], ["Passage à l'offre", pct(conv["offer"])], ["Taux de recrutement", pct(conv["hired"])],
            ["Délai moyen de recrutement", f"{tth['average_days']} jours ({tth['count']} recrutement(s))" if tth else "indisponible (aucun recrutement)"],
        ], [9 * cm, 8 * cm])]
        for title, chart in (("Entonnoir de recrutement", analytics.funnel()), ("Répartition par étape actuelle", analytics.stage_distribution()),
                             ("Candidatures par offre", analytics.applications_per_job()), ("Sources de candidature", analytics.source_distribution())):
            rows = [["Libellé", "Nombre"]] + [[l, v] for l, v in zip(chart["labels"], chart["datasets"][0]["data"])]
            out += [Paragraph(title, st["h2"]), _table(rows, [12 * cm, 5 * cm]) if len(rows) > 1 else Paragraph("Aucune donnée.", st["body"])]
        out += [Spacer(1, 12), Paragraph("Tous les chiffres proviennent des données enregistrées. « n/d » : non disponible faute de données.", st["small"])]
        return out
    return _build(story, "Rapport de recrutement")


def ranking_pdf(job, ranked, shortlist):
    def story(st):
        out = [Paragraph(f"Offre : {job.title}", st["h2"]),
               Paragraph("Ce classement est une aide à la décision. Une information absente du dossier n'est pas une preuve d'incompétence ; aucune candidature n'est refusée automatiquement.", st["note"]), Spacer(1, 8)]
        rows = [["Rang", "Candidat", "Étape", "Score", "À vérifier"]]
        for i, r in enumerate(ranked, 1):
            rows.append([i, r["app"].candidate.full_name, r["app"].stage.name, f"{r['total']} / {r['max']}", r["unverified"] or "-"])
        out.append(_table(rows, [1.4 * cm, 6 * cm, 4.6 * cm, 2.8 * cm, 2.2 * cm]) if len(rows) > 1 else Paragraph("Aucune candidature évaluée.", st["body"]))
        if shortlist["tie"]:
            names = ", ".join(r["app"].candidate.full_name for r in shortlist["tied"])
            out += [Spacer(1, 10), Paragraph(f"<b>Égalité au seuil ({shortlist['cutoff']} points)</b> entre : {names}. Aucun départage automatique : le choix final doit être justifié par écrit.", st["note"])]
        return out
    return _build(story, "Classement des candidatures")
