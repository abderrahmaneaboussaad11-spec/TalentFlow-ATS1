"""Espace de démonstration isolé : réinitialisation complète (réservée au mode démo)."""
from django.conf import settings
from django.core.management import call_command

from ..models import (AuditEvent, Candidate, CompanyProfile, CVDocument, Department, Job, PipelineStage, Skill)
from . import pipeline


def reset_demo_workspace():
    """Efface TOUTES les données métier puis recharge le jeu fictif. Refusé hors mode démo."""
    if not settings.DEMO_MODE:
        raise PermissionError("La réinitialisation n'est autorisée qu'en mode démonstration.")
    for doc in CVDocument.objects.all():
        doc.file.delete(save=False)
    Candidate.objects.all().delete()   # supprime aussi candidatures, notes, entretiens, résultats
    Job.objects.all().delete()
    PipelineStage.objects.all().delete()
    Department.objects.all().delete()
    Skill.objects.all().delete()
    AuditEvent.objects.all().delete()
    CompanyProfile.objects.all().delete()
    pipeline.ensure_default_stages()
    CompanyProfile.get()
    call_command("seed_demo", verbosity=0)
