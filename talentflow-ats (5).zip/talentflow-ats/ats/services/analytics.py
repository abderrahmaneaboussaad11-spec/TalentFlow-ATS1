"""Calculs d'indicateurs à partir des données réellement enregistrées."""
from collections import OrderedDict
from datetime import timedelta

from django.db.models import Count, Min
from django.utils import timezone

from ..models import Application, Interview, Job, PipelineStage, StageHistory, Candidate


def _week_start(dt):
    d = timezone.localtime(dt).date() if hasattr(dt, "hour") else dt
    return d - timedelta(days=d.weekday())


def weekly_series(weeks=12):
    today = timezone.localdate()
    first = today - timedelta(days=today.weekday()) - timedelta(weeks=weeks - 1)
    buckets = OrderedDict((first + timedelta(weeks=i), [0, 0]) for i in range(weeks))
    since = timezone.make_aware(timezone.datetime.combine(first, timezone.datetime.min.time()))
    for dt in Application.objects.filter(applied_at__gte=since).values_list("applied_at", flat=True):
        k = _week_start(dt)
        if k in buckets:
            buckets[k][0] += 1
    for dt in StageHistory.objects.filter(changed_at__gte=since, from_stage__isnull=False).values_list("changed_at", flat=True):
        k = _week_start(dt)
        if k in buckets:
            buckets[k][1] += 1
    return {
        "labels": [k.strftime("%d/%m") for k in buckets],
        "datasets": [
            {"label": "Candidatures reçues", "data": [v[0] for v in buckets.values()]},
            {"label": "Changements d'étape", "data": [v[1] for v in buckets.values()]},
        ],
    }


def stage_distribution():
    rows = PipelineStage.objects.annotate(n=Count("applications")).order_by("order")
    return {"labels": [r.name for r in rows], "colors": [r.color for r in rows], "datasets": [{"label": "Candidatures", "data": [r.n for r in rows]}]}


def applications_per_job(limit=10):
    rows = Job.objects.annotate(n=Count("applications")).filter(n__gt=0).order_by("-n")[:limit]
    return {"labels": [r.title for r in rows], "datasets": [{"label": "Candidatures", "data": [r.n for r in rows]}]}


def funnel():
    """Nombre de candidatures ayant atteint chaque étape (d'après l'historique)."""
    rows = []
    for stage in PipelineStage.objects.order_by("order"):
        n = StageHistory.objects.filter(to_stage=stage).values("application").distinct().count()
        rows.append((stage.name, n))
    return {"labels": [r[0] for r in rows], "datasets": [{"label": "Candidatures ayant atteint l'étape", "data": [r[1] for r in rows]}]}


def source_distribution():
    labels = dict(Candidate.Source.choices)
    rows = Candidate.objects.values("source").annotate(n=Count("id")).order_by("-n")
    return {"labels": [labels.get(r["source"], r["source"]) for r in rows], "datasets": [{"label": "Candidats", "data": [r["n"] for r in rows]}]}


def time_to_hire():
    """Délai moyen (jours) entre dépôt et passage à une étape « Recruté » ; None si aucune donnée."""
    hired = StageHistory.objects.filter(to_stage__kind=PipelineStage.Kind.HIRED).values("application").annotate(t=Min("changed_at"))
    apps = {a.pk: a.applied_at for a in Application.objects.filter(pk__in=[h["application"] for h in hired])}
    days = [(h["t"] - apps[h["application"]]).total_seconds() / 86400 for h in hired if h["application"] in apps]
    if not days:
        return None
    return {"average_days": round(sum(days) / len(days), 1), "count": len(days)}


def conversion_rates():
    total = Application.objects.count()
    if not total:
        return {"total": 0, "interview": None, "offer": None, "hired": None}

    def reached(kind):
        return StageHistory.objects.filter(to_stage__kind=kind).values("application").distinct().count()

    def pct(n):
        return round(100 * n / total, 1)

    return {
        "total": total,
        "interview": pct(reached(PipelineStage.Kind.INTERVIEW)),
        "offer": pct(reached(PipelineStage.Kind.OFFER)),
        "hired": pct(reached(PipelineStage.Kind.HIRED)),
    }


def dashboard_kpis():
    K = PipelineStage.Kind
    now = timezone.now()
    return {
        "active_jobs": Job.objects.filter(status=Job.Status.PUBLISHED).count(),
        "applications": Application.objects.count(),
        "candidates": Candidate.objects.count(),
        "under_review": Application.objects.filter(stage__kind__in=[K.NEW, K.SCREENING, K.EVALUATION]).count(),
        "interviews_scheduled": Interview.objects.filter(status=Interview.Status.PLANNED, scheduled_at__gte=now).count(),
        "offers": Application.objects.filter(stage__kind=K.OFFER).count(),
        "hired": Application.objects.filter(stage__kind=K.HIRED).count(),
    }
