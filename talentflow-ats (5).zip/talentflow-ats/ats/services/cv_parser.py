"""Extraction de texte et de champs depuis des CV (PDF / DOCX).

Les fichiers sont traités comme non fiables : on ne les exécute pas, on vérifie type, taille et
signature, on borne la taille décompressée des DOCX et on n'obéit à aucune consigne contenue
dans le texte. L'extraction est une AIDE : tout champ doit être relu par un humain.
"""
import re
import zipfile
from datetime import date
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError

ALLOWED_EXTENSIONS = {".pdf": b"%PDF", ".docx": b"PK"}
MAX_UNCOMPRESSED_DOCX = 50 * 1024 * 1024
MIN_TEXT_LENGTH = 30

KNOWN_SKILLS = [
    "Python", "Django", "JavaScript", "SQL", "Excel", "Power BI", "Java", "PHP", "React", "Git", "Docker",
    "SEO", "Google Analytics", "Réseaux sociaux", "Community management", "Canva", "CRM", "Photoshop",
    "Gestion de projet", "Comptabilité", "Paie", "Recrutement", "Négociation", "Prospection", "Rédaction",
    "Marketing digital", "Emailing", "Google Ads", "Excel avancé", "Scrum", "Communication",
]
LANGUAGES = {"Français": r"fran[cç]ais|french", "Anglais": r"anglais|english", "Arabe": r"arabe|arabic",
             "Espagnol": r"espagnol|spanish", "Allemand": r"allemand|german", "Amazigh": r"amazigh|tamazight"}
LEVEL_RE = r"(courant|natif|maternelle|bilingue|professionnel|interm[ée]diaire|d[ée]butant|notions|scolaire|[ABC][12]\b)"
HEADING_RE = re.compile(r"^\s*(exp[ée]riences?(\s+professionnelles?)?|parcours professionnel|formations?|[ée]ducation|dipl[oô]mes?|comp[ée]tences?|langues?|certifications?|projets?|centres? d.int[ée]r[êe]ts?|loisirs)\s*:?\s*$", re.I)
EXP_HEADING_RE = re.compile(r"^\s*(exp[ée]riences?(\s+professionnelles?)?|parcours professionnel)\s*:?\s*$", re.I)
EDU_PATTERNS = [
    (5, r"doctorat|ph\.?d"),
    (4, r"master|mast[èe]re|ing[ée]nieur|bac\s?\+\s?5|\bm2\b"),
    (3, r"licence|bachelor|bac\s?\+\s?[34]"),
    (2, r"\bdut\b|\bbts\b|\bdts\b|bac\s?\+\s?2|technicien sp[ée]cialis[ée]"),
    (1, r"baccalaur[ée]at|\bbac\b(?!\s?\+)"),
]


class CVExtractionError(Exception):
    """Erreur lisible par l'utilisateur lors de l'extraction."""


def validate_cv_file(upload):
    ext = Path(upload.name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValidationError("Format non pris en charge : seuls les fichiers PDF et DOCX sont acceptés.")
    max_bytes = settings.CV_MAX_UPLOAD_MB * 1024 * 1024
    if upload.size == 0:
        raise ValidationError("Le fichier est vide.")
    if upload.size > max_bytes:
        raise ValidationError(f"Le fichier dépasse la taille maximale autorisée ({settings.CV_MAX_UPLOAD_MB} Mo).")
    head = upload.read(8)
    upload.seek(0)
    if not head.startswith(ALLOWED_EXTENSIONS[ext]):
        raise ValidationError("Le contenu du fichier ne correspond pas à son extension.")
    return ext


def ocr_available():
    """OCR utilisable seulement si activé, si les bibliothèques sont là ET si le programme Tesseract est installé."""
    if not getattr(settings, "OCR_ENABLED", True):
        return False
    try:
        import pypdfium2  # noqa: F401
        import pytesseract
    except ImportError:
        return False
    import shutil

    return bool(shutil.which("tesseract") or getattr(pytesseract.pytesseract, "tesseract_cmd", "") not in ("", "tesseract") and Path(pytesseract.pytesseract.tesseract_cmd).exists())


def _ocr_pdf(file_obj, max_pages=5):
    """Reconnaissance de caractères sur les premières pages d'un PDF scanné."""
    import pypdfium2 as pdfium
    import pytesseract

    file_obj.seek(0)
    pdf = pdfium.PdfDocument(file_obj.read())
    langs = getattr(settings, "OCR_LANGS", "fra+eng")
    parts = []
    for i in range(min(len(pdf), max_pages)):
        image = pdf[i].render(scale=2.5).to_pil()
        try:
            parts.append(pytesseract.image_to_string(image, lang=langs))
        except pytesseract.TesseractError:  # langue absente : repli sur l'anglais
            parts.append(pytesseract.image_to_string(image, lang="eng"))
    return "\n".join(parts)


def extract_text_ex(file_obj, ext):
    """Retourne (texte, ocr_utilisé) ou lève CVExtractionError avec un message clair."""
    file_obj.seek(0)
    used_ocr = False
    try:
        text = _pdf_text(file_obj) if ext == ".pdf" else _docx_text(file_obj)
        if ext == ".pdf" and len(text.strip()) < MIN_TEXT_LENGTH and ocr_available():
            text, used_ocr = _ocr_pdf(file_obj), True
    except CVExtractionError:
        raise
    except Exception as exc:  # fichier corrompu : message clair, détails techniques non exposés
        raise CVExtractionError("Le fichier est corrompu ou illisible.") from exc
    finally:
        file_obj.seek(0)
    if len(text.strip()) < MIN_TEXT_LENGTH:
        hint = "" if ext != ".pdf" or ocr_available() else " La reconnaissance de caractères (OCR) n'est pas disponible sur ce serveur."
        raise CVExtractionError("Aucun texte exploitable n'a été trouvé (document scanné ou image ?)." + hint + " Saisissez les informations manuellement.")
    return text, used_ocr


def extract_text(file_obj, ext):
    """Retourne le texte brut ou lève CVExtractionError avec un message clair."""
    return extract_text_ex(file_obj, ext)[0]


def _pdf_text(file_obj):
    from pypdf import PdfReader

    reader = PdfReader(file_obj)
    if reader.is_encrypted:
        raise CVExtractionError("Le PDF est protégé par un mot de passe.")
    return "\n".join((page.extract_text() or "") for page in reader.pages[:20])


def _docx_text(file_obj):
    import docx

    try:
        with zipfile.ZipFile(file_obj) as z:
            if "word/document.xml" not in z.namelist():
                raise CVExtractionError("Le fichier n'est pas un document Word valide.")
            if sum(i.file_size for i in z.infolist()) > MAX_UNCOMPRESSED_DOCX:
                raise CVExtractionError("Le document est anormalement volumineux une fois décompressé.")
    except zipfile.BadZipFile as exc:
        raise CVExtractionError("Le fichier DOCX est corrompu.") from exc
    file_obj.seek(0)
    document = docx.Document(file_obj)
    parts = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            parts.append(" ".join(c.text for c in row.cells))
    return "\n".join(parts)


def _sections(text):
    lines = [l for l in text.splitlines()]
    return lines


def _estimate_experience_years(lines):
    """Somme des périodes (années) listées dans la section Expérience ; None si section introuvable."""
    start = next((i for i, l in enumerate(lines) if EXP_HEADING_RE.match(l)), None)
    if start is None:
        return None
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if HEADING_RE.match(lines[j]) and not EXP_HEADING_RE.match(lines[j]):
            end = j
            break
    block = "\n".join(lines[start + 1:end])
    this_year = date.today().year
    spans = []
    for m in re.finditer(r"\b((?:19|20)\d{2})\s*(?:[-–—/]|à|au)\s*((?:19|20)\d{2}|pr[ée]sent|aujourd.?hui|actuel|en cours)", block, re.I):
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2).isdigit() else this_year
        if a <= b <= this_year + 1:
            spans.append((a, b))
    if not spans:
        return None
    spans.sort()
    merged = [list(spans[0])]
    for a, b in spans[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return float(sum(b - a for a, b in merged))


def extract_fields(text, known_skills=()):
    """Tente d'identifier les champs courants. Retourne {valeurs, notes} ; rien n'est inventé."""
    lines = _sections(text)
    data, notes = {}, []
    m = re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", text)
    if m:
        data["email"] = m.group(0).lower()
    else:
        notes.append("E-mail non détecté.")
    m = re.search(r"(?:\+212|00212|0)\s?[5-7](?:[\s.-]?\d{2}){4}", text) or re.search(r"\+\d{1,3}[\s.-]?\d(?:[\s.-]?\d){7,11}", text)
    if m:
        data["phone"] = re.sub(r"\s+", " ", m.group(0)).strip()
    else:
        notes.append("Téléphone non détecté.")
    for line in [l.strip() for l in lines if l.strip()][:6]:
        words = line.split()
        if 2 <= len(words) <= 4 and all(re.fullmatch(r"[A-Za-zÀ-ÿ'’-]+", w) for w in words) and not re.search(r"curriculum|cv|resume|profil|contact", line, re.I):
            data["first_name"], data["last_name"] = words[0].title(), " ".join(words[1:]).title()
            notes.append("Nom déduit de la première ligne du document : à vérifier (l'ordre prénom/nom peut être inversé).")
            break
    else:
        notes.append("Nom non détecté.")
    pool = list(dict.fromkeys(list(known_skills) + KNOWN_SKILLS))
    found = []
    for name in pool:
        if len(name) >= 2 and re.search(rf"(?<![\w+#]){re.escape(name)}(?![\w+#])", text, re.I):
            found.append(name)
    data["skills"] = found
    if not found:
        notes.append("Aucune compétence connue détectée : une compétence non détectée n'est pas une compétence absente.")
    langs = []
    for label, pattern in LANGUAGES.items():
        lm = re.search(rf"(?:{pattern})(.{{0,40}})", text, re.I)
        if lm:
            level = re.search(LEVEL_RE, lm.group(1), re.I)
            langs.append(f"{label} ({level.group(1).lower()})" if level else label)
    data["languages"] = ", ".join(langs)
    best, hint = None, ""
    for line in lines:
        for level, pattern in EDU_PATTERNS:
            if re.search(pattern, line, re.I) and (best is None or level > best):
                best, hint = level, line.strip()[:200]
    if best:
        data["education_level"] = best
        data["education_hint"] = hint
        notes.append("Niveau de formation estimé à partir d'un mot-clé : à confirmer.")
    years = _estimate_experience_years(lines)
    if years is not None:
        data["years_experience"] = years
        notes.append("Durée d'expérience estimée à partir des dates de la section Expérience : approximative, à confirmer.")
    else:
        notes.append("Durée d'expérience non déterminée.")
    return {"data": data, "notes": notes}
