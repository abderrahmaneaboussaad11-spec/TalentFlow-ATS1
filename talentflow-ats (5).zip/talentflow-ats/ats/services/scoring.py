"""Moteur d'évaluation configurable.

Principes :
- Chaque critère de l'offre porte un poids ; le total des poids doit être 100.
- Une information absente du dossier n'est JAMAIS traitée comme une preuve d'incompétence :
  elle est marquée « non documentée » et rapporte 0 point automatiquement, en attente de vérification humaine.
- Le score aide la décision humaine ; il ne refuse aucune candidature automatiquement.
"""
import unicodedata
from decimal import ROUND_HALF_UP, Decimal

from django.db import transaction

from ..models import EDU_LEVELS, EvaluationCriterion, EvaluationResult

TOTAL_POINTS = 100
EDU_LABELS = dict(EDU_LEVELS)

DEFAULT_CRITERIA = [
    (EvaluationCriterion.Kind.EDUCATION, "Formation pertinente", 20),
    (EvaluationCriterion.Kind.EXPERIENCE, "Expérience professionnelle", 20),
    (EvaluationCriterion.Kind.SKILLS, "Compétences techniques", 40),
    (EvaluationCriterion.Kind.LANGUAGES, "Langues requises", 10),
    (EvaluationCriterion.Kind.CERTIFICATIONS, "Certifications", 10),
]


def normalize(text):
    text = unicodedata.normalize("NFKD", text or "")
    return "".join(c for c in text if not unicodedata.combining(c)).lower().strip()


def _q(value):
    return Decimal(value).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)


def clamp(points, weight):
    return max(Decimal("0"), min(_q(points), Decimal(weight)))


def create_default_criteria(job):
    if job.criteria.exists():
        return
    for i, (kind, name, weight) in enumerate(DEFAULT_CRITERIA, start=1):
        EvaluationCriterion.objects.create(job=job, kind=kind, name=name, weight=weight, order=i)


def validate_weights(weights):
    """Retourne un message d'erreur si les poids sont incohérents, sinon None."""
    if any(w <= 0 for w in weights):
        return "Chaque poids doit être supérieur à zéro."
    total = sum(weights)
    if total != TOTAL_POINTS:
        return f"Le total des poids doit être égal à {TOTAL_POINTS} points (actuellement {total})."
    return None


# ---- évaluation de chaque type de critère : retourne (points, statut, justification) ----

def _education(job, cand, weight):
    S = EvaluationResult.Status
    if not job.required_education_level and not job.education_keywords:
        return Decimal(weight), S.VERIFIED, "Aucune exigence de formation définie pour cette offre : points accordés."
    if cand.education_level is None:
        return Decimal(0), S.UNVERIFIED, "Niveau de formation non documenté : à vérifier avec le candidat."
    ok_level = (not job.required_education_level) or cand.education_level >= job.required_education_level
    field = normalize(cand.education_field)
    kws = [normalize(k) for k in job.education_keywords]
    if kws and not field:
        return Decimal(0), S.UNVERIFIED, "Domaine de formation non documenté : à vérifier."
    ok_field = (not kws) or any(k in field for k in kws)
    level_txt = EDU_LABELS.get(cand.education_level, "?")
    if ok_level and ok_field:
        return Decimal(weight), S.VERIFIED, f"Formation documentée : {level_txt}, {cand.education_field or 'domaine non exigé'}."
    reasons = []
    if not ok_level:
        reasons.append(f"niveau {level_txt} inférieur au niveau requis ({EDU_LABELS.get(job.required_education_level)})")
    if not ok_field:
        reasons.append(f"domaine « {cand.education_field} » hors des domaines attendus")
    return Decimal(0), S.VERIFIED, "Formation documentée mais non conforme : " + " ; ".join(reasons) + "."


def _experience(job, cand, weight):
    S = EvaluationResult.Status
    required = Decimal(job.min_experience_years or 0)
    if required <= 0:
        return Decimal(weight), S.VERIFIED, "Aucune expérience minimale exigée : points accordés."
    if cand.years_experience is None:
        return Decimal(0), S.UNVERIFIED, "Durée d'expérience non documentée : à vérifier."
    years = Decimal(cand.years_experience)
    if years >= required:
        return Decimal(weight), S.VERIFIED, f"{years} an(s) d'expérience documentés (minimum {required})."
    # Barème : au moins la moitié de l'expérience requise = moitié des points.
    if years >= required / 2:
        return Decimal(weight) / 2, S.VERIFIED, f"{years} an(s) documentés, soit au moins la moitié du minimum ({required}) : 50 % des points."
    return Decimal(0), S.VERIFIED, f"{years} an(s) documentés, en dessous de la moitié du minimum ({required})."


def _proportional(required_names, candidate_names, weight, label):
    S = EvaluationResult.Status
    if not required_names:
        return Decimal(weight), S.VERIFIED, f"Aucun(e) {label} exigé(e) : points accordés."
    have = {normalize(n) for n in candidate_names}
    matched = [n for n in required_names if normalize(n) in have]
    missing = [n for n in required_names if n not in matched]
    points = Decimal(weight) * len(matched) / len(required_names)
    if not candidate_names:
        return Decimal(0), S.UNVERIFIED, f"Aucun(e) {label} renseigné(e) : information non documentée, à vérifier."
    status = S.VERIFIED if not missing else S.PARTIAL
    text = f"Documentés : {', '.join(matched) or 'aucun'}."
    if missing:
        text += f" Non documentés dans le dossier : {', '.join(missing)} (absence de mention ≠ absence de compétence)."
    return points, status, text


def _skills(job, cand, weight):
    return _proportional([s.name for s in job.required_skills.all()], [s.name for s in cand.skills.all()], weight, "compétence")


def _languages(job, cand, weight):
    return _proportional(job.required_language_list, [x.split("(")[0] for x in cand.language_list], weight, "langue")


def _certifications(job, cand, weight):
    S = EvaluationResult.Status
    certs = [q for q in cand.qualifications.all() if q.kind == "certification"]
    if certs:
        return Decimal(weight), S.VERIFIED, "Certification(s) documentée(s) : " + ", ".join(c.title for c in certs[:5]) + "."
    return Decimal(0), S.UNVERIFIED, "Aucune certification renseignée : information non documentée."


def _custom(job, cand, weight):
    return Decimal(0), EvaluationResult.Status.MANUAL, "Critère évalué manuellement par le recruteur."


EVALUATORS = {
    "education": _education,
    "experience": _experience,
    "skills": _skills,
    "languages": _languages,
    "certifications": _certifications,
    "custom": _custom,
}


def score_criterion(criterion, job, candidate):
    points, status, evidence = EVALUATORS[criterion.kind](job, candidate, criterion.weight)
    return clamp(points, criterion.weight), status, evidence


@transaction.atomic
def evaluate_application(app):
    """Calcule (ou recalcule) les résultats automatiques ; conserve les corrections manuelles."""
    job, cand = app.job, app.candidate
    create_default_criteria(job)
    criteria = list(job.criteria.all())
    for crit in criteria:
        points, status, evidence = score_criterion(crit, job, cand)
        result, _ = EvaluationResult.objects.get_or_create(application=app, criterion=crit)
        result.auto_points, result.status, result.evidence = points, status, evidence
        result.save()
    EvaluationResult.objects.filter(application=app).exclude(criterion__in=criteria).delete()
    return list(app.results.select_related("criterion"))


def _results(app):
    """Résultats de la candidature ; réutilise le préchargement (prefetch_related) pour éviter les requêtes en boucle."""
    if "results" in getattr(app, "_prefetched_objects_cache", {}):
        return list(app.results.all())
    return list(app.results.select_related("criterion"))


def insights(app):
    """Éléments d'explication du score : correspondance des compétences, atouts, points non documentés."""
    job, cand = app.job, app.candidate
    have = {normalize(s.name) for s in cand.skills.all()}
    required = [s.name for s in job.required_skills.all()]
    matched = [n for n in required if normalize(n) in have]
    missing = [n for n in required if normalize(n) not in have]
    preferred = [s.name for s in job.preferred_skills.all() if normalize(s.name) in have]
    results = _results(app)
    strengths = [r.criterion.name for r in results if r.effective_points >= r.criterion.weight and r.criterion.weight > 0]
    relevance = [(r.criterion.name, int(round(100 * float(r.effective_points) / r.criterion.weight)) if r.criterion.weight else 0, r.status) for r in results]
    return {
        "skills_pct": int(round(100 * len(matched) / len(required))) if required else None,
        "matched": matched, "missing": missing, "preferred": preferred, "strengths": strengths, "relevance": relevance,
    }


def summarize(app):
    """Résumé calculé pour l'affichage : total, maximum, nombre d'infos non documentées."""
    results = _results(app)
    total = sum((r.effective_points for r in results), Decimal("0"))
    maximum = sum((r.criterion.weight for r in results), 0)
    total = max(Decimal("0"), min(total, Decimal(maximum)))
    unverified = sum(1 for r in results if r.status in ("unverified", "partial", "manual") and not r.is_overridden)
    return {"total": total, "max": maximum, "unverified": unverified, "evaluated": bool(results)}


def apply_override(result, points, justification, user):
    """Correction manuelle d'un score : justification obligatoire, bornée au poids du critère."""
    if not justification or not justification.strip():
        raise ValueError("Une justification est obligatoire pour corriger un score.")
    points = Decimal(points)
    if points < 0 or points > result.criterion.weight:
        raise ValueError(f"Les points doivent être compris entre 0 et {result.criterion.weight}.")
    result.manual_points = _q(points)
    result.justification = justification.strip()[:300]
    result.reviewed_by = user
    result.save()
    return result
