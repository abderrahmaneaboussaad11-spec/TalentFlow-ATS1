import uuid
from pathlib import Path

from django.conf import settings
from django.core.files.storage import FileSystemStorage


class PrivateStorage(FileSystemStorage):
    """Stockage privé hors de tout dossier servi : aucune URL publique, lecture via une vue protégée."""

    @property
    def base_location(self):
        return str(settings.PRIVATE_MEDIA_ROOT)

    @property
    def location(self):
        return str(Path(settings.PRIVATE_MEDIA_ROOT).resolve())

    @property
    def base_url(self):
        return None


def get_private_storage():
    return PrivateStorage()


def cv_upload_path(instance, filename):
    return f"cv/{uuid.uuid4().hex}{Path(filename).suffix.lower()}"
