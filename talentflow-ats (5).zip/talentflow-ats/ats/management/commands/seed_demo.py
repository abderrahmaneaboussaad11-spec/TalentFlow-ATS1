"""Charge des données de démonstration FICTIVES (marquées is_demo). N'efface jamais de données réelles."""
import random
import secrets
from datetime import timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from accounts.models import User
from ats.models import (Application, Candidate, CVDocument, Department, Interview, InterviewFeedback, Job,
                        PipelineStage, Qualification, Skill, StageHistory)
from ats.services import pipeline, scoring

FIRST = ["Yasmine", "Karim", "Salma", "Omar", "Lina", "Mehdi", "Hajar", "Anas", "Nora", "Reda", "Sara", "Ilyas", "Meryem", "Adam", "Zineb", "Bilal", "Rim", "Hamza", "Khadija", "Walid", "Aya", "Soufiane", "Imane", "Taha"]
LAST = ["Alaoui", "Bennani", "Chraibi", "Daoudi", "El Idrissi", "Fassi", "Gharbi", "Haddad", "Idrissi", "Jabri", "Kettani", "Lahlou", "Mansouri", "Naciri", "Ouazzani", "Pasha", "Qadiri", "Rifai", "Sebti", "Tazi", "Uzzani", "Wahbi", "Yousfi", "Zniber"]
CITIES = ["Casablanca", "Rabat", "Marrakech", "Tanger", "Fès", "Agadir", "Kénitra"]

JOBS = [
    dict(title="Chargé(e) de marketing digital junior", dept="Marketing", location="Casablanca", contract="cdi", level=3, field="marketing, communication, commerce", exp="1.0",
         skills=["SEO", "Réseaux sociaux", "Google Analytics", "Excel"], langs="Français, Anglais",
         desc="Piloter la présence digitale de l'entreprise : campagnes, contenus et suivi des indicateurs de performance. (Offre fictive de démonstration.)"),
    dict(title="Développeur(se) Python / Django", dept="Technologie", location="Rabat", contract="cdi", level=4, field="informatique, ingénierie", exp="2.0",
         skills=["Python", "Django", "SQL", "Git"], langs="Français, Anglais",
         desc="Concevoir et maintenir des applications web internes. (Offre fictive de démonstration.)"),
    dict(title="Gestionnaire RH", dept="Ressources humaines", location="Casablanca", contract="cdd", level=3, field="gestion, ressources humaines, droit", exp="3.0",
         skills=["Recrutement", "Paie", "Excel"], langs="Français, Arabe",
         desc="Gérer l'administration du personnel et accompagner les recrutements. (Offre fictive de démonstration.)"),
]
EDU_FIELDS = ["Marketing digital", "Informatique", "Gestion des entreprises", "Communication", "Ressources humaines", "Finance", "Droit"]
ALL_SKILLS = ["SEO", "Réseaux sociaux", "Google Analytics", "Excel", "Canva", "CRM", "Python", "Django", "SQL", "Git", "Recrutement", "Paie", "Rédaction", "Power BI"]


class Command(BaseCommand):
    help = "Crée des données de démonstration fictives. Utilisez --reset pour supprimer UNIQUEMENT les données de démonstration."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Supprime les données de démonstration existantes avant de les recréer.")
        parser.add_argument("--only-reset", action="store_true", help="Supprime les données de démonstration puis s'arrête.")
        parser.add_argument("--with-users", action="store_true", help="Crée aussi 3 comptes de démonstration avec mots de passe aléatoires affichés une seule fois.")
        parser.add_argument("--candidates", type=int, default=24)

    @transaction.atomic
    def handle(self, *args, **opts):
        if opts["reset"] or opts["only_reset"]:
            self._reset()
            if opts["only_reset"]:
                return
        elif Candidate.objects.filter(is_demo=True).exists():
            self.stdout.write(self.style.WARNING("Des données de démonstration existent déjà. Utilisez --reset pour les recréer."))
            return
        rng = random.Random(2026)
        pipeline.ensure_default_stages()
        users = self._users(opts["with_users"])
        interviewer = users[0] if users else User.objects.exclude(role=User.Role.OBSERVER).first()
        jobs = self._jobs()
        candidates = self._candidates(rng, min(max(opts["candidates"], 6), len(FIRST)))
        self._applications(rng, candidates, jobs, interviewer)
        self.stdout.write(self.style.SUCCESS(f"Démonstration chargée : {len(jobs)} offres, {len(candidates)} candidats fictifs."))

    def _reset(self):
        for doc in CVDocument.objects.filter(candidate__is_demo=True):
            doc.file.delete(save=False)
        n_c = Candidate.objects.filter(is_demo=True).delete()[0]
        n_j = Job.objects.filter(is_demo=True).delete()[0]
        self.stdout.write(f"Données de démonstration supprimées ({n_c + n_j} objets). Aucune donnée réelle touchée.")

    def _users(self, create):
        if not create:
            return []
        out = []
        for username, role in (("demo_rh", User.Role.HR_MANAGER), ("demo_recruteur", User.Role.RECRUITER), ("demo_observateur", User.Role.OBSERVER)):
            pwd = secrets.token_urlsafe(12)
            user, created = User.objects.get_or_create(username=username, defaults={"role": role, "email": f"{username}@example.test", "first_name": "Démo", "last_name": role.label})
            if created:
                user.set_password(pwd)
                user.save()
                self.stdout.write(f"Compte {username} ({role.label}) — mot de passe : {pwd}")
            out.append(user)
        return [u for u in out if u.role != User.Role.OBSERVER]

    def _jobs(self):
        jobs = []
        for spec in JOBS:
            dept, _ = Department.objects.get_or_create(name=spec["dept"])
            job = Job.objects.create(title=spec["title"], department=dept, location=spec["location"], contract_type=spec["contract"], description=spec["desc"],
                                     required_education_level=spec["level"], required_education_field=spec["field"], min_experience_years=Decimal(spec["exp"]),
                                     required_languages=spec["langs"], status=Job.Status.PUBLISHED, published_at=timezone.now() - timedelta(days=70),
                                     deadline=timezone.localdate() + timedelta(days=45), is_demo=True)
            job.required_skills.set([Skill.get_or_create_ci(s) for s in spec["skills"]])
            scoring.create_default_criteria(job)
            jobs.append(job)
        return jobs

    def _candidates(self, rng, n):
        out = []
        firsts, lasts = FIRST[:], LAST[:]
        rng.shuffle(firsts)
        rng.shuffle(lasts)
        for i in range(n):
            f, l = firsts[i], lasts[i]
            known_edu = rng.random() > 0.15
            known_exp = rng.random() > 0.2
            c = Candidate.objects.create(
                first_name=f, last_name=l, email=f"{f}.{l}.{i}@example.test".lower().replace(" ", ""), phone=f"06 {rng.randint(10, 99)} {rng.randint(10, 99)} {rng.randint(10, 99)} {rng.randint(10, 99)}",
                city=rng.choice(CITIES), headline="Profil fictif de démonstration",
                education_level=rng.choice([2, 3, 3, 4, 4, 5]) if known_edu else None, education_field=rng.choice(EDU_FIELDS) if known_edu else "",
                years_experience=Decimal(str(round(rng.uniform(0, 8) * 2) / 2)) if known_exp else None,
                languages=rng.choice(["Français (courant), Anglais (B2)", "Français, Arabe, Anglais", "Français (natif)", "Arabe, Français (courant)", ""]),
                source=rng.choice([s for s, _ in Candidate.Source.choices]), is_demo=True)
            c.skills.set([Skill.get_or_create_ci(s) for s in rng.sample(ALL_SKILLS, rng.randint(2, 6))])
            if rng.random() > 0.6:
                Qualification.objects.create(candidate=c, kind="certification", title=rng.choice(["Google Analytics", "Scrum Master", "Certification SEO"]), organization="Organisme fictif")
            out.append(c)
        return out

    def _applications(self, rng, candidates, jobs, interviewer):
        stages = {s.kind: s for s in PipelineStage.objects.all()}
        path = ["new", "screening", "interview", "evaluation", "offer", "hired"]
        outcomes = ["new", "new", "screening", "screening", "interview", "interview", "evaluation", "offer", "hired", "rejected", "withdrawn"]
        now = timezone.now()
        for c in candidates:
            for job in rng.sample(jobs, rng.choice([1, 1, 2])):
                applied = now - timedelta(days=rng.randint(3, 68), hours=rng.randint(0, 12))
                app = pipeline.create_application(c, job, None, applied_at=applied)
                outcome = rng.choice(outcomes)
                steps = path[1:path.index(outcome) + 1] if outcome in path else path[1:rng.randint(1, 3)] + [outcome]
                if outcome in ("rejected", "withdrawn"):
                    steps = steps[:-1] + [outcome]
                t = applied
                for kind in steps:
                    if kind not in stages:
                        continue
                    prev = app.stage
                    t = min(now, t + timedelta(days=rng.randint(1, 8)))
                    app.stage = stages[kind]
                    StageHistory.objects.create(application=app, from_stage=prev, to_stage=stages[kind], comment="Donnée de démonstration", changed_at=t)
                if outcome == "rejected":
                    app.decision_note = "Profil ne correspondant pas aux besoins actuels (démonstration)."
                app.last_activity = t
                app.save()
                scoring.evaluate_application(app)
                if outcome in ("interview", "evaluation", "offer", "hired"):
                    when = max(applied + timedelta(days=5), now - timedelta(days=rng.randint(1, 20)))
                    iv = Interview.objects.create(application=app, scheduled_at=when, format="video", location="https://meet.example.test/demo", interviewer=interviewer, status="done")
                    InterviewFeedback.objects.create(interview=iv, rating=rng.randint(2, 5), strengths="Communication claire (démo).", concerns="À approfondir (démo).", recommendation=rng.choice(["yes", "yes", "maybe", "no"]), author=interviewer)
                if outcome in ("screening", "interview") and rng.random() > 0.5:
                    Interview.objects.create(application=app, scheduled_at=now + timedelta(days=rng.randint(1, 14), hours=rng.randint(0, 6)), format="video", location="https://meet.example.test/demo", interviewer=interviewer, status="planned")
