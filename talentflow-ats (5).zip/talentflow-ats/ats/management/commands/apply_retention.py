"""Purge les candidatures clôturées au-delà de la durée de conservation (simulation par défaut)."""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from ats.models import Candidate, CompanyProfile
from ats.services import audit


class Command(BaseCommand):
    help = "Liste (ou supprime avec --apply) les candidats dont toutes les candidatures sont clôturées depuis plus que la durée de conservation."

    def add_arguments(self, parser):
        parser.add_argument("--apply", action="store_true", help="Effectue réellement la suppression (irréversible).")

    def handle(self, *args, **opts):
        months = CompanyProfile.get().retention_months
        limit = timezone.now() - timedelta(days=30 * months)
        expired = []
        for cand in Candidate.objects.filter(is_demo=False).prefetch_related("applications__stage"):
            apps = list(cand.applications.all())
            if apps and all(a.stage.is_closed and a.last_activity < limit for a in apps):
                expired.append(cand)
        self.stdout.write(f"{len(expired)} candidat(s) au-delà de {months} mois après clôture.")
        if not opts["apply"]:
            self.stdout.write("Simulation : ajoutez --apply pour supprimer.")
            return
        for cand in expired:
            for doc in cand.documents.all():
                doc.file.delete(save=False)
            cand.delete()
        audit.log(None, "retention.purge", "", f"{len(expired)} candidat(s)")
        self.stdout.write(self.style.SUCCESS("Purge effectuée."))
