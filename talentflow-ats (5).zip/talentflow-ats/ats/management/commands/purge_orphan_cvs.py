"""Supprime les CV importés mais jamais rattachés à un candidat (relecture abandonnée)."""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from ats.models import CVDocument
from ats.services import audit


class Command(BaseCommand):
    help = "Supprime les CV non rattachés à un candidat depuis plus de N heures (24 par défaut)."

    def add_arguments(self, parser):
        parser.add_argument("--hours", type=int, default=24)

    def handle(self, *args, **opts):
        limit = timezone.now() - timedelta(hours=opts["hours"])
        docs = list(CVDocument.objects.filter(candidate__isnull=True, uploaded_at__lt=limit))
        for doc in docs:
            doc.file.delete(save=False)
            doc.delete()
        if docs:
            audit.log(None, "cv.purge_orphans", "", f"{len(docs)} document(s)")
        self.stdout.write(f"{len(docs)} CV orphelin(s) supprimé(s).")
