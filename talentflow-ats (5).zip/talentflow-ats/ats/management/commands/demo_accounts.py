"""(Re)crée les comptes de démonstration avec des mots de passe aléatoires neufs, affichés une seule fois."""
import secrets

from django.core.management.base import BaseCommand

from accounts.models import User

ALPHABET = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # sans caractères ambigus (0/O, 1/l/I)
ACCOUNTS = (("demo_rh", User.Role.HR_MANAGER), ("demo_recruteur", User.Role.RECRUITER), ("demo_observateur", User.Role.OBSERVER))


class Command(BaseCommand):
    help = "Crée ou réinitialise les comptes demo_rh, demo_recruteur et demo_observateur (mots de passe aléatoires)."

    def add_arguments(self, parser):
        parser.add_argument("--file", help="Écrit aussi les identifiants dans ce fichier texte.")

    def handle(self, *args, **opts):
        lines = []
        for username, role in ACCOUNTS:
            pwd = "".join(secrets.choice(ALPHABET) for _ in range(14))
            user, _ = User.objects.get_or_create(username=username, defaults={"email": f"{username}@example.test", "first_name": "Démo", "last_name": role.label})
            user.role, user.is_active = role, True
            user.set_password(pwd)
            user.save()
            lines.append(f"{role.label:<16} identifiant : {username:<18} mot de passe : {pwd}")
        text = "\n".join(lines)
        self.stdout.write(text)
        if opts["file"]:
            with open(opts["file"], "w", encoding="utf-8") as fh:
                fh.write("Comptes de démonstration TalentFlow (données fictives)\n" + text + "\n")
