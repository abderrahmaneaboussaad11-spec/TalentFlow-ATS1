"""Démarrage d'un déploiement de démonstration : migrations, données fictives si vides, comptes de démo."""
import io

from django.core.management import call_command
from django.core.management.base import BaseCommand

from ats.models import Candidate


class Command(BaseCommand):
    help = "Prépare un serveur de démonstration (idempotent) : migrate, seed_demo si la base est vide, comptes demo_*."

    def handle(self, *args, **opts):
        call_command("migrate", interactive=False, verbosity=0)
        if not Candidate.objects.exists():
            call_command("seed_demo", verbosity=0)
        call_command("demo_accounts", stdout=io.StringIO())  # mots de passe aléatoires, non affichés : connexion en un clic
        self.stdout.write(self.style.SUCCESS("Démonstration prête."))
