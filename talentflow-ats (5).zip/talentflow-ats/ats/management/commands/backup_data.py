"""Sauvegarde de la base SQLite et des CV (archive datée). PostgreSQL : utilisez pg_dump."""
import shutil
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import connection


class Command(BaseCommand):
    help = "Crée backups/talentflow-AAAAMMJJ-HHMMSS.sqlite3 et .zip des CV ; conserve les N dernières sauvegardes."

    def add_arguments(self, parser):
        parser.add_argument("--keep", type=int, default=10, help="Nombre de sauvegardes à conserver (défaut 10).")

    def handle(self, *args, **opts):
        if connection.vendor != "sqlite":
            raise CommandError("Base non SQLite : utilisez pg_dump (ex. pg_dump $DATABASE_URL > sauvegarde.sql).")
        dest = Path(settings.BACKUP_DIR)
        dest.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        db_copy = dest / f"talentflow-{stamp}.sqlite3"
        connection.ensure_connection()
        src = connection.connection  # connexion SQLite de Django (fonctionne aussi pour une base en mémoire)
        out = sqlite3.connect(db_copy)
        if "memory" in str(connection.settings_dict["NAME"]):
            out.executescript("\n".join(src.iterdump()))  # base en mémoire (tests) : l'API de sauvegarde peut se bloquer
        else:
            with out:
                src.backup(out)  # copie cohérente même si l'application tourne
        out.close()
        media = Path(settings.PRIVATE_MEDIA_ROOT)
        files = [p for p in media.rglob("*") if p.is_file() and p.name != ".gitkeep"] if media.exists() else []
        if files:
            with zipfile.ZipFile(dest / f"talentflow-{stamp}-fichiers.zip", "w", zipfile.ZIP_DEFLATED) as z:
                for p in files:
                    z.write(p, p.relative_to(media))
        for pattern in ("talentflow-*.sqlite3", "talentflow-*-fichiers.zip"):
            for old in sorted(dest.glob(pattern))[:-max(opts["keep"], 1)]:
                old.unlink()
        self.stdout.write(self.style.SUCCESS(f"Sauvegarde créée : {db_copy.name}" + (f" + {len(files)} fichier(s)" if files else "")))
        self.stdout.write("Copiez le dossier de sauvegarde hors de cet ordinateur (clé USB, Drive chiffré).")
