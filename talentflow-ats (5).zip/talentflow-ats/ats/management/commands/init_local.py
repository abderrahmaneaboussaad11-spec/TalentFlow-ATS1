"""Initialisation guidée du premier lancement local : crée le compte administrateur si aucun utilisateur n'existe."""
import getpass
import sys

from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.management import call_command
from django.core.management.base import BaseCommand

from accounts.models import User
from ats.models import Candidate
from ats.services.pipeline import ensure_default_stages


class Command(BaseCommand):
    help = "Premier lancement : crée l'administrateur (saisie guidée) et propose les données de démonstration."

    def add_arguments(self, parser):
        parser.add_argument("--demo", action="store_true", help="Charge directement les données de démonstration.")

    def handle(self, *args, **opts):
        ensure_default_stages()
        if User.objects.exists():
            self.stdout.write("Un compte existe déjà : aucune création nécessaire.")
        elif not self._interactive():
            self.stdout.write(self.style.WARNING("Saisie impossible ici. Lancez : python manage.py createsuperuser"))
        else:
            self._create_admin()
        if opts["demo"] and not Candidate.objects.filter(is_demo=True).exists():
            call_command("seed_demo")
        elif User.objects.exists() and not Candidate.objects.exists() and not opts["demo"] and self._interactive():
            answer = input("Charger des données de démonstration fictives pour essayer l'application ? (o/N) ").strip().lower()
            if answer in ("o", "oui", "y", "yes"):
                call_command("seed_demo")

    @staticmethod
    def _interactive():
        return sys.stdin is not None and sys.stdin.isatty()

    def _create_admin(self):
        self.stdout.write("\n=== Création du compte administrateur ===")
        username = (input("Nom d'utilisateur [admin] : ").strip() or "admin")
        for _ in range(5):
            pwd = getpass.getpass("Mot de passe (10 caractères minimum, rien ne s'affiche en tapant) : ")
            if pwd != getpass.getpass("Confirmez le mot de passe : "):
                self.stdout.write(self.style.ERROR("Les mots de passe ne correspondent pas. Recommencez."))
                continue
            try:
                validate_password(pwd)
            except ValidationError as exc:
                self.stdout.write(self.style.ERROR("Mot de passe refusé : " + " ".join(exc.messages)))
                continue
            User.objects.create_superuser(username=username, email="", password=pwd)
            self.stdout.write(self.style.SUCCESS(f"Compte « {username} » créé (rôle Administrateur)."))
            return
        self.stdout.write(self.style.ERROR("Trop d'essais. Relancez le programme."))
