from django.apps import AppConfig
from django.db.models.signals import post_migrate


def _ensure_defaults(sender, **kwargs):
    from .services.pipeline import ensure_default_stages
    from .models import CompanyProfile

    ensure_default_stages()
    CompanyProfile.get()


class AtsConfig(AppConfig):
    name = "ats"
    verbose_name = "Recrutement"

    def ready(self):
        post_migrate.connect(_ensure_defaults, sender=self)
