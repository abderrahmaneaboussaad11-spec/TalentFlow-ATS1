from django.urls import path

from .views import applications as a
from .views import candidates as c
from .views import dashboard as d
from .views import interviews as i
from .views import jobs as j
from .views import settings_views as s
from .views import system as sysv
from .views import demo as demo_views

urlpatterns = [
    path("sante/", sysv.health, name="health"),
    path("demo/entrer/<str:role>/", demo_views.demo_login, name="demo_login"),
    path("demo/reinitialiser/", demo_views.demo_reset, name="demo_reset"),
    path("", d.dashboard, name="dashboard"),
    path("analyses/", d.analytics_view, name="analytics"),
    path("recherche/", d.search, name="search"),
    path("parametres/audit/", d.audit_log, name="audit_log"),
    # Offres
    path("offres/", j.job_list, name="job_list"),
    path("offres/nouvelle/", j.job_create, name="job_create"),
    path("offres/<int:pk>/", j.job_detail, name="job_detail"),
    path("offres/<int:pk>/modifier/", j.job_edit, name="job_edit"),
    path("offres/<int:pk>/statut/<str:action>/", j.job_status, name="job_status"),
    path("offres/<int:pk>/supprimer/", j.job_delete, name="job_delete"),
    path("offres/<int:pk>/criteres/", j.job_criteria, name="job_criteria"),
    path("offres/<int:pk>/evaluer/", j.job_evaluate_all, name="job_evaluate_all"),
    path("offres/<int:pk>/classement/", j.job_ranking, name="job_ranking"),
    path("offres/<int:pk>/comparer/", j.job_compare, name="job_compare"),
    path("offres/<int:pk>/preselection/", j.job_shortlist, name="job_shortlist"),
    # Candidats
    path("candidats/", c.candidate_list, name="candidate_list"),
    path("candidats/nouveau/", c.candidate_create, name="candidate_create"),
    path("candidats/importer/", c.cv_import, name="cv_import"),
    path("candidats/importer/a-relire/", c.cv_pending, name="cv_pending"),
    path("candidats/importer/<int:pk>/relecture/", c.cv_review, name="cv_review"),
    path("candidats/importer/<int:pk>/ecarter/", c.cv_discard, name="cv_discard"),
    path("candidats/<int:pk>/", c.candidate_detail, name="candidate_detail"),
    path("candidats/<int:pk>/modifier/", c.candidate_edit, name="candidate_edit"),
    path("candidats/<int:pk>/supprimer/", c.candidate_delete, name="candidate_delete"),
    path("candidats/<int:pk>/postuler/", c.candidate_apply, name="candidate_apply"),
    path("candidats/<int:pk>/parcours/", c.qualification_add, name="qualification_add"),
    path("candidats/<int:pk>/cv/", c.cv_attach, name="cv_attach"),
    path("parcours/<int:pk>/supprimer/", c.qualification_delete, name="qualification_delete"),
    path("documents/<int:pk>/telecharger/", c.cv_download, name="cv_download"),
    path("documents/<int:pk>/supprimer/", c.cv_delete, name="cv_delete"),
    # Candidatures et processus
    path("processus/", a.pipeline_board, name="pipeline"),
    path("candidatures/<int:pk>/", a.application_detail, name="application_detail"),
    path("candidatures/<int:pk>/etape/", a.application_move, name="application_move"),
    path("candidatures/<int:pk>/etape.json", a.application_move_json, name="application_move_json"),
    path("candidatures/<int:pk>/evaluer/", a.application_evaluate, name="application_evaluate"),
    path("candidatures/<int:pk>/note/", a.application_note, name="application_note"),
    path("candidatures/<int:pk>/decision/", a.application_decision, name="application_decision"),
    path("resultats/<int:pk>/corriger/", a.result_override, name="result_override"),
    path("resultats/<int:pk>/reinitialiser/", a.result_reset, name="result_reset"),
    # Entretiens
    path("entretiens/", i.interview_list, name="interview_list"),
    path("entretiens/planifier/", i.interview_create, name="interview_create"),
    path("entretiens/<int:pk>/modifier/", i.interview_edit, name="interview_edit"),
    path("entretiens/<int:pk>/retour/", i.interview_feedback, name="interview_feedback"),
    path("entretiens/<int:pk>/statut/<str:status>/", i.interview_status, name="interview_status"),
    # Paramètres
    path("parametres/", s.company_settings, name="settings_company"),
    path("parametres/etapes/", s.stage_settings, name="settings_stages"),
    path("parametres/etapes/<int:pk>/", s.stage_edit, name="stage_edit"),
    path("parametres/etapes/<int:pk>/supprimer/", s.stage_delete, name="stage_delete"),
    path("parametres/utilisateurs/", s.user_list, name="user_list"),
    path("parametres/utilisateurs/nouveau/", s.user_create, name="user_create"),
    path("parametres/utilisateurs/<int:pk>/", s.user_edit, name="user_edit"),
    path("parametres/utilisateurs/<int:pk>/mot-de-passe/", s.user_password, name="user_password"),
]
