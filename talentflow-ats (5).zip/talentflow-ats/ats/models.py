from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models.functions import Lower
from django.urls import reverse
from django.utils import timezone

from .storage import cv_upload_path, get_private_storage

EDU_LEVELS = [
    (1, "Baccalauréat"),
    (2, "Bac+2 (DUT, BTS, DTS)"),
    (3, "Bac+3 (Licence)"),
    (4, "Bac+5 (Master, Ingénieur)"),
    (5, "Doctorat"),
]


class Department(models.Model):
    name = models.CharField("Nom", max_length=100, unique=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "Département"

    def __str__(self):
        return self.name


class CompanyProfile(models.Model):
    """Profil de l'entreprise (une seule ligne)."""

    name = models.CharField("Nom de l'entreprise", max_length=150, default="Mon entreprise")
    description = models.TextField("Description", blank=True)
    website = models.URLField("Site web", blank=True)
    contact_email = models.EmailField("E-mail RH", blank=True)
    retention_months = models.PositiveIntegerField(
        "Conservation des candidatures clôturées (mois)", default=24,
        help_text="Durée après laquelle les dossiers clôturés peuvent être purgés (commande apply_retention).",
    )

    class Meta:
        verbose_name = "Profil entreprise"

    def __str__(self):
        return self.name

    @classmethod
    def get(cls):
        obj = cls.objects.first()
        return obj or cls.objects.create()


class PipelineStage(models.Model):
    class Kind(models.TextChoices):
        NEW = "new", "Nouvelle candidature"
        SCREENING = "screening", "Présélection"
        INTERVIEW = "interview", "Entretien"
        EVALUATION = "evaluation", "Évaluation"
        OFFER = "offer", "Offre"
        HIRED = "hired", "Recruté"
        REJECTED = "rejected", "Refusé"
        WITHDRAWN = "withdrawn", "Retiré"

    name = models.CharField("Nom", max_length=60, unique=True)
    order = models.PositiveSmallIntegerField("Ordre", default=0)
    kind = models.CharField("Type d'étape", max_length=12, choices=Kind.choices, default=Kind.SCREENING,
                            help_text="Sert aux statistiques (entonnoir, délai de recrutement).")
    color = models.CharField("Couleur", max_length=7, default="#10b981")

    class Meta:
        ordering = ["order", "id"]
        verbose_name = "Étape du processus"

    def __str__(self):
        return self.name

    @property
    def is_closed(self):
        return self.kind in (self.Kind.HIRED, self.Kind.REJECTED, self.Kind.WITHDRAWN)


class Skill(models.Model):
    name = models.CharField("Compétence", max_length=80)

    class Meta:
        ordering = ["name"]
        constraints = [models.UniqueConstraint(Lower("name"), name="uniq_skill_name_ci")]

    def __str__(self):
        return self.name

    @classmethod
    def get_or_create_ci(cls, name):
        name = " ".join(name.split())
        if not name:
            return None
        found = cls.objects.filter(name__iexact=name).first()
        return found or cls.objects.create(name=name[:80])


class Job(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Brouillon"
        PUBLISHED = "published", "Publiée"
        CLOSED = "closed", "Clôturée"
        ARCHIVED = "archived", "Archivée"

    class Contract(models.TextChoices):
        CDI = "cdi", "CDI"
        CDD = "cdd", "CDD"
        INTERNSHIP = "stage", "Stage"
        FREELANCE = "freelance", "Freelance"
        APPRENTICE = "alternance", "Alternance"

    title = models.CharField("Intitulé du poste", max_length=150)
    department = models.ForeignKey(Department, verbose_name="Département", null=True, blank=True, on_delete=models.SET_NULL, related_name="jobs")
    location = models.CharField("Lieu", max_length=120, blank=True)
    contract_type = models.CharField("Type de contrat", max_length=12, choices=Contract.choices, default=Contract.CDI)
    description = models.TextField("Description du poste")
    required_education_level = models.PositiveSmallIntegerField("Niveau de formation requis", choices=EDU_LEVELS, null=True, blank=True)
    required_education_field = models.CharField("Domaines de formation pertinents", max_length=200, blank=True,
                                                help_text="Mots-clés séparés par des virgules (ex. marketing, communication).")
    min_experience_years = models.DecimalField("Expérience minimale (années)", max_digits=4, decimal_places=1, default=Decimal("0"))
    required_skills = models.ManyToManyField(Skill, verbose_name="Compétences requises", blank=True, related_name="jobs_required")
    preferred_skills = models.ManyToManyField(Skill, verbose_name="Compétences souhaitées", blank=True, related_name="jobs_preferred")
    required_languages = models.CharField("Langues requises", max_length=200, blank=True, help_text="Séparées par des virgules (ex. Français, Anglais).")
    deadline = models.DateField("Date limite de candidature", null=True, blank=True)
    status = models.CharField("Statut", max_length=10, choices=Status.choices, default=Status.DRAFT)
    published_at = models.DateTimeField(null=True, blank=True, editable=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+", editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_demo = models.BooleanField("Donnée de démonstration", default=False)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status"])]
        verbose_name = "Offre d'emploi"

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("job_detail", args=[self.pk])

    def clean(self):
        if self.min_experience_years is not None and self.min_experience_years < 0:
            raise ValidationError({"min_experience_years": "L'expérience minimale ne peut pas être négative."})

    @property
    def accepts_applications(self):
        if self.status != self.Status.PUBLISHED:
            return False
        return not (self.deadline and self.deadline < timezone.localdate())

    @property
    def required_language_list(self):
        return [x.strip() for x in self.required_languages.split(",") if x.strip()]

    @property
    def education_keywords(self):
        return [x.strip() for x in self.required_education_field.split(",") if x.strip()]


class EvaluationCriterion(models.Model):
    class Kind(models.TextChoices):
        EDUCATION = "education", "Formation"
        EXPERIENCE = "experience", "Expérience professionnelle"
        SKILLS = "skills", "Compétences techniques"
        LANGUAGES = "languages", "Langues"
        CERTIFICATIONS = "certifications", "Certifications"
        CUSTOM = "custom", "Critère personnalisé (évaluation manuelle)"

    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="criteria")
    kind = models.CharField("Type", max_length=15, choices=Kind.choices)
    name = models.CharField("Libellé", max_length=100)
    weight = models.PositiveSmallIntegerField("Poids (points)")
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]
        verbose_name = "Critère d'évaluation"

    def __str__(self):
        return f"{self.name} ({self.weight})"


class Candidate(models.Model):
    class Source(models.TextChoices):
        WEBSITE = "website", "Site carrière"
        LINKEDIN = "linkedin", "LinkedIn"
        REFERRAL = "referral", "Cooptation"
        AGENCY = "agency", "Cabinet / agence"
        SPONTANEOUS = "spontaneous", "Candidature spontanée"
        OTHER = "other", "Autre"

    first_name = models.CharField("Prénom", max_length=80)
    last_name = models.CharField("Nom", max_length=80)
    email = models.EmailField("E-mail")
    phone = models.CharField("Téléphone", max_length=30, blank=True)
    city = models.CharField("Ville", max_length=80, blank=True)
    headline = models.CharField("Titre / profil", max_length=150, blank=True)
    education_level = models.PositiveSmallIntegerField("Niveau de formation", choices=EDU_LEVELS, null=True, blank=True,
                                                       help_text="Laisser vide si l'information n'est pas documentée.")
    education_field = models.CharField("Domaine de formation", max_length=150, blank=True)
    years_experience = models.DecimalField("Années d'expérience", max_digits=4, decimal_places=1, null=True, blank=True,
                                           help_text="Laisser vide si l'information n'est pas documentée.")
    skills = models.ManyToManyField(Skill, verbose_name="Compétences", blank=True, related_name="candidates")
    languages = models.CharField("Langues", max_length=250, blank=True, help_text="Séparées par des virgules (ex. Français (courant), Anglais (B2)).")
    source = models.CharField("Source", max_length=12, choices=Source.choices, default=Source.OTHER)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_demo = models.BooleanField("Donnée de démonstration", default=False)

    class Meta:
        ordering = ["last_name", "first_name"]
        constraints = [models.UniqueConstraint(Lower("email"), name="uniq_candidate_email_ci")]
        indexes = [models.Index(fields=["last_name", "first_name"])]
        verbose_name = "Candidat"

    def __str__(self):
        return self.full_name

    def get_absolute_url(self):
        return reverse("candidate_detail", args=[self.pk])

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def language_list(self):
        return [x.strip() for x in self.languages.split(",") if x.strip()]


class Qualification(models.Model):
    class Kind(models.TextChoices):
        EDUCATION = "education", "Formation"
        EXPERIENCE = "experience", "Expérience"
        CERTIFICATION = "certification", "Certification"

    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE, related_name="qualifications")
    kind = models.CharField("Type", max_length=14, choices=Kind.choices)
    title = models.CharField("Intitulé", max_length=150)
    organization = models.CharField("Établissement / entreprise", max_length=150, blank=True)
    start_date = models.DateField("Début", null=True, blank=True)
    end_date = models.DateField("Fin", null=True, blank=True)
    description = models.TextField("Détails", blank=True)

    class Meta:
        ordering = ["-end_date", "-start_date", "id"]

    def __str__(self):
        return self.title

    def clean(self):
        if self.start_date and self.end_date and self.end_date < self.start_date:
            raise ValidationError({"end_date": "La date de fin précède la date de début."})


class CVDocument(models.Model):
    class Status(models.TextChoices):
        OK = "ok", "Texte extrait"
        FAILED = "failed", "Extraction impossible"

    candidate = models.ForeignKey(Candidate, null=True, blank=True, on_delete=models.CASCADE, related_name="documents")
    file = models.FileField(upload_to=cv_upload_path, storage=get_private_storage, max_length=200)
    original_name = models.CharField(max_length=200)
    extracted_text = models.TextField(blank=True)
    extraction_status = models.CharField(max_length=8, choices=Status.choices, default=Status.OK)
    extraction_error = models.CharField(max_length=250, blank=True)
    used_ocr = models.BooleanField(default=False)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return self.original_name


class Application(models.Model):
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE, related_name="applications")
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="applications")
    stage = models.ForeignKey(PipelineStage, on_delete=models.PROTECT, related_name="applications")
    applied_at = models.DateTimeField(default=timezone.now)
    last_activity = models.DateTimeField(default=timezone.now)
    decision_note = models.TextField("Justification de la décision", blank=True)

    class Meta:
        ordering = ["-applied_at"]
        constraints = [models.UniqueConstraint(fields=["candidate", "job"], name="uniq_application_candidate_job")]
        indexes = [models.Index(fields=["stage"]), models.Index(fields=["applied_at"])]
        verbose_name = "Candidature"

    def __str__(self):
        return f"{self.candidate} → {self.job}"

    def get_absolute_url(self):
        return reverse("application_detail", args=[self.pk])

    @property
    def total_score(self):
        return sum((r.effective_points for r in self.results.all()), Decimal("0"))

    @property
    def max_score(self):
        return sum((c.weight for c in self.job.criteria.all()), 0)


class StageHistory(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="history")
    from_stage = models.ForeignKey(PipelineStage, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    to_stage = models.ForeignKey(PipelineStage, null=True, on_delete=models.SET_NULL, related_name="+")
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    comment = models.CharField(max_length=300, blank=True)
    changed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-changed_at", "-id"]
        indexes = [models.Index(fields=["changed_at"])]


class Note(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="notes")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    text = models.TextField("Note")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]


class EvaluationResult(models.Model):
    class Status(models.TextChoices):
        VERIFIED = "verified", "Information documentée"
        PARTIAL = "partial", "Partiellement documentée"
        UNVERIFIED = "unverified", "Non documentée / non vérifiée"
        MANUAL = "manual", "Évaluation manuelle requise"

    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="results")
    criterion = models.ForeignKey(EvaluationCriterion, on_delete=models.CASCADE, related_name="results")
    auto_points = models.DecimalField(max_digits=5, decimal_places=1, default=Decimal("0"))
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.UNVERIFIED)
    evidence = models.TextField(blank=True)
    manual_points = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True)
    justification = models.CharField(max_length=300, blank=True)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["criterion__order", "criterion_id"]
        constraints = [models.UniqueConstraint(fields=["application", "criterion"], name="uniq_result_application_criterion")]

    @property
    def effective_points(self):
        return self.manual_points if self.manual_points is not None else self.auto_points

    @property
    def is_overridden(self):
        return self.manual_points is not None


class Interview(models.Model):
    class Format(models.TextChoices):
        VIDEO = "video", "Visioconférence"
        ONSITE = "onsite", "Sur site"
        PHONE = "phone", "Téléphone"

    class Status(models.TextChoices):
        PLANNED = "planned", "Planifié"
        DONE = "done", "Réalisé"
        CANCELLED = "cancelled", "Annulé"
        NO_SHOW = "no_show", "Absence du candidat"

    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="interviews")
    scheduled_at = models.DateTimeField("Date et heure")
    duration_minutes = models.PositiveSmallIntegerField("Durée (minutes)", default=45)
    format = models.CharField("Format", max_length=8, choices=Format.choices, default=Format.VIDEO)
    location = models.CharField("Lieu ou lien de visioconférence", max_length=250, blank=True)
    interviewer = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name="Intervieweur", null=True, on_delete=models.SET_NULL, related_name="interviews")
    status = models.CharField("Statut", max_length=10, choices=Status.choices, default=Status.PLANNED)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["scheduled_at"]
        indexes = [models.Index(fields=["scheduled_at", "status"])]

    def __str__(self):
        return f"Entretien {self.application.candidate} – {self.scheduled_at:%d/%m/%Y %H:%M}"

    @property
    def end_at(self):
        return self.scheduled_at + timezone.timedelta(minutes=self.duration_minutes)


class InterviewFeedback(models.Model):
    class Recommendation(models.TextChoices):
        YES = "yes", "Favorable"
        MAYBE = "maybe", "Réservé"
        NO = "no", "Défavorable"

    interview = models.OneToOneField(Interview, on_delete=models.CASCADE, related_name="feedback")
    rating = models.PositiveSmallIntegerField("Note globale (1 à 5)", choices=[(i, str(i)) for i in range(1, 6)])
    strengths = models.TextField("Points forts", blank=True)
    concerns = models.TextField("Points de vigilance", blank=True)
    recommendation = models.CharField("Recommandation", max_length=6, choices=Recommendation.choices)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)


class AuditEvent(models.Model):
    """Journal d'audit des actions importantes (sans données personnelles superflues)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    action = models.CharField(max_length=60)
    target = models.CharField(max_length=200, blank=True)
    details = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["created_at"])]
