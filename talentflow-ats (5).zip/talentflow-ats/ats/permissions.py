from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def _role_check(predicate):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(request, *args, **kwargs):
            if not predicate(request.user):
                raise PermissionDenied
            return view(request, *args, **kwargs)
        return wrapper
    return decorator


# Lecture : tout utilisateur connecté (y compris Observateur).
read_required = login_required
# Écriture : Recruteur, Responsable RH, Administrateur.
write_required = _role_check(lambda u: u.can_write)
# Gestion (paramètres, suppression, archivage) : Responsable RH, Administrateur.
manage_required = _role_check(lambda u: u.can_manage)
# Administration des utilisateurs : Administrateur uniquement.
admin_required = _role_check(lambda u: u.is_admin_role)
