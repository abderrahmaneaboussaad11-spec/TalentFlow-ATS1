from decimal import Decimal

from django import forms
from django.core.exceptions import ValidationError
from django.forms import BaseModelFormSet, modelformset_factory
from django.utils import timezone

from accounts.models import User

from .models import (Application, Candidate, CompanyProfile, EvaluationCriterion, Interview, InterviewFeedback,
                     Job, PipelineStage, Qualification, Skill)
from .services import scoring
from .services.cv_parser import validate_cv_file


class BootstrapMixin:
    def _style(self):
        for f in self.fields.values():
            w = f.widget
            if isinstance(w, forms.CheckboxInput):
                w.attrs["class"] = "form-check-input"
            elif isinstance(w, (forms.Select, forms.SelectMultiple)):
                w.attrs["class"] = "form-select"
            elif isinstance(w, forms.FileInput):
                w.attrs["class"] = "form-control"
            else:
                w.attrs["class"] = w.attrs.get("class", "") + " form-control"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()


def _split_skills(text):
    seen, out = set(), []
    for part in (text or "").replace("\n", ",").replace(";", ",").split(","):
        name = " ".join(part.split())
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out


class JobForm(BootstrapMixin, forms.ModelForm):
    required_skills_text = forms.CharField(label="Compétences requises", required=False, help_text="Séparées par des virgules.")
    preferred_skills_text = forms.CharField(label="Compétences souhaitées", required=False, help_text="Séparées par des virgules.")

    class Meta:
        model = Job
        fields = ["title", "department", "location", "contract_type", "description", "required_education_level",
                  "required_education_field", "min_experience_years", "required_languages", "deadline"]
        widgets = {"description": forms.Textarea(attrs={"rows": 6}), "deadline": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields["required_skills_text"].initial = ", ".join(self.instance.required_skills.values_list("name", flat=True))
            self.fields["preferred_skills_text"].initial = ", ".join(self.instance.preferred_skills.values_list("name", flat=True))
        self._style()

    def clean_min_experience_years(self):
        v = self.cleaned_data["min_experience_years"]
        if v is not None and (v < 0 or v > 50):
            raise ValidationError("Indiquez une durée comprise entre 0 et 50 ans.")
        return v

    def clean_deadline(self):
        d = self.cleaned_data.get("deadline")
        if d and not self.instance.pk and d < timezone.localdate():
            raise ValidationError("La date limite ne peut pas être dans le passé.")
        return d

    def save(self, commit=True):
        job = super().save(commit=commit)
        if commit:
            job.required_skills.set([Skill.get_or_create_ci(n) for n in _split_skills(self.cleaned_data["required_skills_text"])])
            job.preferred_skills.set([Skill.get_or_create_ci(n) for n in _split_skills(self.cleaned_data["preferred_skills_text"])])
        return job


class CandidateForm(BootstrapMixin, forms.ModelForm):
    skills_text = forms.CharField(label="Compétences", required=False, help_text="Séparées par des virgules. Ne renseigner que ce qui est documenté.")

    class Meta:
        model = Candidate
        fields = ["first_name", "last_name", "email", "phone", "city", "headline", "education_level", "education_field",
                  "years_experience", "languages", "source"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields["skills_text"].initial = ", ".join(self.instance.skills.values_list("name", flat=True))
        self._style()

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        dup = Candidate.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).first()
        if dup:
            self.duplicate = dup
            raise ValidationError(f"Un candidat avec cette adresse e-mail existe déjà ({dup.full_name}).")
        return email

    def clean_years_experience(self):
        v = self.cleaned_data.get("years_experience")
        if v is not None and (v < 0 or v > 60):
            raise ValidationError("Indiquez une durée comprise entre 0 et 60 ans.")
        return v

    def save(self, commit=True):
        cand = super().save(commit=commit)
        if commit:
            cand.skills.set([Skill.get_or_create_ci(n) for n in _split_skills(self.cleaned_data["skills_text"])])
        return cand


class QualificationForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Qualification
        fields = ["kind", "title", "organization", "start_date", "end_date", "description"]
        widgets = {"start_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
                   "end_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"), "description": forms.Textarea(attrs={"rows": 2})}


class CVUploadForm(BootstrapMixin, forms.Form):
    file = forms.FileField(label="CV (PDF ou DOCX)")
    job = forms.ModelChoiceField(label="Associer à une offre (facultatif)", queryset=Job.objects.none(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["job"].queryset = Job.objects.filter(status=Job.Status.PUBLISHED)
        self._style()

    def clean_file(self):
        f = self.cleaned_data["file"]
        self.ext = validate_cv_file(f)
        return f


class BulkCVForm(BootstrapMixin, forms.Form):
    """Import de plusieurs CV : les fichiers sont validés un par un dans la vue."""

    job = forms.ModelChoiceField(label="Associer à une offre (facultatif)", queryset=Job.objects.none(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["job"].queryset = Job.objects.filter(status=Job.Status.PUBLISHED)
        self._style()


class ApplyForm(BootstrapMixin, forms.Form):
    job = forms.ModelChoiceField(label="Offre", queryset=Job.objects.none())

    def __init__(self, candidate, *args, **kwargs):
        super().__init__(*args, **kwargs)
        taken = candidate.applications.values_list("job_id", flat=True)
        self.fields["job"].queryset = Job.objects.filter(status=Job.Status.PUBLISHED).exclude(pk__in=taken)
        self._style()


class StageForm(BootstrapMixin, forms.Form):
    stage = forms.ModelChoiceField(label="Nouvelle étape", queryset=PipelineStage.objects.all())
    comment = forms.CharField(label="Commentaire", required=False, max_length=300)


class NoteForm(BootstrapMixin, forms.Form):
    text = forms.CharField(label="Note interne", widget=forms.Textarea(attrs={"rows": 3}), max_length=2000)


class OverrideForm(BootstrapMixin, forms.Form):
    points = forms.DecimalField(label="Points corrigés", min_value=Decimal("0"), max_digits=5, decimal_places=1)
    justification = forms.CharField(label="Justification (obligatoire)", max_length=300)


class DecisionForm(BootstrapMixin, forms.Form):
    decision_note = forms.CharField(label="Justification de la décision", widget=forms.Textarea(attrs={"rows": 2}), required=False, max_length=1000)


class InterviewForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Interview
        fields = ["application", "scheduled_at", "duration_minutes", "format", "location", "interviewer", "status"]
        widgets = {"scheduled_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M")}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["scheduled_at"].input_formats = ["%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"]
        self.fields["interviewer"].queryset = User.objects.filter(is_active=True).exclude(role=User.Role.OBSERVER)
        self.fields["interviewer"].required = True
        self.fields["application"].queryset = Application.objects.select_related("candidate", "job").exclude(stage__kind__in=["rejected", "withdrawn", "hired"])
        if self.instance.pk:
            self.fields["application"].queryset = Application.objects.select_related("candidate", "job")
        self._style()

    def clean_duration_minutes(self):
        d = self.cleaned_data["duration_minutes"]
        if d < 10 or d > 480:
            raise ValidationError("La durée doit être comprise entre 10 et 480 minutes.")
        return d

    def clean(self):
        cleaned = super().clean()
        start, status = cleaned.get("scheduled_at"), cleaned.get("status")
        if not start:
            return cleaned
        if status == Interview.Status.PLANNED and (not self.instance.pk or "scheduled_at" in self.changed_data) and start < timezone.now():
            self.add_error("scheduled_at", "Un entretien planifié ne peut pas être fixé dans le passé.")
        if cleaned.get("format") in ("video", "onsite") and not cleaned.get("location"):
            self.add_error("location", "Indiquez le lieu ou le lien de visioconférence.")
        if status == Interview.Status.PLANNED:
            end = start + timezone.timedelta(minutes=cleaned.get("duration_minutes") or 45)
            overlapping = Interview.objects.filter(status=Interview.Status.PLANNED, scheduled_at__lt=end).exclude(pk=self.instance.pk)
            overlapping = [i for i in overlapping if i.end_at > start]
            interviewer, app = cleaned.get("interviewer"), cleaned.get("application")
            for i in overlapping:
                if interviewer and i.interviewer_id == interviewer.pk:
                    raise ValidationError(f"Conflit : {interviewer.display_name} a déjà un entretien le {timezone.localtime(i.scheduled_at):%d/%m/%Y à %H:%M}.")
                if app and i.application.candidate_id == app.candidate_id:
                    raise ValidationError(f"Conflit : le candidat a déjà un entretien le {timezone.localtime(i.scheduled_at):%d/%m/%Y à %H:%M}.")
        return cleaned


class FeedbackForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = InterviewFeedback
        fields = ["rating", "strengths", "concerns", "recommendation"]
        widgets = {"strengths": forms.Textarea(attrs={"rows": 3}), "concerns": forms.Textarea(attrs={"rows": 3})}


class CompanyForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = CompanyProfile
        fields = ["name", "description", "website", "contact_email", "retention_months"]
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}

    def clean_retention_months(self):
        v = self.cleaned_data["retention_months"]
        if v < 1 or v > 120:
            raise ValidationError("Indiquez une durée comprise entre 1 et 120 mois.")
        return v


class StageEditForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = PipelineStage
        fields = ["name", "kind", "order", "color"]
        widgets = {"color": forms.TextInput(attrs={"type": "color"})}

    def clean_color(self):
        c = self.cleaned_data["color"]
        if len(c) != 7 or not c.startswith("#"):
            raise ValidationError("Couleur invalide (format #RRGGBB).")
        return c


class CriterionForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = EvaluationCriterion
        fields = ["kind", "name", "weight"]


class BaseCriterionFormSet(BaseModelFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return
        weights, kinds = [], []
        for form in self.forms:
            if not form.cleaned_data or form.cleaned_data.get("DELETE"):
                continue
            weights.append(form.cleaned_data["weight"])
            if form.cleaned_data["kind"] != "custom":
                kinds.append(form.cleaned_data["kind"])
        if not weights:
            raise ValidationError("Définissez au moins un critère.")
        if len(kinds) != len(set(kinds)):
            raise ValidationError("Chaque type de critère automatique ne peut apparaître qu'une fois.")
        error = scoring.validate_weights(weights)
        if error:
            raise ValidationError(error)


CriterionFormSet = modelformset_factory(EvaluationCriterion, form=CriterionForm, formset=BaseCriterionFormSet, extra=1, can_delete=True)
