from django.conf import settings
from django.utils import timezone

from .models import CompanyProfile, Interview


def global_context(request):
    if not request.user.is_authenticated:
        return {"demo_mode": settings.DEMO_MODE}
    upcoming = (
        Interview.objects.filter(interviewer=request.user, status=Interview.Status.PLANNED, scheduled_at__gte=timezone.now())
        .select_related("application__candidate", "application__job").order_by("scheduled_at")[:5]
        if request.user.can_see_private else []
    )
    return {"company": CompanyProfile.get(), "nav_interviews": upcoming, "demo_mode": settings.DEMO_MODE}
