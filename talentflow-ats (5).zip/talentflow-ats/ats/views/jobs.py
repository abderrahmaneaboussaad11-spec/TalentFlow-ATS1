from django.contrib import messages
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

from ..forms import CriterionFormSet, JobForm
from ..models import Application, Department, EvaluationCriterion, Job, PipelineStage
from ..permissions import manage_required, read_required, write_required
from ..services import audit, pipeline, scoring
from .helpers import csv_response, paginate

STATUS_FLOW = {"publish": "published", "close": "closed", "archive": "archived", "draft": "draft"}


@read_required
def job_list(request):
    qs = Job.objects.select_related("department").annotate(n_apps=Count("applications")).order_by("-created_at")
    q, status, dept = request.GET.get("q", "").strip(), request.GET.get("status", ""), request.GET.get("department", "")
    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(location__icontains=q) | Q(description__icontains=q))
    if status:
        qs = qs.filter(status=status)
    elif request.GET.get("all") != "1":
        qs = qs.exclude(status=Job.Status.ARCHIVED)
    if dept:
        qs = qs.filter(department_id=dept)
    page, qstr = paginate(request, qs)
    return render(request, "ats/job_list.html", {
        "page": page, "qs": qstr, "q": q, "status": status, "dept": dept, "statuses": Job.Status.choices,
        "departments": Department.objects.all(), "breadcrumbs": [("Offres d'emploi", None)],
    })


def _save_department(request, form):
    name = request.POST.get("new_department", "").strip()
    if name and not form.instance.department_id:
        form.instance.department, _ = Department.objects.get_or_create(name=name[:100])


@write_required
def job_create(request):
    form = JobForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.instance.created_by = request.user
        _save_department(request, form)
        job = form.save()
        scoring.create_default_criteria(job)
        audit.log(request.user, "job.create", f"Offre #{job.pk}", job.title)
        messages.success(request, "L'offre a été créée en brouillon. Vérifiez les critères d'évaluation avant publication.")
        return redirect("job_detail", pk=job.pk)
    return render(request, "ats/job_form.html", {"form": form, "title": "Nouvelle offre d'emploi", "breadcrumbs": [("Offres d'emploi", "job_list"), ("Nouvelle offre", None)], "cancel_url": "job_list"})


@read_required
def job_detail(request, pk):
    job = get_object_or_404(Job.objects.select_related("department"), pk=pk)
    apps = job.applications.select_related("candidate", "stage")
    return render(request, "ats/job_detail.html", {
        "job": job, "applications": apps, "criteria": job.criteria.all(),
        "breadcrumbs": [("Offres d'emploi", "job_list"), (job.title, None)],
    })


@write_required
def job_edit(request, pk):
    job = get_object_or_404(Job, pk=pk)
    form = JobForm(request.POST or None, instance=job)
    if request.method == "POST" and form.is_valid():
        _save_department(request, form)
        form.save()
        audit.log(request.user, "job.update", f"Offre #{job.pk}", job.title)
        messages.success(request, "L'offre a été mise à jour.")
        return redirect("job_detail", pk=job.pk)
    return render(request, "ats/job_form.html", {"form": form, "title": f"Modifier : {job.title}", "breadcrumbs": [("Offres d'emploi", "job_list"), (job.title, job.get_absolute_url()), ("Modifier", None)], "cancel_url": "job_list"})


@write_required
@require_POST
def job_status(request, pk, action):
    job = get_object_or_404(Job, pk=pk)
    if action not in STATUS_FLOW:
        messages.error(request, "Action inconnue.")
        return redirect("job_detail", pk=pk)
    if action == "archive" and not request.user.can_manage:
        messages.error(request, "Seul un responsable RH peut archiver une offre.")
        return redirect("job_detail", pk=pk)
    if action == "publish":
        if not job.criteria.exists():
            scoring.create_default_criteria(job)
        if job.deadline and job.deadline < timezone.localdate():
            messages.error(request, "La date limite est dépassée : modifiez-la avant de publier.")
            return redirect("job_detail", pk=pk)
        job.published_at = job.published_at or timezone.now()
    job.status = STATUS_FLOW[action]
    job.save()
    audit.log(request.user, f"job.{action}", f"Offre #{job.pk}", job.title)
    messages.success(request, f"Statut de l'offre : {job.get_status_display().lower()}.")
    return redirect("job_detail", pk=pk)


@manage_required
@require_POST
def job_delete(request, pk):
    job = get_object_or_404(Job, pk=pk)
    if job.applications.exists():
        messages.error(request, "Cette offre a des candidatures : archivez-la au lieu de la supprimer.")
        return redirect("job_detail", pk=pk)
    title = job.title
    job.delete()
    audit.log(request.user, "job.delete", f"Offre #{pk}", title)
    messages.success(request, "L'offre a été supprimée.")
    return redirect("job_list")


@manage_required
def job_criteria(request, pk):
    job = get_object_or_404(Job, pk=pk)
    scoring.create_default_criteria(job)
    qs = EvaluationCriterion.objects.filter(job=job)
    formset = CriterionFormSet(request.POST or None, queryset=qs)
    if request.method == "POST" and formset.is_valid():
        instances = formset.save(commit=False)
        for obj in formset.deleted_objects:
            obj.delete()
        for i, obj in enumerate(instances, start=1):
            obj.job = job
            obj.save()
        for i, obj in enumerate(EvaluationCriterion.objects.filter(job=job), start=1):
            if obj.order != i:
                obj.order = i
                obj.save(update_fields=["order"])
        audit.log(request.user, "job.criteria", f"Offre #{job.pk}", "Critères modifiés")
        messages.success(request, "Critères enregistrés. Relancez l'évaluation des candidatures pour appliquer les nouveaux poids.")
        return redirect("job_detail", pk=pk)
    return render(request, "ats/job_criteria.html", {"job": job, "formset": formset, "breadcrumbs": [("Offres d'emploi", "job_list"), (job.title, job.get_absolute_url()), ("Critères", None)]})


@write_required
@require_POST
def job_evaluate_all(request, pk):
    job = get_object_or_404(Job, pk=pk)
    count = 0
    for app in job.applications.select_related("candidate"):
        scoring.evaluate_application(app)
        count += 1
    audit.log(request.user, "job.evaluate_all", f"Offre #{job.pk}", f"{count} candidature(s)")
    messages.success(request, f"{count} candidature(s) évaluée(s). Les corrections manuelles ont été conservées.")
    return redirect("job_ranking", pk=pk)


def _ranked_rows(job):
    rows = []
    for app in job.applications.select_related("candidate", "stage").prefetch_related("results__criterion"):
        rows.append({"app": app, **scoring.summarize(app)})
    evaluated = sorted((r for r in rows if r["evaluated"]), key=lambda r: (-r["total"], r["app"].candidate.last_name))
    pending = [r for r in rows if not r["evaluated"]]
    return evaluated, pending


def shortlist_analysis(ranked, n):
    """Détermine la présélection recommandée et signale les ex æquo au seuil, sans départager arbitrairement."""
    n = max(1, n)
    if len(ranked) <= n:
        return {"n": n, "sure": ranked, "tied": [], "slots": 0, "tie": False, "cutoff": ranked[-1]["total"] if ranked else None}
    cutoff = ranked[n - 1]["total"]
    sure = [r for r in ranked if r["total"] > cutoff]
    tied = [r for r in ranked if r["total"] == cutoff]
    slots = n - len(sure)
    tie = len(tied) > slots
    return {"n": n, "sure": sure + ([] if tie else tied), "tied": tied if tie else [], "slots": slots, "tie": tie, "cutoff": cutoff}


@read_required
def job_ranking(request, pk):
    job = get_object_or_404(Job, pk=pk)
    evaluated, pending = _ranked_rows(job)
    if request.GET.get("export") == "csv":
        if not request.user.can_see_private:
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied
        audit.log(request.user, "export.ranking", f"Offre #{job.pk}")
        return csv_response(f"classement-offre-{job.pk}.csv", ["Rang", "Candidat", "Étape", "Score", "Maximum", "Critères à vérifier"],
                            [(i, r["app"].candidate.full_name, r["app"].stage.name, r["total"], r["max"], r["unverified"]) for i, r in enumerate(evaluated, 1)])
    try:
        n = min(10, max(1, int(request.GET.get("n", 3))))
    except ValueError:
        n = 3
    shortlist = shortlist_analysis(evaluated, n)
    if request.GET.get("export") == "pdf":
        if not request.user.can_see_private:
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied
        from django.http import HttpResponse
        from ..services import reports
        audit.log(request.user, "export.ranking_pdf", f"Offre #{job.pk}")
        resp = HttpResponse(reports.ranking_pdf(job, evaluated, shortlist), content_type="application/pdf")
        resp["Content-Disposition"] = f'attachment; filename="classement-offre-{job.pk}.pdf"'
        return resp
    preselected = {r["app"].pk for r in shortlist["sure"]}
    return render(request, "ats/job_ranking.html", {"job": job, "ranked": evaluated, "pending": pending, "shortlist": shortlist, "preselected": preselected,
                                                     "breadcrumbs": [("Offres d'emploi", "job_list"), (job.title, job.get_absolute_url()), ("Classement", None)]})


@write_required
@require_POST
def job_shortlist(request, pk):
    """Présélection par un humain. En cas d'égalité au seuil, une justification écrite est obligatoire."""
    job = get_object_or_404(Job, pk=pk)
    ids = [int(i) for i in request.POST.getlist("ids") if i.isdigit()]
    apps = list(job.applications.filter(pk__in=ids).select_related("candidate", "stage"))
    if not apps:
        messages.error(request, "Sélectionnez au moins un candidat.")
        return redirect("job_ranking", pk=pk)
    try:
        n = min(10, max(1, int(request.POST.get("n", 3))))
    except ValueError:
        n = 3
    evaluated, _ = _ranked_rows(job)
    analysis = shortlist_analysis(evaluated, n)
    justification = request.POST.get("justification", "").strip()
    if analysis["tie"] and not justification:
        messages.error(request, f"Égalité au seuil ({analysis['cutoff']} pts) : justifiez par écrit le choix final avant de présélectionner.")
        return redirect(f"{reverse('job_ranking', args=[pk])}?n={n}")
    target = PipelineStage.objects.filter(kind=PipelineStage.Kind.SCREENING).first()
    if not target:
        messages.error(request, "Aucune étape de type « Présélection » n'est configurée.")
        return redirect("job_ranking", pk=pk)
    scores = {r["app"].pk: r["total"] for r in evaluated}
    moved = 0
    for app in apps:
        if app.stage.is_closed:
            continue
        comment = f"Présélection (score {scores.get(app.pk, 'non évalué')}/100)" + (f" — {justification}" if justification else "")
        if pipeline.move_application(app, target, request.user, comment):
            moved += 1
    audit.log(request.user, "job.shortlist", f"Offre #{job.pk}", f"{moved} candidat(s)" + (" ; égalité justifiée" if analysis["tie"] else ""))
    messages.success(request, f"{moved} candidature(s) présélectionnée(s).")
    return redirect("job_ranking", pk=pk)


@read_required
def job_compare(request, pk):
    if not request.user.can_see_private:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    job = get_object_or_404(Job, pk=pk)
    raw = request.POST.getlist("ids") if request.method == "POST" else request.GET.get("ids", "").split(",")
    ids = [int(i) for i in raw if str(i).isdigit()][:4]
    apps = list(job.applications.filter(pk__in=ids).select_related("candidate", "stage").prefetch_related("results__criterion"))
    if len(apps) < 2:
        messages.error(request, "Sélectionnez entre 2 et 4 candidats à comparer.")
        return redirect("job_ranking", pk=pk)
    criteria = list(job.criteria.all())
    columns = []
    for app in apps:
        by_crit = {r.criterion_id: r for r in app.results.all()}
        columns.append({"app": app, "summary": scoring.summarize(app), "results": [by_crit.get(c.pk) for c in criteria]})
    rows = [{"criterion": c, "cells": [col["results"][i] for col in columns]} for i, c in enumerate(criteria)]
    return render(request, "ats/job_compare.html", {"job": job, "columns": columns, "rows": rows,
                                                     "breadcrumbs": [("Offres d'emploi", "job_list"), (job.title, job.get_absolute_url()), ("Classement", reverse("job_ranking", args=[pk])), ("Comparaison", None)]})
