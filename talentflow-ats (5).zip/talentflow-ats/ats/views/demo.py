from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.http import Http404
from django.shortcuts import redirect
from django.views.decorators.http import require_POST

from accounts.models import User

from ..permissions import manage_required
from ..services import audit
from ..services.demo import reset_demo_workspace

DEMO_ROLES = {"recruteur": "demo_recruteur", "rh": "demo_rh", "observateur": "demo_observateur"}


@require_POST
def demo_login(request, role):
    """Connexion en un clic à un compte de démonstration (jamais administrateur). Mode démo uniquement."""
    if not settings.DEMO_MODE or role not in DEMO_ROLES:
        raise Http404
    user = User.objects.filter(username=DEMO_ROLES[role], is_active=True).exclude(role=User.Role.ADMIN).first()
    if not user:
        messages.error(request, "Le compte de démonstration n'est pas disponible.")
        return redirect("login")
    login(request, user, backend="django.contrib.auth.backends.ModelBackend")
    return redirect("dashboard")


@manage_required
@require_POST
def demo_reset(request):
    if not settings.DEMO_MODE:
        raise Http404
    reset_demo_workspace()
    audit.log(request.user, "demo.reset")
    messages.success(request, "L'espace de démonstration a été remis à son état d'origine.")
    return redirect("dashboard")
