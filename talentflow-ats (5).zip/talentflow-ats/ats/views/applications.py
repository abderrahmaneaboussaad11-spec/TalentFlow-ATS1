import json

from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from ..forms import DecisionForm, InterviewForm, NoteForm, OverrideForm, StageForm
from ..models import Application, EvaluationResult, Job, PipelineStage
from ..permissions import read_required, write_required
from ..services import audit, pipeline, scoring


@read_required
def application_detail(request, pk):
    app = get_object_or_404(Application.objects.select_related("candidate", "job", "stage"), pk=pk)
    if not request.user.can_see_private:
        raise PermissionDenied
    results = list(app.results.select_related("criterion"))
    summary = scoring.summarize(app)
    return render(request, "ats/application_detail.html", {
        "app": app, "results": results, "summary": summary, "insights": scoring.insights(app), "history": app.history.select_related("from_stage", "to_stage", "changed_by"),
        "notes": app.notes.select_related("author"), "interviews": app.interviews.select_related("interviewer"),
        "stage_form": StageForm(initial={"stage": app.stage}), "note_form": NoteForm(), "override_form": OverrideForm(),
        "decision_form": DecisionForm(initial={"decision_note": app.decision_note}),
        "breadcrumbs": [("Candidats", "candidate_list"), (app.candidate.full_name, app.candidate.get_absolute_url()), (app.job.title, None)],
    })


@write_required
@require_POST
def application_move(request, pk):
    app = get_object_or_404(Application, pk=pk)
    form = StageForm(request.POST)
    if form.is_valid():
        stage = form.cleaned_data["stage"]
        if stage.is_closed and stage.kind in ("rejected",) and not (form.cleaned_data["comment"] or app.decision_note):
            messages.error(request, "Un refus doit être justifié : saisissez un commentaire (ou une justification de décision). Aucun refus n'est automatique.")
        elif pipeline.move_application(app, stage, request.user, form.cleaned_data["comment"]):
            messages.success(request, f"Candidature déplacée vers « {stage.name} ».")
        else:
            messages.info(request, "La candidature est déjà à cette étape.")
    else:
        messages.error(request, "Étape invalide.")
    return redirect(request.POST.get("next") if request.POST.get("next", "").startswith("/") else app.get_absolute_url())


@write_required
@require_POST
def application_move_json(request, pk):
    """Déplacement par glisser-déposer (Kanban). Une alternative sans JavaScript existe sur chaque carte."""
    app = get_object_or_404(Application, pk=pk)
    try:
        stage = PipelineStage.objects.get(pk=json.loads(request.body or "{}").get("stage"))
    except (ValueError, PipelineStage.DoesNotExist, AttributeError):
        return JsonResponse({"ok": False, "error": "Étape invalide."}, status=400)
    if stage.kind == "rejected" and not app.decision_note:
        return JsonResponse({"ok": False, "error": "Un refus doit être justifié : ouvrez la candidature pour ajouter une justification."}, status=400)
    pipeline.move_application(app, stage, request.user, "Déplacement dans le tableau")
    return JsonResponse({"ok": True, "stage": stage.name})


@write_required
@require_POST
def application_evaluate(request, pk):
    app = get_object_or_404(Application, pk=pk)
    scoring.evaluate_application(app)
    audit.log(request.user, "application.evaluate", f"Candidature #{app.pk}")
    messages.success(request, "Évaluation calculée. Vérifiez les informations signalées comme non documentées.")
    return redirect(app.get_absolute_url())


@write_required
@require_POST
def result_override(request, pk):
    result = get_object_or_404(EvaluationResult.objects.select_related("application", "criterion"), pk=pk)
    form = OverrideForm(request.POST)
    if form.is_valid():
        try:
            scoring.apply_override(result, form.cleaned_data["points"], form.cleaned_data["justification"], request.user)
            audit.log(request.user, "score.override", f"Candidature #{result.application_id}", f"{result.criterion.name}: {result.auto_points} → {result.manual_points}")
            messages.success(request, "Score corrigé et justification enregistrée.")
        except ValueError as exc:
            messages.error(request, str(exc))
    else:
        messages.error(request, "Correction invalide : " + " ".join(e for errs in form.errors.values() for e in errs))
    return redirect(result.application.get_absolute_url())


@write_required
@require_POST
def result_reset(request, pk):
    result = get_object_or_404(EvaluationResult, pk=pk)
    result.manual_points, result.justification, result.reviewed_by = None, "", None
    result.save()
    audit.log(request.user, "score.reset", f"Candidature #{result.application_id}")
    messages.success(request, "Correction manuelle retirée.")
    return redirect(result.application.get_absolute_url())


@write_required
@require_POST
def application_note(request, pk):
    app = get_object_or_404(Application, pk=pk)
    form = NoteForm(request.POST)
    if form.is_valid():
        app.notes.create(author=request.user, text=form.cleaned_data["text"])
        messages.success(request, "Note ajoutée.")
    else:
        messages.error(request, "La note est vide ou trop longue.")
    return redirect(app.get_absolute_url())


@write_required
@require_POST
def application_decision(request, pk):
    app = get_object_or_404(Application, pk=pk)
    form = DecisionForm(request.POST)
    if form.is_valid():
        app.decision_note = form.cleaned_data["decision_note"]
        app.save(update_fields=["decision_note"])
        audit.log(request.user, "application.decision_note", f"Candidature #{app.pk}")
        messages.success(request, "Justification enregistrée.")
    return redirect(app.get_absolute_url())


@read_required
def pipeline_board(request):
    stages = list(PipelineStage.objects.all())
    apps = Application.objects.select_related("candidate", "job", "stage").prefetch_related("results__criterion")
    job_id = request.GET.get("job", "")
    if job_id.isdigit():
        apps = apps.filter(job_id=job_id)
    q = request.GET.get("q", "").strip()
    if q:
        apps = apps.filter(Q(candidate__first_name__icontains=q) | Q(candidate__last_name__icontains=q))
    columns = {s.pk: [] for s in stages}
    for app in apps.order_by("-last_activity"):
        item = {"app": app, "summary": scoring.summarize(app)}
        columns[app.stage_id].append(item)
    can_see = request.user.can_see_private
    return render(request, "ats/pipeline.html", {
        "columns": [(s, columns[s.pk]) for s in stages], "jobs": Job.objects.all(), "job_id": job_id, "q": q,
        "can_move": request.user.can_write, "can_see": can_see, "stages": stages, "breadcrumbs": [("Processus de recrutement", None)],
    })
