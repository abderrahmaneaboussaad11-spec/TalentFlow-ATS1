from django.db.models import Q
from django.shortcuts import render
from django.utils import timezone

from ..models import AuditEvent, Candidate, Interview, Job, StageHistory
from ..permissions import read_required
from ..services import analytics


@read_required
def dashboard(request):
    kpis = analytics.dashboard_kpis()
    context = {
        "kpis": kpis,
        "conversion": analytics.conversion_rates(),
        "stage_chart": analytics.stage_distribution(),
        "job_chart": analytics.applications_per_job(),
        "trend_chart": analytics.weekly_series(),
        "recent": StageHistory.objects.select_related("application__candidate", "application__job", "to_stage", "changed_by")[:8],
        "upcoming": Interview.objects.filter(status="planned", scheduled_at__gte=timezone.now()).select_related("application__candidate", "application__job", "interviewer")[:5],
        "has_data": kpis["applications"] > 0,
        "demo_count": Candidate.objects.filter(is_demo=True).count(),
        "breadcrumbs": [("Tableau de bord", None)],
    }
    return render(request, "ats/dashboard.html", context)


@read_required
def analytics_view(request):
    if request.GET.get("export") == "pdf":
        if not request.user.can_see_private:
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied
        from django.http import HttpResponse
        from ..services import audit, reports
        audit.log(request.user, "export.analytics_pdf")
        resp = HttpResponse(reports.analytics_pdf(), content_type="application/pdf")
        resp["Content-Disposition"] = 'attachment; filename="rapport-recrutement.pdf"'
        return resp
    if request.GET.get("export") == "csv":
        if not request.user.can_see_private:
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied
        from .helpers import csv_response
        from ..services import audit
        audit.log(request.user, "export.analytics")
        rows = [("Indicateur", k, v) for k, v in analytics.dashboard_kpis().items()]
        conv = analytics.conversion_rates()
        rows += [("Conversion (%)", k, "" if v is None else v) for k, v in conv.items()]
        for title, chart in (("Étape actuelle", analytics.stage_distribution()), ("Entonnoir", analytics.funnel()), ("Candidatures par offre", analytics.applications_per_job()), ("Sources", analytics.source_distribution())):
            rows += [(title, label, value) for label, value in zip(chart["labels"], chart["datasets"][0]["data"])]
        tth = analytics.time_to_hire()
        rows.append(("Délai moyen de recrutement (jours)", "moyenne", tth["average_days"] if tth else "indisponible"))
        return csv_response("analyses-recrutement.csv", ["Rubrique", "Libellé", "Valeur"], rows)
    context = {
        "kpis": analytics.dashboard_kpis(),
        "conversion": analytics.conversion_rates(),
        "stage_chart": analytics.stage_distribution(),
        "job_chart": analytics.applications_per_job(),
        "funnel_chart": analytics.funnel(),
        "trend_chart": analytics.weekly_series(),
        "source_chart": analytics.source_distribution(),
        "tth": analytics.time_to_hire(),
        "breadcrumbs": [("Analyses", None)],
    }
    context["has_data"] = context["kpis"]["applications"] > 0
    return render(request, "ats/analytics.html", context)


@read_required
def search(request):
    q = request.GET.get("q", "").strip()
    candidates, jobs = [], []
    if len(q) >= 2:
        if request.user.can_see_private:
            candidates = Candidate.objects.filter(Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(email__icontains=q) | Q(headline__icontains=q))[:15]
        jobs = Job.objects.filter(Q(title__icontains=q) | Q(location__icontains=q))[:15]
    return render(request, "ats/search.html", {"q": q, "candidates": candidates, "jobs": jobs, "breadcrumbs": [("Recherche", None)]})


@read_required
def audit_log(request):
    from .helpers import paginate

    if not request.user.can_manage:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    page, qs = paginate(request, AuditEvent.objects.select_related("user"), 30)
    return render(request, "ats/audit.html", {"page": page, "qs": qs, "breadcrumbs": [("Paramètres", "settings_company"), ("Journal d'audit", None)]})
