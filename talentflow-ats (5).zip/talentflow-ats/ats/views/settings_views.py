from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.forms import UserCreateForm, UserEditForm, UserPasswordForm
from accounts.models import User

from ..forms import CompanyForm, StageEditForm
from ..models import CompanyProfile, PipelineStage
from ..permissions import admin_required, manage_required
from ..services import audit


@manage_required
def company_settings(request):
    form = CompanyForm(request.POST or None, instance=CompanyProfile.get())
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "settings.company", "Profil entreprise")
        messages.success(request, "Profil de l'entreprise enregistré.")
        return redirect("settings_company")
    return render(request, "ats/settings_form.html", {"form": form, "title": "Profil de l'entreprise et conservation des données", "section": "company", "breadcrumbs": [("Paramètres", None), ("Entreprise", None)]})


@manage_required
def stage_settings(request):
    stages = PipelineStage.objects.all()
    form = StageEditForm(request.POST or None, initial={"order": (stages.last().order + 1) if stages else 1, "color": "#10b981"})
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "settings.stage.create", form.cleaned_data["name"])
        messages.success(request, "Étape ajoutée.")
        return redirect("settings_stages")
    return render(request, "ats/settings_stages.html", {"stages": stages, "form": form, "section": "stages", "breadcrumbs": [("Paramètres", None), ("Étapes du processus", None)]})


@manage_required
def stage_edit(request, pk):
    stage = get_object_or_404(PipelineStage, pk=pk)
    form = StageEditForm(request.POST or None, instance=stage)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "settings.stage.update", stage.name)
        messages.success(request, "Étape modifiée.")
        return redirect("settings_stages")
    return render(request, "ats/settings_form.html", {"form": form, "title": f"Modifier l'étape « {stage.name} »", "section": "stages", "breadcrumbs": [("Paramètres", None), ("Étapes", "settings_stages"), (stage.name, None)]})


@manage_required
@require_POST
def stage_delete(request, pk):
    stage = get_object_or_404(PipelineStage, pk=pk)
    if stage.applications.exists():
        messages.error(request, "Cette étape contient des candidatures : déplacez-les avant de la supprimer.")
    elif PipelineStage.objects.filter(kind=stage.kind).count() == 1 and stage.kind in ("new", "hired"):
        messages.error(request, "Cette étape est indispensable au fonctionnement (candidature initiale / recrutement).")
    else:
        audit.log(request.user, "settings.stage.delete", stage.name)
        stage.delete()
        messages.success(request, "Étape supprimée.")
    return redirect("settings_stages")


@admin_required
def user_list(request):
    return render(request, "ats/user_list.html", {"users": User.objects.order_by("username"), "section": "users", "breadcrumbs": [("Paramètres", None), ("Utilisateurs", None)]})


@admin_required
def user_create(request):
    form = UserCreateForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        audit.log(request.user, "user.create", f"Utilisateur #{user.pk}", user.role)
        messages.success(request, "Utilisateur créé.")
        return redirect("user_list")
    return render(request, "ats/settings_form.html", {"form": form, "title": "Nouvel utilisateur", "section": "users", "breadcrumbs": [("Paramètres", None), ("Utilisateurs", "user_list"), ("Nouveau", None)]})


@admin_required
def user_edit(request, pk):
    user = get_object_or_404(User, pk=pk)
    form = UserEditForm(request.POST or None, instance=user)
    if request.method == "POST" and form.is_valid():
        if user.pk == request.user.pk and (not form.cleaned_data["is_active"] or form.cleaned_data["role"] != User.Role.ADMIN):
            form.add_error(None, "Vous ne pouvez pas désactiver votre compte ni retirer votre propre rôle d'administrateur.")
        else:
            form.save()
            audit.log(request.user, "user.update", f"Utilisateur #{user.pk}", form.cleaned_data["role"])
            messages.success(request, "Utilisateur mis à jour.")
            return redirect("user_list")
    return render(request, "ats/settings_form.html", {"form": form, "title": f"Modifier l'utilisateur {user.username}", "section": "users", "breadcrumbs": [("Paramètres", None), ("Utilisateurs", "user_list"), (user.username, None)]})


@admin_required
def user_password(request, pk):
    user = get_object_or_404(User, pk=pk)
    form = UserPasswordForm(user, request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "user.password_reset", f"Utilisateur #{user.pk}")
        messages.success(request, f"Mot de passe de « {user.username} » modifié. Communiquez-le de façon sécurisée.")
        return redirect("user_list")
    return render(request, "ats/settings_form.html", {"form": form, "title": f"Nouveau mot de passe : {user.username}", "section": "users", "breadcrumbs": [("Paramètres", None), ("Utilisateurs", "user_list"), (user.username, None)]})
