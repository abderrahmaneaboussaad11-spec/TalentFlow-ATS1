from django.db import connection
from django.http import JsonResponse


def health(request):
    """Contrôle de santé pour l'hébergeur : sans authentification, sans donnée personnelle."""
    try:
        connection.ensure_connection()
        return JsonResponse({"status": "ok"})
    except Exception:
        return JsonResponse({"status": "database_unavailable"}, status=503)
