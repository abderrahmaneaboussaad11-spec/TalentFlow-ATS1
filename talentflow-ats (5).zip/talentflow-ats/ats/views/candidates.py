import mimetypes

from django.conf import settings
from django.contrib import messages
from django.core.files.base import ContentFile
from django.db.models import Count, Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from ..forms import ApplyForm, BulkCVForm, CandidateForm, CVUploadForm, QualificationForm
from ..models import Candidate, CVDocument, EDU_LEVELS, Job, PipelineStage, Qualification, Skill
from ..permissions import manage_required, read_required, write_required
from ..services import audit, pipeline
from ..services.cv_parser import CVExtractionError, extract_fields, extract_text, extract_text_ex, validate_cv_file
from django.core.exceptions import ValidationError
from .helpers import csv_response, paginate

SORTS = {"name": ("last_name", "first_name"), "recent": ("-created_at",), "experience": ("-years_experience",)}


def filtered_candidates(request):
    qs = Candidate.objects.annotate(n_apps=Count("applications", distinct=True))
    g = request.GET
    q = g.get("q", "").strip()
    if q:
        qs = qs.filter(Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(email__icontains=q) | Q(headline__icontains=q) | Q(city__icontains=q))
    if g.get("job"):
        qs = qs.filter(applications__job_id=g["job"])
    if g.get("stage"):
        qs = qs.filter(applications__stage_id=g["stage"])
    if g.get("skill"):
        qs = qs.filter(skills__name__icontains=g["skill"].strip())
    if g.get("min_exp"):
        try:
            qs = qs.filter(years_experience__gte=float(g["min_exp"]))
        except ValueError:
            pass
    if g.get("education"):
        qs = qs.filter(education_level__gte=g["education"]) if g["education"].isdigit() else qs
    if g.get("demo") == "1":
        qs = qs.filter(is_demo=True)
    return qs.distinct().order_by(*SORTS.get(g.get("sort"), SORTS["name"]))


@read_required
def candidate_list(request):
    if not request.user.can_see_private:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    qs = filtered_candidates(request)
    if request.GET.get("export") == "csv":
        audit.log(request.user, "export.candidates", "", f"{qs.count()} ligne(s)")
        return csv_response("candidats.csv", ["Nom", "Prénom", "E-mail", "Ville", "Formation", "Expérience (ans)", "Source", "Démo"],
                            [(c.last_name, c.first_name, c.email, c.city, c.get_education_level_display() or "non documenté",
                              c.years_experience if c.years_experience is not None else "non documenté", c.get_source_display(), "oui" if c.is_demo else "non") for c in qs])
    page, qstr = paginate(request, qs)
    return render(request, "ats/candidate_list.html", {
        "page": page, "qs": qstr, "g": request.GET, "jobs": Job.objects.all(), "stages": PipelineStage.objects.all(),
        "edu_levels": EDU_LEVELS, "breadcrumbs": [("Candidats", None)],
    })


@write_required
def candidate_create(request):
    form = CandidateForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        cand = form.save()
        audit.log(request.user, "candidate.create", f"Candidat #{cand.pk}")
        messages.success(request, "Le candidat a été créé.")
        return redirect("candidate_detail", pk=cand.pk)
    return render(request, "ats/candidate_form.html", {"form": form, "title": "Nouveau candidat", "duplicate": getattr(form, "duplicate", None), "breadcrumbs": [("Candidats", "candidate_list"), ("Nouveau", None)], "cancel_url": "candidate_list"})


@read_required
def candidate_detail(request, pk):
    if not request.user.can_see_private:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    cand = get_object_or_404(Candidate, pk=pk)
    return render(request, "ats/candidate_detail.html", {
        "cand": cand, "applications": cand.applications.select_related("job", "stage"), "qualifications": cand.qualifications.all(),
        "documents": cand.documents.all(), "qual_form": QualificationForm(), "apply_form": ApplyForm(cand), "cv_form": CVUploadForm(),
        "breadcrumbs": [("Candidats", "candidate_list"), (cand.full_name, None)],
    })


@write_required
def candidate_edit(request, pk):
    cand = get_object_or_404(Candidate, pk=pk)
    form = CandidateForm(request.POST or None, instance=cand)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "candidate.update", f"Candidat #{cand.pk}")
        messages.success(request, "Le profil a été mis à jour.")
        return redirect("candidate_detail", pk=pk)
    return render(request, "ats/candidate_form.html", {"form": form, "title": f"Modifier : {cand.full_name}", "duplicate": getattr(form, "duplicate", None), "breadcrumbs": [("Candidats", "candidate_list"), (cand.full_name, cand.get_absolute_url()), ("Modifier", None)], "cancel_url": "candidate_list"})


@manage_required
@require_POST
def candidate_delete(request, pk):
    cand = get_object_or_404(Candidate, pk=pk)
    if cand.applications.exclude(stage__kind__in=["rejected", "withdrawn", "hired"]).exists():
        messages.error(request, "Ce candidat a des candidatures actives : retirez-les du processus avant suppression.")
        return redirect("candidate_detail", pk=pk)
    for doc in cand.documents.all():
        doc.file.delete(save=False)
    audit.log(request.user, "candidate.delete", f"Candidat #{pk}")
    cand.delete()
    messages.success(request, "Le candidat et ses documents ont été supprimés.")
    return redirect("candidate_list")


@write_required
@require_POST
def candidate_apply(request, pk):
    cand = get_object_or_404(Candidate, pk=pk)
    form = ApplyForm(cand, request.POST)
    if form.is_valid():
        job = form.cleaned_data["job"]
        if not job.accepts_applications:
            messages.error(request, "Cette offre n'accepte plus de candidatures (date limite dépassée).")
        else:
            app = pipeline.create_application(cand, job, request.user)
            messages.success(request, "Candidature enregistrée.")
            return redirect("application_detail", pk=app.pk)
    else:
        messages.error(request, "Offre invalide ou candidature déjà existante.")
    return redirect("candidate_detail", pk=pk)


@write_required
@require_POST
def qualification_add(request, pk):
    cand = get_object_or_404(Candidate, pk=pk)
    form = QualificationForm(request.POST)
    if form.is_valid():
        q = form.save(commit=False)
        q.candidate = cand
        q.save()
        messages.success(request, "Élément ajouté au parcours.")
    else:
        messages.error(request, "Parcours non enregistré : " + " ".join(e for errs in form.errors.values() for e in errs))
    return redirect("candidate_detail", pk=pk)


@write_required
@require_POST
def qualification_delete(request, pk):
    q = get_object_or_404(Qualification, pk=pk)
    cid = q.candidate_id
    q.delete()
    messages.success(request, "Élément supprimé.")
    return redirect("candidate_detail", pk=cid)


def _store_cv(upload, ext, user):
    """Valide déjà fait : extrait le texte (OCR si besoin), enregistre le fichier de façon privée."""
    doc = CVDocument(original_name=upload.name[:200], uploaded_by=user)
    try:
        doc.extracted_text, doc.used_ocr = extract_text_ex(upload, ext)
        doc.extraction_status = CVDocument.Status.OK
    except CVExtractionError as exc:
        doc.extraction_status, doc.extraction_error = CVDocument.Status.FAILED, str(exc)[:250]
    upload.seek(0)
    doc.file.save(upload.name, ContentFile(upload.read()), save=False)
    doc.save()
    audit.log(user, "cv.upload", f"Document #{doc.pk}", doc.extraction_status + (" (OCR)" if doc.used_ocr else ""))
    return doc


@write_required
def cv_import(request):
    form = BulkCVForm(request.POST if request.method == "POST" else None)  # un envoi de fichiers seuls a un POST vide
    if request.method == "POST" and form.is_valid():
        files = request.FILES.getlist("files")
        if not files:
            form.add_error(None, "Choisissez au moins un fichier PDF ou DOCX.")
        elif len(files) > settings.CV_MAX_FILES_PER_UPLOAD:
            form.add_error(None, f"Maximum {settings.CV_MAX_FILES_PER_UPLOAD} fichiers à la fois.")
        else:
            docs, rejected = [], []
            for upload in files:
                try:
                    ext = validate_cv_file(upload)
                except ValidationError as exc:
                    rejected.append(f"{upload.name} : {' '.join(exc.messages)}")
                    continue
                docs.append(_store_cv(upload, ext, request.user))
            for line in rejected:
                messages.error(request, "Fichier refusé — " + line)
            if not docs:
                return redirect("cv_import")
            job = form.cleaned_data.get("job")
            if len(docs) == 1:
                url = redirect("cv_review", pk=docs[0].pk)
                if job:
                    url["Location"] += f"?job={job.pk}"
                return url
            messages.success(request, f"{len(docs)} CV importés. Relisez-les un par un : aucun candidat n'est créé sans votre validation.")
            url = redirect("cv_pending")
            if job:
                url["Location"] += f"?job={job.pk}"
            return url
    return render(request, "ats/cv_import.html", {"form": form, "max_mb": settings.CV_MAX_UPLOAD_MB, "max_files": settings.CV_MAX_FILES_PER_UPLOAD,
                                                  "breadcrumbs": [("Candidats", "candidate_list"), ("Importer des CV", None)]})


@write_required
def cv_pending(request):
    docs = list(CVDocument.objects.filter(candidate__isnull=True).select_related("uploaded_by"))
    known = list(Skill.objects.values_list("name", flat=True))
    rows = []
    for doc in docs:
        detected = extract_fields(doc.extracted_text, known)["data"] if doc.extraction_status == CVDocument.Status.OK else {}
        rows.append({"doc": doc, "name": f"{detected.get('first_name', '')} {detected.get('last_name', '')}".strip(), "email": detected.get("email", "")})
    job_id = request.GET.get("job", "")
    return render(request, "ats/cv_pending.html", {"rows": rows, "job_id": job_id if job_id.isdigit() else "", "breadcrumbs": [("Candidats", "candidate_list"), ("CV à relire", None)]})


@write_required
@require_POST
def cv_discard(request, pk):
    doc = get_object_or_404(CVDocument, pk=pk, candidate__isnull=True)
    doc.file.delete(save=False)
    doc.delete()
    audit.log(request.user, "cv.discard", f"Document #{pk}")
    messages.success(request, "CV écarté et supprimé.")
    return redirect("cv_pending")


@write_required
def cv_review(request, pk):
    doc = get_object_or_404(CVDocument, pk=pk, candidate__isnull=True)
    job = Job.objects.filter(pk=request.GET.get("job") or request.POST.get("job") or 0).first()
    extraction = {"data": {}, "notes": []}
    if doc.extraction_status == CVDocument.Status.OK:
        extraction = extract_fields(doc.extracted_text, Skill.objects.values_list("name", flat=True))
    d = extraction["data"]
    initial = {k: d[k] for k in ("first_name", "last_name", "email", "phone", "languages", "education_level", "years_experience") if k in d}
    initial["skills_text"] = ", ".join(d.get("skills", []))
    initial["source"] = Candidate.Source.OTHER
    form = CandidateForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        cand = form.save()
        doc.candidate = cand
        doc.save(update_fields=["candidate"])
        audit.log(request.user, "candidate.create", f"Candidat #{cand.pk}", "Import CV après relecture")
        if job and job.accepts_applications:
            pipeline.create_application(cand, job, request.user)
        messages.success(request, "Candidat créé après relecture des informations extraites.")
        return redirect("candidate_detail", pk=cand.pk)
    return render(request, "ats/cv_review.html", {
        "form": form, "doc": doc, "pending_count": CVDocument.objects.filter(candidate__isnull=True).exclude(pk=doc.pk).count(), "notes": extraction["notes"], "hint": d.get("education_hint"), "job": job,
        "duplicate": getattr(form, "duplicate", None), "breadcrumbs": [("Candidats", "candidate_list"), ("Importer un CV", "cv_import"), ("Relecture", None)],
    })


@write_required
@require_POST
def cv_attach(request, pk):
    cand = get_object_or_404(Candidate, pk=pk)
    form = CVUploadForm(request.POST, request.FILES)
    if not form.is_valid():
        messages.error(request, " ".join(e for errs in form.errors.values() for e in errs))
        return redirect("candidate_detail", pk=pk)
    upload = form.cleaned_data["file"]
    doc = CVDocument(candidate=cand, original_name=upload.name[:200], uploaded_by=request.user)
    try:
        doc.extracted_text, doc.used_ocr = extract_text_ex(upload, form.ext)
    except CVExtractionError as exc:
        doc.extraction_status, doc.extraction_error = CVDocument.Status.FAILED, str(exc)[:250]
        messages.warning(request, f"Document enregistré mais texte non extrait : {exc}")
    upload.seek(0)
    doc.file.save(upload.name, ContentFile(upload.read()), save=False)
    doc.save()
    audit.log(request.user, "cv.upload", f"Document #{doc.pk}", f"Candidat #{pk}")
    messages.success(request, "CV ajouté au dossier.")
    return redirect("candidate_detail", pk=pk)


@read_required
def cv_download(request, pk):
    if not request.user.can_see_private:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    doc = get_object_or_404(CVDocument, pk=pk)
    if not doc.file or not doc.file.storage.exists(doc.file.name):
        raise Http404
    audit.log(request.user, "cv.download", f"Document #{doc.pk}")
    ctype = mimetypes.guess_type(doc.original_name)[0] or "application/octet-stream"
    return FileResponse(doc.file.open("rb"), as_attachment=True, filename=doc.original_name, content_type=ctype)


@manage_required
@require_POST
def cv_delete(request, pk):
    doc = get_object_or_404(CVDocument, pk=pk)
    cid = doc.candidate_id
    doc.file.delete(save=False)
    doc.delete()
    audit.log(request.user, "cv.delete", f"Document #{pk}")
    messages.success(request, "Document supprimé.")
    return redirect("candidate_detail", pk=cid) if cid else redirect("candidate_list")
