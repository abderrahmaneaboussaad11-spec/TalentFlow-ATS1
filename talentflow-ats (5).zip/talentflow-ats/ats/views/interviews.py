from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from ..forms import FeedbackForm, InterviewForm
from ..models import Application, Interview
from ..permissions import read_required, write_required
from ..services import audit
from .helpers import paginate


@read_required
def interview_list(request):
    if not request.user.can_see_private:
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    now = timezone.now()
    base = Interview.objects.select_related("application__candidate", "application__job", "interviewer")
    if request.GET.get("mine") == "1":
        base = base.filter(interviewer=request.user)
    upcoming = base.filter(status=Interview.Status.PLANNED, scheduled_at__gte=now)
    past = base.exclude(pk__in=upcoming.values("pk")).order_by("-scheduled_at")
    page, qs = paginate(request, past, 10)
    return render(request, "ats/interview_list.html", {"upcoming": upcoming, "page": page, "qs": qs, "mine": request.GET.get("mine") == "1", "now": now, "breadcrumbs": [("Entretiens", None)]})


@write_required
def interview_create(request):
    initial = {}
    app_id = request.GET.get("application")
    if app_id and app_id.isdigit():
        initial["application"] = app_id
    initial["interviewer"] = request.user.pk
    form = InterviewForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        iv = form.save()
        audit.log(request.user, "interview.create", f"Entretien #{iv.pk}", f"Candidature #{iv.application_id}")
        messages.success(request, "Entretien planifié. Pensez à déplacer la candidature à l'étape « Entretien » si nécessaire.")
        return redirect("application_detail", pk=iv.application_id)
    return render(request, "ats/interview_form.html", {"form": form, "title": "Planifier un entretien", "breadcrumbs": [("Entretiens", "interview_list"), ("Planifier", None)], "cancel_url": "interview_list"})


@write_required
def interview_edit(request, pk):
    iv = get_object_or_404(Interview, pk=pk)
    form = InterviewForm(request.POST or None, instance=iv)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit.log(request.user, "interview.update", f"Entretien #{iv.pk}", iv.status)
        messages.success(request, "Entretien mis à jour.")
        return redirect("interview_list")
    return render(request, "ats/interview_form.html", {"form": form, "title": "Modifier l'entretien", "breadcrumbs": [("Entretiens", "interview_list"), ("Modifier", None)], "cancel_url": "interview_list"})


@write_required
def interview_feedback(request, pk):
    iv = get_object_or_404(Interview.objects.select_related("application__candidate", "application__job"), pk=pk)
    existing = getattr(iv, "feedback", None)
    form = FeedbackForm(request.POST or None, instance=existing)
    if request.method == "POST" and form.is_valid():
        fb = form.save(commit=False)
        fb.interview, fb.author = iv, request.user
        fb.save()
        if iv.status == Interview.Status.PLANNED:
            iv.status = Interview.Status.DONE
            iv.save(update_fields=["status"])
        audit.log(request.user, "interview.feedback", f"Entretien #{iv.pk}", fb.recommendation)
        messages.success(request, "Retour d'entretien enregistré.")
        return redirect("application_detail", pk=iv.application_id)
    return render(request, "ats/interview_form.html", {"form": form, "title": f"Retour d'entretien — {iv.application.candidate.full_name}", "breadcrumbs": [("Entretiens", "interview_list"), ("Retour d'entretien", None)], "cancel_url": "interview_list"})


@write_required
@require_POST
def interview_status(request, pk, status):
    iv = get_object_or_404(Interview, pk=pk)
    if status in ("cancelled", "no_show", "done"):
        iv.status = status
        iv.save(update_fields=["status"])
        audit.log(request.user, "interview.status", f"Entretien #{iv.pk}", status)
        messages.success(request, "Statut de l'entretien mis à jour.")
    return redirect("interview_list")
