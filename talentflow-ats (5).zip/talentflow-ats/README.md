# TalentFlow ATS

Système de suivi des candidatures (ATS) en français : offres d'emploi, candidats, import de CV (PDF/DOCX), évaluation transparente et configurable, processus de recrutement (liste + tableau Kanban), entretiens, indicateurs et exports CSV.

> **Statut honnête.** Projet académique / de démonstration. Il a été testé automatiquement (voir « Tests ») et via des requêtes HTTP, mais **jamais ouvert dans un navigateur par son auteur** : le rendu visuel et le glisser-déposer du Kanban n'ont pas pu être vérifiés visuellement. Ne le déployez pas en production sans la checklist ci-dessous.

## Fonctionnalités

| Module | Contenu |
|---|---|
| Authentification | Connexion/déconnexion Django, **blocage 15 min après 5 échecs**, 4 rôles (Administrateur, Responsable RH, Recruteur, Observateur), contrôle côté serveur, pages 403/404/500, message de session expirée |
| Tableau de bord | Indicateurs calculés en base, graphiques Chart.js (tendance, étapes, offres), activité récente, entretiens à venir, état vide |
| Offres | Création, modification, publication, clôture, archivage, suppression (si sans candidature), recherche/filtres, **critères d'évaluation configurables** |
| Candidats | Annuaire, fiche, parcours, compétences, langues, CV, doublons bloqués (e-mail insensible à la casse), recherche/filtres/tri/pagination, export CSV |
| Import de CV | PDF/DOCX, **import multiple avec glisser-déposer** (file « CV à relire »), validation (extension, taille, signature), extraction de texte et de champs, **OCR facultatif pour les PDF scannés** (Tesseract requis), **relecture obligatoire**, erreurs claires, saisie manuelle toujours possible |
| Évaluation | Score sur 100 par offre, détail par critère, statut « documenté / partiel / non documenté », correction manuelle **justifiée et tracée** |
| Classement et présélection | Classement décroissant, **présélection recommandée (3 par défaut)**, **égalités au seuil signalées sans départage arbitraire** (justification écrite obligatoire), **comparaison côte à côte de 2 à 4 candidats** |
| Processus | 8 étapes configurables, historique (qui, quand, pourquoi), Kanban glisser-déposer **et** liste déroulante sans JavaScript |
| Entretiens | Planification, format, intervieweur, détection de conflits (intervieweur et candidat), retours structurés |
| Rapports | Export **PDF** (rapport de recrutement, classement d'une offre) et CSV ; sauvegarde datée avec `python manage.py backup_data` |
| Interface | Thème **clair / sombre** (mémorisé), analyse de correspondance (compétences retrouvées / non documentées, pertinence par critère) |
| Analyses | Entonnoir, répartition par étape/offre/source, conversion, délai de recrutement (si données) |
| Paramètres | Profil entreprise, durée de conservation (commande `apply_retention`), étapes, utilisateurs et **réinitialisation de mot de passe** (admin), journal d'audit |

### Modèle d'évaluation (par défaut, 100 points)

Formation 20 · Expérience 20 · Compétences techniques 40 · Langues 10 · Certifications 10. Les poids sont modifiables par offre (page de l'offre → « Configurer »), le total doit rester **100**. Un critère « personnalisé » est noté à la main.

Principes appliqués dans `ats/services/scoring.py` :
- une information absente est « **non documentée** » (0 point automatique, signalée) et **jamais** interprétée comme une preuve d'incompétence ;
- aucun critère n'utilise de caractéristique protégée (âge, genre, origine, photo…) ;
- le score est borné entre 0 et le poids de chaque critère ;
- **aucune étape n'est modifiée automatiquement** ; un refus exige une justification humaine.

## Démarrage rapide (Windows) — 3 étapes

Prérequis : **Python 3.10 ou plus** (https://www.python.org/downloads/ — cochez **« Add python.exe to PATH »** pendant l'installation) et une connexion internet pour la première installation.

1. **Extrayez le zip** (clic droit → *Extraire tout…*). Ne lancez rien depuis l'aperçu du zip.
2. Dans le dossier extrait (celui qui contient `manage.py`), **double-cliquez sur `LANCER.bat`**.
3. Suivez les messages : au tout premier lancement, le programme crée l'environnement, installe les dépendances, génère le fichier `.env` avec une clé secrète, prépare la base, **vous demande de choisir un nom d'utilisateur et un mot de passe administrateur**, puis démarre le serveur et **ouvre le navigateur quand il est réellement prêt**.

> **Laissez la fenêtre noire ouverte** tant que vous utilisez le site : la fermer arrête le site. Pour arrêter : `Ctrl + C` ou fermez la fenêtre. La fenêtre ne se ferme jamais toute seule en cas d'erreur (elle attend une touche), ce qui permet de lire le message.

Lancements suivants : double-clic sur `LANCER.bat` (30 secondes de moins, plus d'installation). Le site est sur `http://127.0.0.1:8000/` (ou 8001, 8002… si le port est pris : l'adresse exacte est affichée dans la fenêtre).

Options : `LANCER.bat --demo` charge les données fictives ; `LANCER.bat --no-browser` n'ouvre pas le navigateur.

### Installation manuelle (équivalent, si vous préférez les commandes)

```bat
cd talentflow-ats
py -3 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py init_local
python manage.py runserver
```
(`init_local` crée l'administrateur de façon guidée ; `python manage.py createsuperuser` fonctionne aussi. Sans fichier `.env`, les commandes `manage.py` démarrent en mode développement local.)

PowerShell : si l'activation est bloquée, exécutez `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, ou utilisez l'Invite de commandes.

### Compte administrateur

Il n'existe **aucun compte par défaut**. Le compte est créé par vous au premier lancement (mot de passe d'au moins 10 caractères). Ensuite, l'administrateur crée les autres comptes dans *Utilisateurs* et peut **définir un nouveau mot de passe** pour quelqu'un qui l'a oublié (bouton « Mot de passe »).

## Partager une démonstration avec le jury (données fictives)

`PARTAGER_DEMO.bat` donne un **lien HTTPS temporaire** que le jury peut ouvrir depuis son propre navigateur, pendant que l'application tourne sur **votre** PC.

1. Double-cliquez sur **`PARTAGER_DEMO.bat`** (internet requis).
2. Au premier lancement, il prépare tout, télécharge l'outil officiel `cloudflared` (si absent ; sinon : `winget install --id Cloudflare.cloudflared`), charge les données **fictives** et crée trois comptes de démonstration avec des mots de passe aléatoires.
3. La fenêtre affiche **le lien** (de la forme `https://xxxx.trycloudflare.com`) et les **comptes** (aussi enregistrés dans `DEMO_IDENTIFIANTS.txt`). Donnez-les au jury.
4. **Laissez la fenêtre ouverte** pendant la présentation. `Ctrl + C` arrête tout : le lien devient invalide immédiatement.

Comment cela reste sûr :
- **Base et fichiers séparés** (`demo.sqlite3`, `private_media_demo/`) : vos vraies données ne sont jamais exposées.
- Aucun compte administrateur dans la démo (pas de gestion des utilisateurs) ; `demo_observateur` est en lecture seule.
- Mode production (DEBUG désactivé, serveur waitress, cookies sécurisés), bandeau « Mode démonstration » sur chaque page.
- Option : `PARTAGER_DEMO.bat --mails prof@exemple.ma,autre@exemple.ma` limite l'accès au lien à ces adresses (code reçu par e-mail, service Cloudflare).

À savoir : le lien change à chaque lancement, il n'a **aucune garantie de disponibilité** (service gratuit de test de Cloudflare) et quiconque possède le lien voit la page de connexion. N'y mettez jamais de données réelles de candidats. Préparez aussi un plan B : la démo locale (`LANCER.bat --demo`) fonctionne sans internet.

Non testé ici : le lancement du tunnel Cloudflare lui-même et l'exécution sous Windows. Ont été testés sous Linux : le serveur de démonstration en mode production, la connexion avec en-têtes HTTPS simulés (cookies sécurisés, protection CSRF, pages par rôle, fichiers statiques, absence de fuite d'informations de débogage).

### Données de démonstration (fictives, facultatives)

```bat
python manage.py seed_demo                 :: 3 offres, 24 candidats fictifs, candidatures, entretiens
python manage.py seed_demo --with-users    :: + 3 comptes demo_* (mots de passe aléatoires affichés une seule fois)
python manage.py seed_demo --reset         :: supprime puis recrée UNIQUEMENT les données marquées « démo »
python manage.py seed_demo --only-reset    :: supprime les données de démo
```
Les données de démo sont signalées par un badge « démo », utilisent des adresses `@example.test` et ne touchent jamais vos vraies données.

### Tests

```bat
python manage.py test ats
python manage.py check
```
Dernière exécution réelle (environnement Linux, Python 3.12, SQLite) : **107 tests, 0 échec**, `check` sans problème. Le lanceur `start_local.py` et le serveur de démonstration (`share_demo.py --no-tunnel`) ont aussi été exécutés de bout en bout sur une copie propre (création de l'environnement, installation, `.env`, base, serveur, connexion HTTP, pages). Couverture : barèmes et bornes du scoring, informations manquantes, CV (validation, PDF/DOCX réels, fichiers corrompus/vides), authentification et permissions par rôle, CRUD offres/candidats, doublons, processus et historique, Kanban JSON, entretiens (passé, conflits), recherche/filtres/pagination, exports CSV (filtres, neutralisation des formules), agrégations du tableau de bord, paramètres, commande de démo, limitation des essais de connexion, présélection avec égalités, comparaison, mot de passe par l'administrateur, lecture d'un `.env` enregistré avec BOM.

## Architecture

```
config/            réglages (variables d'environnement), urls
accounts/          utilisateur personnalisé + rôles
ats/
  models.py        modèle relationnel (offres, candidats, candidatures, critères, résultats, entretiens, audit…)
  services/        logique métier séparée des vues : scoring, cv_parser, analytics, pipeline, audit
  views/           vues par domaine ; permissions.py = décorateurs de rôle
  forms.py         validation côté serveur
  management/      seed_demo, apply_retention
  tests/           tests automatisés
templates/ static/ interface (Bootstrap 5, Chart.js et police embarqués : aucun CDN, fonctionne hors ligne)
private_media/     CV (hors de tout dossier public, servis uniquement par une vue protégée)
```

Rôles : *Observateur* = lecture des offres, du processus (anonymisé) et des analyses ; *Recruteur* = + candidats, CV, évaluations, entretiens ; *Responsable RH* = + paramètres, suppression, archivage, critères, journal d'audit ; *Administrateur* = + gestion des utilisateurs.

## Mise en ligne publique (démonstration)

Voir **`DEPLOIEMENT.md`** (pas à pas, Render + GitHub) : le projet contient `render.yaml`, `Procfile`, `.python-version`, un endpoint de santé `/sante/`, le **mode démonstration** (`TALENTFLOW_DEMO_MODE=1` : connexion en un clic sans compte administrateur, bandeau « données fictives », bouton de réinitialisation) et la commande de démarrage `bootstrap_demo`. Le démarrage de production a été simulé en local ; **le déploiement réel et l'URL publique n'ont pas pu être vérifiés** par l'auteur.

Options facultatives : `requirements-prod.txt` (PostgreSQL via `DATABASE_URL`), `requirements-ocr.txt` (OCR : installez aussi le programme Tesseract avec le français).

## IA responsable, vie privée (Maroc)

- Le score est une **aide à la décision**, pas une preuve de performance future. Limites à connaître : la correspondance de mots-clés produit des **faux négatifs** (compétence présente mais formulée autrement) ; des critères en apparence neutres (diplôme, lieu d'étude, parcours linéaire) peuvent **reproduire des biais** ; seule une relecture humaine permet de les corriger.
- Aucune analyse faciale, émotionnelle ou de personnalité. Aucune API d'IA externe.
- Les CV sont traités comme **non fiables** : jamais exécutés, texte seulement ; les instructions qu'ils contiendraient sont ignorées.
- Données personnelles : minimisation, accès restreint par rôle, téléchargements et exports journalisés, conservation configurable (`python manage.py apply_retention` simule ; `--apply` supprime).
- **Loi 09-08 / CNDP** : l'application fournit des briques techniques (accès restreint, traçabilité, conservation), mais **aucune conformité n'est revendiquée**. Déclaration/autorisation CNDP, information des candidats, base légale et durées de conservation doivent être validées par un juriste avant tout usage réel.

## Checklist avant une vraie mise en production

1. `DJANGO_DEBUG=0`, `DJANGO_SECRET_KEY` longue et secrète, `DJANGO_ALLOWED_HOSTS`, `DJANGO_CSRF_TRUSTED_ORIGINS`.
2. HTTPS obligatoire (cookies sécurisés, redirection SSL, HSTS) derrière un serveur web (nginx/IIS) ; servir `static/` via `collectstatic` (aucun serveur de fichiers statiques n'est inclus en mode non-debug).
3. Serveur WSGI (gunicorn/waitress) à la place de `runserver` ; PostgreSQL (variables `POSTGRES_*`, installer `psycopg`) — **non testé ici**.
4. Sauvegardes chiffrées de la base et de `private_media/`, chiffrement du disque.
5. Authentification à deux facteurs, cache partagé (Redis) pour la limitation des connexions, procédure de réinitialisation de mot de passe en libre-service (non fournie).
6. Antivirus sur les uploads, revue de sécurité indépendante, test de charge.
7. Validation juridique (Loi 09-08, CNDP) et information des candidats.

## Limitations connues

- Interface jamais contrôlée visuellement dans un navigateur ; Kanban glisser-déposer non testé en navigateur (la liste « Déplacer » est l'alternative fonctionnelle, testée côté serveur).
- `LANCER.bat` (petit fichier qui appelle `start_local.py`) n'a pas pu être exécuté sous Windows ici ; le programme Python qu'il lance l'a été sous Linux. Si Windows affiche une erreur, copiez-la pour correction.
- Extraction de CV heuristique (français surtout) : noms, durées et niveaux sont des estimations ; l'OCR (si disponible) est encore moins fiable.
- Interface **uniquement en français** (pas de version anglaise) ; le thème clair n'a pas été vérifié visuellement dans un navigateur.
- L'OCR dépend du programme Tesseract installé sur la machine : absent de l'hébergement gratuit standard.
- Pas de notifications e-mail, pas de réinitialisation de mot de passe en libre-service (l'administrateur le fait), pas de 2FA. Le blocage des essais de connexion est conservé en mémoire du processus (suffisant en local ; en production multi-processus, prévoir un cache partagé).
- PostgreSQL supporté par la configuration mais non exécuté ; seuls SQLite et Python 3.12 ont été utilisés pour les tests.
- Les CV importés puis abandonnés avant relecture restent dans `private_media/` jusqu'à `python manage.py purge_orphan_cvs` (supprime ceux de plus de 24 h).

## Dépannage

| Problème | Solution |
|---|---|
| La fenêtre noire se ferme / le navigateur affiche « site inaccessible » | Utilisez `LANCER.bat` : il attend que le serveur soit prêt avant d'ouvrir le navigateur et garde la fenêtre ouverte. Ne fermez pas la fenêtre pendant l'utilisation. |
| « Python est introuvable » | Installez Python (https://www.python.org/downloads/) en cochant « Add python.exe to PATH », puis relancez |
| Le lien de démo (`trycloudflare.com`) n'apparaît pas | Vérifiez internet/pare-feu (le tunnel utilise une connexion sortante UDP 7844 ou HTTPS 443) ; sinon installez `cloudflared` avec `winget install --id Cloudflare.cloudflared` et relancez |
| `manage.py introuvable` | Vous êtes dans le mauvais dossier ou le zip n'est pas extrait : extrayez-le puis ouvrez le dossier qui contient `manage.py` |
| Erreur pendant l'installation des dépendances | Vérifiez internet, puis supprimez le dossier `.venv` et relancez `LANCER.bat` |
| Pages sans style | Vérifiez que `.env` contient `DJANGO_DEBUG=1` : en mode non-debug les fichiers statiques ne sont pas servis |
| `CSRF verification failed` | Utilisez `http://127.0.0.1:8000` ou `localhost` tel qu'affiché dans la fenêtre ; ajoutez une autre adresse à `DJANGO_CSRF_TRUSTED_ORIGINS` |
| Port occupé | `LANCER.bat` choisit automatiquement 8001, 8002… ; lisez l'adresse affichée |
| « Trop de tentatives échouées » | Attendez 15 minutes ou redémarrez le programme |
| Mot de passe oublié | Un administrateur le redéfinit dans *Utilisateurs → Mot de passe*. Si c'est le seul administrateur : `python manage.py changepassword NOM` |
| Fichier `.env` modifié ne semble pas lu | Enregistrez-le en UTF-8 ; relancez le programme |
