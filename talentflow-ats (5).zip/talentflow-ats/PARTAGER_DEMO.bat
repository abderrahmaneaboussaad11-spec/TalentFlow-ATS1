@echo off
chcp 65001 >nul
title TalentFlow ATS - Partage de demonstration
cd /d "%~dp0"
echo.
echo === Partage de la DEMONSTRATION (donnees fictives) ===
where py >nul 2>nul && (py -3 share_demo.py %* & goto :fin)
where python >nul 2>nul && (python share_demo.py %* & goto :fin)
echo Python est introuvable. Installez Python depuis https://www.python.org/downloads/
start https://www.python.org/downloads/
:fin
echo.
echo Le partage est arrete. Si une erreur est affichee ci-dessus, copiez-la pour demander de l aide.
pause
