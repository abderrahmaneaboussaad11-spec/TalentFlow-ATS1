"""Lanceur tout-en-un de TalentFlow ATS (Windows, macOS, Linux).

Fait, dans l'ordre : environnement virtuel, installation des dépendances, fichier .env,
migrations, création de l'administrateur, puis démarre le serveur et ouvre le navigateur
UNE FOIS le serveur réellement prêt.
"""
import argparse
import hashlib
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import venv
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def say(msg=""):
    print(msg, flush=True)


def venv_python():
    sub = "Scripts/python.exe" if os.name == "nt" else "bin/python"
    return ROOT / ".venv" / sub


def run(cmd, what):
    say(f"\n> {what}")
    code = subprocess.call([str(c) for c in cmd], cwd=ROOT)
    if code != 0:
        say(f"\nERREUR pendant : {what}. Lisez le message ci-dessus, puis voir la section Dépannage du README.")
        sys.exit(code or 1)


def port_in_use(port):
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def open_when_ready(port, url):
    for _ in range(120):
        if port_in_use(port):
            time.sleep(0.5)
            webbrowser.open(url)
            return
        time.sleep(0.5)


def ensure_env():
    env = ROOT / ".env"
    if env.exists():
        return
    example = (ROOT / ".env.example").read_text(encoding="utf-8")
    key = secrets.token_urlsafe(50)
    lines = [f"DJANGO_SECRET_KEY={key}" if l.startswith("DJANGO_SECRET_KEY=") else l for l in example.splitlines()]
    env.write_text("\n".join(lines) + "\n", encoding="utf-8")
    say("Fichier .env créé avec une clé secrète générée automatiquement.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--no-server", action="store_true", help="Prépare tout sans lancer le serveur.")
    parser.add_argument("--demo", action="store_true", help="Charge les données de démonstration.")
    parser.add_argument("--skip-admin", action="store_true", help="Ne demande pas la création de l'administrateur.")
    args = parser.parse_args()

    say("=" * 58)
    say("  TalentFlow ATS — lancement")
    say("=" * 58)
    if sys.version_info < (3, 10):
        say(f"Python {sys.version.split()[0]} est trop ancien : installez Python 3.10 ou plus (https://www.python.org).")
        sys.exit(1)
    if not (ROOT / "manage.py").exists():
        say("manage.py introuvable : extrayez d'abord le zip complet, puis lancez ce programme depuis le dossier extrait.")
        sys.exit(1)

    vpy = venv_python()
    if not vpy.exists():
        say("\n> Création de l'environnement virtuel (une seule fois)...")
        venv.create(ROOT / ".venv", with_pip=True)
    req = (ROOT / "requirements.txt").read_bytes()
    marker = ROOT / ".venv" / ".deps_ok"
    digest = hashlib.sha256(req).hexdigest()
    if not marker.exists() or marker.read_text().strip() != digest:
        run([vpy, "-m", "pip", "install", "--disable-pip-version-check", "-r", "requirements.txt"], "Installation des dépendances (une seule fois, nécessite internet)")
        marker.write_text(digest)
    ensure_env()
    run([vpy, "manage.py", "migrate", "--noinput", "-v", "0"], "Préparation de la base de données")
    if not args.skip_admin:
        init_cmd = [vpy, "manage.py", "init_local"] + (["--demo"] if args.demo else [])
        run(init_cmd, "Vérification du compte administrateur")
    if args.no_server:
        say("\nPréparation terminée.")
        return

    port = next((p for p in range(8000, 8011) if not port_in_use(p)), None)
    if port is None:
        say("Aucun port libre entre 8000 et 8010. Fermez d'autres programmes et réessayez.")
        sys.exit(1)
    url = f"http://127.0.0.1:{port}/"
    say("\n" + "=" * 58)
    say(f"  Le site sera disponible sur : {url}")
    say("  NE FERMEZ PAS cette fenêtre tant que vous utilisez le site.")
    say("  Pour arrêter : Ctrl + C (ou fermez la fenêtre).")
    say("=" * 58 + "\n")
    if not args.no_browser:
        threading.Thread(target=open_when_ready, args=(port, url), daemon=True).start()
    try:
        subprocess.call([str(vpy), "manage.py", "runserver", f"127.0.0.1:{port}"], cwd=ROOT)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
