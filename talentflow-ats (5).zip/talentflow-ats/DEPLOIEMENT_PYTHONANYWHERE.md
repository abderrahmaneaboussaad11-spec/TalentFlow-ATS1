# Mettre la démonstration sur PythonAnywhere (gratuit, sans mise en veille)

> **Honnêteté** : ces étapes suivent l'aide officielle de PythonAnywhere (« Deploying an existing Django project ») et le fonctionnement du projet, mais **n'ont pas pu être exécutées par l'auteur** (aucun accès à un compte). Si une étape échoue, copiez le message de l'« Error log » (onglet *Web*) pour obtenir de l'aide.

Résultat : `https://VOTRE-NOM.pythonanywhere.com`, ouvert 24 h/24 tant que vous prolongez le site (voir étape 8).

Remplacez partout **VOTRE-NOM** par votre identifiant PythonAnywhere (il devient l'adresse du site).

## 1. Compte
Créez un compte gratuit « Beginner » sur https://www.pythonanywhere.com. Choisissez l'identifiant avec soin : c'est l'adresse publique.

## 2. Envoyer le projet
Onglet **Files** → *Upload a file* → choisissez `talentflow-ats.zip` (dossier personnel `/home/VOTRE-NOM`).

## 3. Installer (console Bash)
Onglet **Consoles** → *Bash*. Tapez ces commandes une par une :
```
cd ~
unzip talentflow-ats.zip
cd talentflow-ats
mkvirtualenv talentflow --python=python3.12
pip install -r requirements.txt
```
Si `python3.12` n'existe pas, utilisez une version proposée par PythonAnywhere (3.10 ou plus) et **retenez-la** : vous la choisirez de nouveau à l'étape 5.

## 4. Configurer (fichier `.env`) puis préparer les données fictives
Générez une clé secrète : `python -c "import secrets; print(secrets.token_urlsafe(50))"` et copiez le résultat.

Créez le fichier de configuration : `nano .env`, collez ceci en remplaçant VOTRE-NOM et la clé, puis `Ctrl+O`, Entrée, `Ctrl+X` :
```
DJANGO_DEBUG=0
DJANGO_SECRET_KEY=COLLEZ-LA-CLE-ICI
DJANGO_ALLOWED_HOSTS=VOTRE-NOM.pythonanywhere.com
DJANGO_CSRF_TRUSTED_ORIGINS=https://VOTRE-NOM.pythonanywhere.com
DJANGO_BEHIND_PROXY=1
DJANGO_SSL_REDIRECT=0
DJANGO_SECURE_COOKIES=1
TALENTFLOW_DEMO_MODE=1
```
Puis :
```
python manage.py bootstrap_demo
python manage.py collectstatic --noinput
```
La première commande crée la base, les données **fictives** et les comptes de démonstration. Ne mettez jamais de vraies données de candidats.

## 5. Créer l'application web
Onglet **Web** → *Add a new web app* → *Next* → **Manual configuration** (surtout pas l'option « Django », réservée aux nouveaux projets) → choisissez **la même version de Python** qu'à l'étape 3.

Dans la page de configuration :
- **Source code** : `/home/VOTRE-NOM/talentflow-ats`
- **Working directory** : `/home/VOTRE-NOM/talentflow-ats`
- **Virtualenv** : `talentflow` (ou le chemin complet `/home/VOTRE-NOM/.virtualenvs/talentflow`)

## 6. Fichier WSGI
Dans la section *Code*, cliquez le lien du **fichier WSGI** (nom du type `/var/www/VOTRE-NOM_pythonanywhere_com_wsgi.py`). Supprimez tout son contenu et collez :
```python
import os
import sys

path = '/home/VOTRE-NOM/talentflow-ats'
if path not in sys.path:
    sys.path.insert(0, path)

os.environ['DJANGO_SETTINGS_MODULE'] = 'config.settings'

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```
Enregistrez (*Save*).

## 7. Fichiers statiques, HTTPS, lancement
Toujours dans l'onglet *Web* :
- Section **Static files** : URL `/static/` → Directory `/home/VOTRE-NOM/talentflow-ats/staticfiles`
- Activez **Force HTTPS**.
- Cliquez le gros bouton vert **Reload**.

Ouvrez `https://VOTRE-NOM.pythonanywhere.com` : cliquez *Entrer comme Recruteur*. Testez aussi depuis un téléphone en 4G.

## 8. Garder le site actif (important)
Les sites gratuits **expirent** si vous ne les prolongez pas : PythonAnywhere vous envoie un e-mail d'avertissement ; connectez-vous et cliquez le bouton de prolongation de l'onglet *Web*. Pour les comptes récents, la durée est plus courte (environ un mois d'après leur annonce de janvier 2026). Mettez un rappel dans votre calendrier.

## Mise à jour et réinitialisation
- Nouvelle version du projet : renvoyez le zip, dézippez-le par-dessus (`unzip -o`), conservez `.env`, puis `python manage.py migrate`, `python manage.py collectstatic --noinput` et *Reload*.
- Remettre la démo à zéro : se connecter comme **Responsable RH** → *Paramètres* → *Réinitialiser la démonstration*.
- Sauvegarde : `python manage.py backup_data` (dossier `backups/`, à télécharger via l'onglet *Files*).

## Limites du plan gratuit
- Un seul site, sur une adresse `pythonanywhere.com` ; pas de domaine personnalisé.
- Pas d'accès SSH ni de tâches planifiées en gratuit ; accès internet sortant limité (sans effet sur ce projet).
- Quota de temps de calcul pour les consoles (100 secondes de CPU par jour) ; les requêtes du site n'en consomment pas, selon la documentation consultée.
- L'OCR (PDF scannés) n'est pas disponible : l'application propose la saisie manuelle.

## Dépannage
| Symptôme | Piste |
|---|---|
| « Something went wrong » | Onglet *Web* → lien **Error log** : lisez les dernières lignes |
| `ModuleNotFoundError` | Le champ *Virtualenv* est vide ou faux, ou `pip install` n'est pas allé au bout |
| `DisallowedHost` / « Bad Request (400) » | `DJANGO_ALLOWED_HOSTS` dans `.env` ne correspond pas exactement à votre adresse ; faites *Reload* |
| « CSRF verification failed » | `DJANGO_CSRF_TRUSTED_ORIGINS` doit contenir `https://VOTRE-NOM.pythonanywhere.com` |
| Pages sans style | Correspondance *Static files* absente ou `collectstatic` non exécuté |
| Rien ne change après modification | Cliquez *Reload* sur l'onglet *Web* |
